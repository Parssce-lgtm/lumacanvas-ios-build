import XCTest

final class ChatUITests: XCTestCase {
    func testAnywhereSwipeAndSingleTapRatioSelection() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["ui-test-fixture"]
        app.launch()
        XCTAssertTrue(app.descendants(matching: .any)["chat-input"].firstMatch.waitForExistence(timeout: 10))
        let start = app.coordinate(withNormalizedOffset: CGVector(dx: 0.35, dy: 0.4))
        let end = app.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.4))
        start.press(forDuration: 0.05, thenDragTo: end)
        XCTAssertTrue(app.buttons["more-image-button"].waitForExistence(timeout: 5))
        app.buttons["more-image-button"].tap()
        let orientation = app.buttons["orientation-button"]
        XCTAssertTrue(orientation.waitForExistence(timeout: 5))
        let ratio = app.buttons["ratio-16:9"]
        XCTAssertTrue(ratio.isHittable, app.debugDescription)
        ratio.tap()
        XCTAssertTrue(ratio.isSelected, app.debugDescription)
        XCTAssertGreaterThanOrEqual(app.buttons["ratio-auto"].frame.minX, orientation.frame.maxX)
    }

    func testChatAndAdultModeRequiresConfirmation() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["ui-test-fixture", "ui-preview-conversation"]
        app.launch()
        let input = app.descendants(matching: .any)["chat-input"].firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 10), app.debugDescription)
        input.tap(); input.typeText("开启成人模式")
        app.buttons["chat-send-button"].tap()
        let consent = app.alerts["开启成人模式？"]
        XCTAssertTrue(consent.waitForExistence(timeout: 5))
        consent.buttons["取消"].tap()
        XCTAssertFalse(app.buttons["关闭"].exists)
        app.buttons["chat-send-button"].tap()
        XCTAssertTrue(consent.waitForExistence(timeout: 5))
        consent.buttons["确认"].tap()
        XCTAssertFalse(app.staticTexts["成人模式"].exists)
        input.tap(); input.typeText("你好")
        app.buttons["chat-send-button"].tap()
        XCTAssertTrue(app.textViews.matching(NSPredicate(format: "value CONTAINS %@", "聊天测试回复成功")).firstMatch.waitForExistence(timeout: 5))
        app.buttons["聊天选项"].tap()
        app.buttons["关闭成人模式"].tap()
        XCTAssertTrue(app.buttons["复制回复"].exists)
        XCTAssertTrue(app.buttons["分享回复"].exists)
        app.buttons["回复选项"].tap()
        XCTAssertTrue(app.buttons["重试"].exists)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.7, dy: 0.6)).tap()
        let message = app.textViews.matching(NSPredicate(format: "value == %@", "你好")).firstMatch
        message.press(forDuration: 0.6)
        let selection = app.descendants(matching: .any)["选择文本"].firstMatch
        XCTAssertTrue(selection.waitForExistence(timeout: 3), app.debugDescription)
        selection.tap()
        let selectedText = app.textViews["selected-message-text"]
        XCTAssertTrue(selectedText.waitForExistence(timeout: 5))
        selectedText.doubleTap()
        XCTAssertTrue(app.menuItems["拷贝"].waitForExistence(timeout: 3) || app.menuItems["Copy"].exists || app.buttons["Copy"].exists || app.menuItems["复制"].exists || app.buttons["复制"].exists, app.debugDescription)
        app.buttons["完成"].tap()
        app.buttons["复制回复"].tap()
        app.buttons["聊天选项"].tap()
        app.buttons["临时聊天"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["temporary-chat-notice"].firstMatch.waitForExistence(timeout: 5))
        input.tap(); input.typeText("临时消息")
        app.buttons["chat-send-button"].tap()
        XCTAssertTrue(app.textViews.matching(NSPredicate(format: "value CONTAINS %@", "聊天测试回复成功")).firstMatch.waitForExistence(timeout: 5))
        app.buttons["聊天选项"].tap()
        app.buttons["返回普通聊天"].tap()
        XCTAssertTrue(app.textViews.matching(NSPredicate(format: "value == %@", "你好")).firstMatch.waitForExistence(timeout: 5))
        XCTAssertFalse(app.textViews.matching(NSPredicate(format: "value == %@", "临时消息")).firstMatch.exists)
        input.tap(); input.typeText("草稿")
        app.buttons["chat-more-button"].tap()
        XCTAssertTrue(app.buttons["more-image-button"].waitForExistence(timeout: 5))
        app.buttons["new-conversation-button"].tap()
        XCTAssertTrue(app.staticTexts["有什么可以帮你？"].waitForExistence(timeout: 5))
    }
    func testAttachmentPreviewAndModelTestSurvivesLeavingSettings() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["ui-test-fixture", "ui-preview-chat-attachment"]
        app.launch()
        let strip = app.descendants(matching: .any)["chat-attachment-strip"].firstMatch
        XCTAssertTrue(strip.waitForExistence(timeout: 10))
        XCTAssertFalse(app.textViews.matching(NSPredicate(format: "value CONTAINS %@", "聊天测试回复成功")).firstMatch.exists)
        app.buttons["chat-send-button"].tap()
        XCTAssertTrue(app.textViews.matching(NSPredicate(format: "value CONTAINS %@", "聊天测试回复成功")).firstMatch.waitForExistence(timeout: 5))
        XCTAssertFalse(strip.exists)
        app.buttons["chat-more-button"].tap()
        let drawerSettings = app.buttons["more-settings-button"]
        XCTAssertTrue(drawerSettings.waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["chat-more-button"].frame.minX > 200, app.debugDescription)
        drawerSettings.tap()
        XCTAssertTrue(app.buttons["完成"].waitForExistence(timeout: 5), app.debugDescription)
        let probe = app.buttons["test-model-button"]
        for _ in 0..<4 {
            if probe.exists && probe.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(probe.isHittable, app.debugDescription)
        probe.tap()
        app.buttons["完成"].tap()
        app.buttons["more-settings-button"].tap()
        let result = app.descendants(matching: .any)["model-test-result"].firstMatch
        for _ in 0..<4 {
            if result.exists && result.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(result.waitForExistence(timeout: 10), app.debugDescription)
        XCTAssertEqual(result.label, "可用")
    }
}
