import XCTest

final class ChatUITests: XCTestCase {
    func testChatAndAdultModeRequiresConfirmation() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["ui-test-fixture", "ui-preview-conversation"]
        app.launch()
        let input = app.descendants(matching: .any)["chat-input"].firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 10), app.debugDescription)
        input.tap(); input.typeText("开启成人模式")
        app.buttons["chat-send-button"].tap()
        let consent = app.alerts["开启成人模式？"]
        XCTAssertTrue(consent.waitForExistence(timeout: 5))
        consent.buttons["取消"].tap()
        XCTAssertFalse(app.buttons["关闭"].exists)
        app.buttons["chat-send-button"].tap()
        XCTAssertTrue(consent.waitForExistence(timeout: 5))
        consent.buttons["确认"].tap()
        XCTAssertTrue(app.buttons["关闭"].waitForExistence(timeout: 5))
        input.tap(); input.typeText("你好")
        app.buttons["chat-send-button"].tap()
        XCTAssertTrue(app.staticTexts["聊天测试回复成功"].waitForExistence(timeout: 5))
        app.buttons["关闭"].tap()
        XCTAssertFalse(app.buttons["关闭"].exists)
        XCTAssertTrue(app.buttons["复制回复"].exists)
        XCTAssertTrue(app.buttons["分享回复"].exists)
        XCTAssertTrue(app.buttons["重试回复"].exists)
        app.staticTexts["你好"].firstMatch.press(forDuration: 0.8)
        XCTAssertTrue(app.buttons["编辑"].waitForExistence(timeout: 5))
        app.buttons["复制"].tap()
        app.buttons["聊天选项"].tap()
        app.buttons["临时聊天"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["temporary-chat-notice"].firstMatch.waitForExistence(timeout: 5))
        input.tap(); input.typeText("临时消息")
        app.buttons["chat-send-button"].tap()
        XCTAssertTrue(app.staticTexts["聊天测试回复成功"].waitForExistence(timeout: 5))
        app.buttons["聊天选项"].tap()
        app.buttons["返回普通聊天"].tap()
        XCTAssertTrue(app.staticTexts["你好"].firstMatch.waitForExistence(timeout: 5))
        XCTAssertFalse(app.staticTexts["临时消息"].exists)
    }
}
