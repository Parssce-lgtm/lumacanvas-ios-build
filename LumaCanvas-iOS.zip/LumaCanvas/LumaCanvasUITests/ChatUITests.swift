import XCTest

final class ChatUITests: XCTestCase {
    func testChatAndAdultModeRequiresConfirmation() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["ui-test-fixture", "ui-preview-conversation"]
        app.launch()
        let input = app.descendants(matching: .any)["chat-input"].firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 10), app.debugDescription)
        input.tap(); input.typeText("开启成人模式")
        app.buttons["chat-send-button"].tap()
        let consent = app.alerts["开启成人模式？"]
        XCTAssertTrue(consent.waitForExistence(timeout: 5))
        consent.buttons["取消"].tap()
        XCTAssertFalse(app.buttons["关闭"].exists)
        app.buttons["chat-send-button"].tap()
        XCTAssertTrue(consent.waitForExistence(timeout: 5))
        consent.buttons["确认"].tap()
        XCTAssertTrue(app.buttons["关闭"].waitForExistence(timeout: 5))
        input.tap(); input.typeText("你好")
        app.buttons["chat-send-button"].tap()
        XCTAssertTrue(app.staticTexts["聊天测试回复成功"].waitForExistence(timeout: 5))
        app.buttons["关闭"].tap()
        XCTAssertFalse(app.buttons["关闭"].exists)
    }
}
