import XCTest

final class InteractionTests: XCTestCase {
    func testDrawerKeepsBottomLayoutAndGlassButtonsEnabled() {
        let app = launch()
        let generate = app.buttons["generate-button"]
        XCTAssertTrue(generate.waitForExistence(timeout: 8))
        let before = generate.frame
        let saveBefore = app.buttons["save-photo-button"].frame
        app.buttons["more-button"].tap()
        XCTAssertTrue(app.buttons["more-settings-button"].waitForExistence(timeout: 5))
        XCTAssertTrue(generate.isEnabled)
        XCTAssertEqual(generate.frame.minY, before.minY, accuracy: 1)
        XCTAssertEqual(generate.frame.width, before.width, accuracy: 1)
        XCTAssertEqual(generate.frame.minX - before.minX, app.frame.width * 0.75, accuracy: 2)
        XCTAssertEqual(app.buttons["save-photo-button"].frame.minY, saveBefore.minY, accuracy: 1)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.8, dy: 0.65))
            .press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.05, dy: 0.65)))
        XCTAssertTrue(generate.waitForExistence(timeout: 5))
        XCTAssertEqual(generate.frame.minX, before.minX, accuracy: 1)
        XCTAssertEqual(generate.frame.minY, before.minY, accuracy: 1)
    }

    func testDeletingLastInstanceShowsNewAPIConfiguration() {
        let app = launch()
        app.buttons["more-button"].tap(); app.buttons["more-settings-button"].tap()
        let deletion = app.buttons["delete-instance-button"]
        for _ in 0..<6 { if deletion.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(deletion.isHittable); deletion.tap()
        app.buttons["删除当前实例"].lastMatch.tap()
        for _ in 0..<6 { if app.textFields["实例名称"].isHittable { break }; app.swipeDown() }
        XCTAssertEqual(app.textFields["实例名称"].value as? String, "配置新 API")
        app.buttons["完成"].tap()
        XCTAssertTrue(app.buttons["more-settings-button"].waitForExistence(timeout: 5))
        app.buttons["more-settings-button"].tap()
        XCTAssertEqual(app.textFields["实例名称"].value as? String, "配置新 API")
    }

    private func launch(_ extra: [String] = []) -> XCUIApplication {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["ui-test-fixture"] + extra
        app.launch()
        return app
    }

    private func waitForKeyboardToClose(_ app: XCUIApplication) {
        let expectation = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: app.keyboards.firstMatch)
        XCTAssertEqual(XCTWaiter.wait(for: [expectation], timeout: 8), .completed, app.debugDescription)
    }

    func testGenerateWithKeyboardStartsOnFirstTap() {
        let app = launch()
        let prompt = app.textViews["prompt-editor"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 8))
        prompt.tap()
        prompt.typeText("A blue circle")
        XCTAssertTrue(app.keyboards.firstMatch.exists)
        app.buttons["generate-button"].tap()
        let generating = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", "正在生成"), object: app.buttons["generate-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [generating], timeout: 3), .completed, "A single tap must submit while the keyboard is showing.\n" + app.debugDescription)
        waitForKeyboardToClose(app)
        let saved = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value == %@", "可保存"), object: app.buttons["save-photo-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [saved], timeout: 10), .completed)
    }

    func testEmptyPromptAndMissingArtworkGiveFeedback() {
        let app = launch()
        app.buttons["generate-button"].tap()
        XCTAssertTrue(app.staticTexts["请先输入提示词"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.buttons["停止等待"].exists)
        app.buttons["export-file-button"].tap()
        XCTAssertTrue(app.staticTexts["请先生成图片"].waitForExistence(timeout: 3))
    }

    func testModelProbeAndImageModelsComeFirst() {
        let app = launch()
        app.buttons["more-button"].tap()
        app.buttons["more-settings-button"].tap()
        let probe = app.buttons["test-model-button"]
        for _ in 0..<6 {
            if probe.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(probe.isHittable)
        probe.tap()
        XCTAssertTrue(app.staticTexts["model-test-result"].waitForExistence(timeout: 12))
        XCTAssertEqual(app.staticTexts["model-test-result"].label, "可用")
        let read = app.buttons["读取模型列表"]
        for _ in 0..<4 { if read.isHittable { break }; app.swipeDown() }
        read.tap()
        let image = app.buttons["model-gpt-image-fixture"]
        XCTAssertTrue(image.waitForExistence(timeout: 5))
        let other = app.buttons["model-gpt-chat-fixture"]
        XCTAssertTrue(other.exists)
        XCTAssertLessThan(image.frame.minY, other.frame.minY)
        XCTAssertTrue(app.staticTexts["图片生成（1）"].exists)
        XCTAssertTrue(app.staticTexts["其他模型（1）"].exists)
    }

    func testChatGenerationAcceptsStreamingResultOnMainPage() {
        let app = launch(["ui-test-chat"])
        let prompt = app.textViews["prompt-editor"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 8))
        prompt.tap(); prompt.typeText("A blue circle")
        app.buttons["generate-button"].tap()
        let generating = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", "正在生成"), object: app.buttons["generate-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [generating], timeout: 5), .completed, app.debugDescription)
        waitForKeyboardToClose(app)
        let saved = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value == %@", "可保存"), object: app.buttons["save-photo-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [saved], timeout: 30), .completed, app.debugDescription)
        XCTAssertFalse(app.alerts.firstMatch.exists)
    }

    func testMultipleReferencesCanBeRemovedIndividually() {
        let app = launch(["ui-test-references"])
        let count = app.staticTexts["reference-count"]
        XCTAssertTrue(count.waitForExistence(timeout: 8))
        XCTAssertTrue(count.label.contains("2/8"))
        app.buttons["移除 第一张"].tap()
        XCTAssertTrue(count.label.contains("1/8"))
        XCTAssertTrue(app.buttons["移除 第二张"].exists)
        app.buttons["移除 第二张"].tap()
        XCTAssertFalse(count.exists)
    }

    func testRealNetworkImageCompletesAfterHomeAndReturn() {
        let app = launch(["ui-test-background-network"])
        let prompt = app.textViews["prompt-editor"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 8))
        prompt.tap(); prompt.typeText("A blue circle")
        app.buttons["generate-button"].tap()
        let generating = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", "正在生成"), object: app.buttons["generate-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [generating], timeout: 3), .completed)
        XCUIDevice.shared.press(.home)
        XCTAssertTrue(app.wait(for: .runningBackground, timeout: 5), "Wait for Home transition before verifying suspension")
        // The server delays 12 seconds; allow the UI to suspend during the reply.
        let delay = XCTestExpectation(description: "Wait for delayed HTTP response")
        XCTAssertEqual(XCTWaiter.wait(for: [delay], timeout: 14), .timedOut)
        app.activate()
        let saved = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value == %@", "可保存"), object: app.buttons["save-photo-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [saved], timeout: 20), .completed)
        XCTAssertFalse(app.alerts.firstMatch.exists)
    }

    func testStandardPOSTDisplaysRealRinkoResponse() {
        let app = launch(["ui-test-standard-network"])
        let prompt = app.textViews["prompt-editor"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 8))
        prompt.tap(); prompt.typeText("A blue circle")
        app.buttons["generate-button"].tap()
        let saved = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value == %@", "可保存"), object: app.buttons["save-photo-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [saved], timeout: 20), .completed, app.debugDescription)
        XCTAssertFalse(app.alerts.firstMatch.exists)
    }

    func testDrawerSwipesFromMainAndInsideDrawer() {
        let app = launch()
        XCTAssertTrue(app.buttons["more-button"].waitForExistence(timeout: 8))
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.12, dy: 0.60))
            .press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.75, dy: 0.60)))
        let gallery = app.buttons["more-gallery-button"]
        XCTAssertTrue(gallery.waitForExistence(timeout: 5), app.debugDescription)
        let drawer = app.descendants(matching: .any)["more-drawer"].firstMatch
        XCTAssertLessThanOrEqual(drawer.frame.width, 171)
        // Start inside the drawer, rather than on the shifted main-page overlay.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.32, dy: 0.72))
            .press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.05, dy: 0.72)))
        let closed = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: gallery)
        XCTAssertEqual(XCTWaiter.wait(for: [closed], timeout: 5), .completed, app.debugDescription)
        app.buttons["more-button"].tap()
        XCTAssertTrue(gallery.waitForExistence(timeout: 5))
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.60)).tap()
        XCTAssertFalse(gallery.exists)
    }

    func testRatioTapsHoldReleaseAndCircularOrientation() {
        let app = launch()
        let orientation = app.buttons["orientation-button"]
        XCTAssertTrue(orientation.waitForExistence(timeout: 8))
        XCTAssertEqual(orientation.frame.width, orientation.frame.height, accuracy: 1)
        orientation.tap()
        XCTAssertEqual(orientation.value as? String, "竖图")
        orientation.tap()
        XCTAssertEqual(orientation.value as? String, "横图")
        let wide = app.buttons["ratio-16:9"]
        wide.tap()
        XCTAssertTrue(wide.isSelected)
        let portrait = app.buttons["ratio-3:4"]
        portrait.press(forDuration: 0.25)
        XCTAssertTrue(portrait.isSelected)
        XCTAssertFalse(wide.isSelected)
        XCTAssertEqual(wide.frame.width, portrait.frame.width, accuracy: 1)
        XCTAssertEqual(orientation.value as? String, "竖图")
        app.buttons["ratio-auto"].tap()
        XCTAssertTrue(app.buttons["ratio-auto"].isSelected)
    }

    func testMoreDrawerAndGalleryOpenStoredImages() {
        let app = launch(["ui-test-gallery"])
        let more = app.buttons["more-button"]
        XCTAssertTrue(more.waitForExistence(timeout: 8)); more.tap()
        let gallery = app.buttons["more-gallery-button"]
        XCTAssertTrue(gallery.waitForExistence(timeout: 8), app.debugDescription)
        XCTAssertTrue(app.descendants(matching: .any)["more-video-unavailable"].exists)
        gallery.tap()
        let newest = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "gallery-item-"))
        XCTAssertTrue(newest.firstMatch.waitForExistence(timeout: 10))
        XCTAssertEqual(newest.count, 2)
        newest.firstMatch.tap()
        XCTAssertTrue(app.buttons["gallery-export-button"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["gallery-save-button"].exists)
        app.buttons["放大图片"].tap()
        XCTAssertTrue(app.buttons["关闭全屏预览"].waitForExistence(timeout: 5))
        app.buttons["关闭全屏预览"].tap()
        XCTAssertTrue(app.buttons["gallery-export-button"].waitForExistence(timeout: 5))
    }

    func testGalleryRightSwipesReturnThroughGalleryToOpenDrawer() {
        let app = launch(["ui-test-gallery"])
        app.buttons["more-button"].tap(); app.buttons["more-gallery-button"].tap()
        let images = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "gallery-item-"))
        XCTAssertTrue(images.firstMatch.waitForExistence(timeout: 8)); images.firstMatch.tap()
        XCTAssertTrue(app.buttons["gallery-export-button"].waitForExistence(timeout: 5))
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.2, dy: 0.55))
            .press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.55)))
        XCTAssertTrue(images.firstMatch.waitForExistence(timeout: 5), app.debugDescription)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.2, dy: 0.7))
            .press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.7)))
        XCTAssertTrue(app.buttons["more-gallery-button"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["more-settings-button"].isHittable)
    }

    func testGalleryContinueEditingThenNewConversationClearsDraft() {
        let app = launch(["ui-test-gallery"])
        app.buttons["more-button"].tap(); app.buttons["more-gallery-button"].tap()
        let images = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "gallery-item-"))
        XCTAssertTrue(images.firstMatch.waitForExistence(timeout: 8)); images.firstMatch.tap()
        let edit = app.buttons["gallery-edit-button"]
        XCTAssertTrue(edit.waitForExistence(timeout: 5)); edit.tap()
        let count = app.staticTexts["reference-count"]
        XCTAssertTrue(count.waitForExistence(timeout: 8), app.debugDescription)
        XCTAssertTrue(count.label.contains("1/8"))
        let prompt = app.textViews["prompt-editor"]
        XCTAssertFalse((prompt.value as? String ?? "").isEmpty)
        app.buttons["more-button"].tap()
        app.buttons["new-conversation-button"].tap()
        XCTAssertTrue(prompt.waitForExistence(timeout: 5))
        XCTAssertEqual(prompt.value as? String, "")
        XCTAssertFalse(count.exists)
        XCTAssertEqual(app.buttons["save-photo-button"].value as? String, "尚无图片")
    }

    func testGalleryLongPressOffersActionsAndDeletionUpdatesGallery() {
        let app = launch(["ui-test-gallery"])
        app.buttons["more-button"].tap(); app.buttons["more-gallery-button"].tap()
        let images = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "gallery-item-"))
        XCTAssertTrue(images.firstMatch.waitForExistence(timeout: 8))
        images.firstMatch.press(forDuration: 0.8)
        XCTAssertTrue(app.buttons["分享"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["继续编辑"].exists)
        app.buttons["删除照片"].tap()
        let deletion = app.buttons["删除照片"]
        XCTAssertTrue(deletion.waitForExistence(timeout: 5)); deletion.tap()
        let updated = XCTNSPredicateExpectation(predicate: NSPredicate(format: "count == 1"), object: images)
        XCTAssertEqual(XCTWaiter.wait(for: [updated], timeout: 5), .completed, app.debugDescription)
    }

    func testImageVerticalSwipeClosesZoomAndPreservesDetail() {
        let app = launch(["ui-test-gallery"])
        app.buttons["more-button"].tap(); app.buttons["more-gallery-button"].tap()
        let images = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "gallery-item-"))
        XCTAssertTrue(images.firstMatch.waitForExistence(timeout: 8)); images.firstMatch.tap()
        let original = app.buttons["放大图片"]
        XCTAssertTrue(original.waitForExistence(timeout: 5))
        let originalFrame = original.frame
        original.tap()
        let close = app.buttons["关闭全屏预览"]
        XCTAssertTrue(close.waitForExistence(timeout: 5))
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.45))
            .press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.8)))
        let closed = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: close)
        XCTAssertEqual(XCTWaiter.wait(for: [closed], timeout: 5), .completed)
        XCTAssertTrue(app.buttons["gallery-export-button"].exists)
        XCTAssertEqual(original.frame.minY, originalFrame.minY, accuracy: 1)
    }
}
