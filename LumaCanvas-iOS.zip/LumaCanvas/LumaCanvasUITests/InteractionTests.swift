import XCTest

final class InteractionTests: XCTestCase {
    private func launch(_ extra: [String] = []) -> XCUIApplication {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["ui-test-fixture"] + extra
        app.launch()
        return app
    }

    private func waitForKeyboardToClose(_ app: XCUIApplication) {
        let expectation = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: app.keyboards.firstMatch)
        XCTAssertEqual(XCTWaiter.wait(for: [expectation], timeout: 5), .completed)
    }

    func testGenerateWithKeyboardStartsOnFirstTap() {
        let app = launch()
        let prompt = app.textViews["prompt-editor"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 8))
        prompt.tap()
        prompt.typeText("A blue circle")
        XCTAssertTrue(app.keyboards.firstMatch.exists)
        app.buttons["generate-button"].tap()
        let generating = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", "正在生成"), object: app.buttons["generate-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [generating], timeout: 3), .completed, "A single tap must submit while the keyboard is showing.\n" + app.debugDescription)
        waitForKeyboardToClose(app)
        let saved = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value == %@", "可保存"), object: app.buttons["save-photo-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [saved], timeout: 10), .completed)
    }

    func testEmptyPromptAndMissingArtworkGiveFeedback() {
        let app = launch()
        app.buttons["generate-button"].tap()
        XCTAssertTrue(app.staticTexts["请先输入提示词"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.buttons["停止等待"].exists)
        app.buttons["export-file-button"].tap()
        XCTAssertTrue(app.staticTexts["请先生成图片"].waitForExistence(timeout: 3))
    }

    func testModelProbeAndImageModelsComeFirst() {
        let app = launch()
        app.buttons["API 设置"].tap()
        let probe = app.buttons["test-model-button"]
        for _ in 0..<6 {
            if probe.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(probe.isHittable)
        probe.tap()
        XCTAssertTrue(app.staticTexts["model-test-result"].waitForExistence(timeout: 12))
        XCTAssertEqual(app.staticTexts["model-test-result"].label, "可用")
        let read = app.buttons["读取模型列表"]
        for _ in 0..<4 { if read.isHittable { break }; app.swipeDown() }
        read.tap()
        let image = app.buttons["model-gpt-image-fixture"]
        XCTAssertTrue(image.waitForExistence(timeout: 5))
        let other = app.buttons["model-gpt-chat-fixture"]
        XCTAssertTrue(other.exists)
        XCTAssertLessThan(image.frame.minY, other.frame.minY)
        XCTAssertTrue(app.staticTexts["图片生成（1）"].exists)
        XCTAssertTrue(app.staticTexts["其他模型（1）"].exists)
    }

    func testChatGenerationAcceptsStreamingResultOnMainPage() {
        let app = launch(["ui-test-chat"])
        let prompt = app.textViews["prompt-editor"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 8))
        prompt.tap(); prompt.typeText("A blue circle")
        app.buttons["generate-button"].tap()
        let generating = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", "正在生成"), object: app.buttons["generate-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [generating], timeout: 5), .completed, app.debugDescription)
        waitForKeyboardToClose(app)
        let saved = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value == %@", "可保存"), object: app.buttons["save-photo-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [saved], timeout: 30), .completed, app.debugDescription)
        XCTAssertFalse(app.alerts.firstMatch.exists)
    }

    func testMultipleReferencesCanBeRemovedIndividually() {
        let app = launch(["ui-test-references"])
        let count = app.staticTexts["reference-count"]
        XCTAssertTrue(count.waitForExistence(timeout: 8))
        XCTAssertTrue(count.label.contains("2/8"))
        app.buttons["移除 第一张"].tap()
        XCTAssertTrue(count.label.contains("1/8"))
        XCTAssertTrue(app.buttons["移除 第二张"].exists)
        app.buttons["移除 第二张"].tap()
        XCTAssertFalse(count.exists)
    }

    func testRealNetworkImageCompletesAfterHomeAndReturn() {
        let app = launch(["ui-test-background-network"])
        let prompt = app.textViews["prompt-editor"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 8))
        prompt.tap(); prompt.typeText("A blue circle")
        app.buttons["generate-button"].tap()
        let generating = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", "正在生成"), object: app.buttons["generate-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [generating], timeout: 3), .completed)
        XCUIDevice.shared.press(.home)
        XCTAssertTrue(app.wait(for: .runningBackground, timeout: 5), "Wait for Home transition before verifying suspension")
        // The server delays 12 seconds; allow the UI to suspend during the reply.
        let delay = XCTestExpectation(description: "Wait for delayed HTTP response")
        XCTAssertEqual(XCTWaiter.wait(for: [delay], timeout: 14), .timedOut)
        app.activate()
        let saved = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value == %@", "可保存"), object: app.buttons["save-photo-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [saved], timeout: 20), .completed)
        XCTAssertFalse(app.alerts.firstMatch.exists)
    }

    func testStandardPOSTDisplaysRealRinkoResponse() {
        let app = launch(["ui-test-standard-network"])
        let prompt = app.textViews["prompt-editor"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 8))
        prompt.tap(); prompt.typeText("A blue circle")
        app.buttons["generate-button"].tap()
        let saved = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value == %@", "可保存"), object: app.buttons["save-photo-button"])
        XCTAssertEqual(XCTWaiter.wait(for: [saved], timeout: 20), .completed, app.debugDescription)
        XCTAssertFalse(app.alerts.firstMatch.exists)
    }

    func testMoreDrawerAndGalleryOpenStoredImages() {
        let app = launch(["ui-test-gallery"])
        let more = app.buttons["more-button"]
        XCTAssertTrue(more.waitForExistence(timeout: 8)); more.tap()
        let gallery = app.buttons["more-gallery-button"]
        XCTAssertTrue(gallery.waitForExistence(timeout: 5))
        XCTAssertTrue(app.descendants(matching: .any)["more-video-unavailable"].exists)
        gallery.tap()
        let newest = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "gallery-item-"))
        XCTAssertTrue(newest.firstMatch.waitForExistence(timeout: 10))
        XCTAssertEqual(newest.count, 2)
        newest.firstMatch.tap()
        XCTAssertTrue(app.buttons["gallery-export-button"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["gallery-save-button"].exists)
        app.buttons["放大图片"].tap()
        XCTAssertTrue(app.buttons["关闭全屏预览"].waitForExistence(timeout: 5))
        app.buttons["关闭全屏预览"].tap()
        XCTAssertTrue(app.buttons["gallery-export-button"].waitForExistence(timeout: 5))
    }
}
