#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"
: "${TEAM_ID:?Set TEAM_ID to your Apple team ID}"
: "${BUNDLE_ID:?Set BUNDLE_ID to your unique app identifier}"
EXPORT_OPTIONS="${EXPORT_OPTIONS:-$PROJECT_ROOT/ExportOptions.local.plist}"
if [[ ! -f "$EXPORT_OPTIONS" ]]; then
  echo "Copy ExportOptions.example.plist to ExportOptions.local.plist and fill in your team ID." >&2
  exit 1
fi
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "Requires macOS with full Xcode installed." >&2
  exit 1
fi
TASK_BUILD="$(mktemp -d "$PROJECT_ROOT/build-signed.XXXXXX")"
trap 'rm -rf "$TASK_BUILD"' EXIT
mkdir -p "$PROJECT_ROOT/build"
xcodebuild \
  -project LumaCanvas.xcodeproj \
  -scheme LumaCanvas \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  -archivePath "$TASK_BUILD/LumaCanvas.xcarchive" \
  -allowProvisioningUpdates \
  DEVELOPMENT_TEAM="$TEAM_ID" PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID" \
  archive
xcodebuild \
  -exportArchive \
  -archivePath "$TASK_BUILD/LumaCanvas.xcarchive" \
  -exportPath "$TASK_BUILD/export" \
  -exportOptionsPlist "$EXPORT_OPTIONS" \
  -allowProvisioningUpdates
test -f "$TASK_BUILD/export/LumaCanvas.ipa"
mv -f "$TASK_BUILD/export/LumaCanvas.ipa" "$PROJECT_ROOT/build/LumaCanvas.ipa"
echo "Created signed IPA: $PROJECT_ROOT/build/LumaCanvas.ipa"
