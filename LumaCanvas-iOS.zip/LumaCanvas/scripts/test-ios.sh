#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"
python3 scripts/network-test-server.py > build-network-test.log 2>&1 &
TASK_SERVER_PID=$!
trap 'kill "$TASK_SERVER_PID" 2>/dev/null || true' EXIT
python3 - <<'PY'
import time, urllib.request
for _ in range(50):
    try:
        urllib.request.urlopen('http://localhost:8765/health',timeout=1).read()
        break
    except OSError: time.sleep(.1)
else: raise RuntimeError('Network test server failed to start')
PY
TASK_SIMULATOR="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; devices=[d for _,group in sorted(json.load(sys.stdin)["devices"].items(), key=lambda pair: [int(x) for x in pair[0].split("iOS-")[-1].split("-") if x.isdigit()], reverse=True) for d in group if d.get("isAvailable") and "iPhone" in d["name"]]; assert devices, "No available iPhone simulator. Install an iOS runtime in Xcode Settings > Components."; print(devices[0]["udid"])')"
xcrun simctl boot "$TASK_SIMULATOR" || true
xcrun simctl bootstatus "$TASK_SIMULATOR" -b
TASK_TEST_FILTER=()
if [[ "${1:-}" != "--all" ]]; then
  # Default to the current drawer/settings smoke checks; --all retains the complete suite.
  TASK_TEST_FILTER=(-only-testing:LumaCanvasTests/CanvasTaskTests -only-testing:LumaCanvasTests/CanvasDraftTests -only-testing:LumaCanvasTests/ChatTests -only-testing:LumaCanvasUITests/ChatUITests/testAnywhereSwipeAndSingleTapRatioSelection -only-testing:LumaCanvasUITests/ChatUITests/testAttachmentPreviewAndModelTestSurvivesLeavingSettings)
fi
xcodebuild test \
  -project LumaCanvas.xcodeproj \
  -scheme LumaCanvas \
  -destination "platform=iOS Simulator,id=$TASK_SIMULATOR" \
  -derivedDataPath build/TestDerivedData \
  -parallel-testing-enabled NO \
  "${TASK_TEST_FILTER[@]}" \
  CODE_SIGNING_ALLOWED=YES CODE_SIGN_IDENTITY=-
