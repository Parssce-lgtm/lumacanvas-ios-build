#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "Requires macOS with full Xcode installed. Windows cannot compile the iOS SDK." >&2
  exit 1
fi
TASK_BUILD="$(mktemp -d "$PROJECT_ROOT/build-unsigned.XXXXXX")"
trap 'rm -rf "$TASK_BUILD"' EXIT
mkdir -p "$PROJECT_ROOT/build"
xcodebuild \
  -project LumaCanvas.xcodeproj \
  -scheme LumaCanvas \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$TASK_BUILD/DerivedData" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  build
APP_PATH="$TASK_BUILD/DerivedData/Build/Products/Release-iphoneos/LumaCanvas.app"
test -d "$APP_PATH"
mkdir -p "$TASK_BUILD/package/Payload"
ditto "$APP_PATH" "$TASK_BUILD/package/Payload/LumaCanvas.app"
(
  cd "$TASK_BUILD/package"
  /usr/bin/zip -qr "$TASK_BUILD/LumaCanvas-unsigned.ipa" Payload
)
mv -f "$TASK_BUILD/LumaCanvas-unsigned.ipa" "$PROJECT_ROOT/build/LumaCanvas-unsigned.ipa"
echo "Created: $PROJECT_ROOT/build/LumaCanvas-unsigned.ipa"
echo "This IPA is unsigned. Sign it with a valid certificate and provisioning profile before installing."
