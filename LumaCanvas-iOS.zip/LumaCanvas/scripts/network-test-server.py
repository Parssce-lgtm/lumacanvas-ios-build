"""Loopback-only integration fixture: no provider, credentials or paid requests."""
import base64, gzip, json, time, threading
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlsplit, parse_qs

PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg=='
JSON = json.dumps({'data': [{'b64_json': PNG}], 'padding': '回包' * 4096}, ensure_ascii=False).encode()
RINKO = (Path(__file__).parent / 'fixtures/rinko-chat-success.json').read_bytes()
NAI = (Path(__file__).parent / 'fixtures/rinko-nai-parameters-success.json').read_bytes()
records, lock = {}, threading.Lock()

class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *_): pass
    def send(self, data, status=200, content_type='application/json', headers=None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        for key,value in (headers or {}).items(): self.send_header(key,value)
        self.end_headers(); self.wfile.write(data); self.wfile.flush()
    def do_GET(self):
        parts=urlsplit(self.path)
        if parts.path == '/health': self.send(b'{}'); return
        token=parse_qs(parts.query).get('id',[''])[0]
        with lock: value=records.get(token,[])
        self.send(json.dumps(value).encode())
    def do_POST(self):
        parts=urlsplit(self.path); token=parse_qs(parts.query).get('id',[''])[0]
        size=int(self.headers.get('Content-Length','0'))
        body=self.rfile.read(size)
        with lock:
            records.setdefault(token,[]).append({'method':'POST','bytes':size,'body':body.decode(errors='replace')})
        if parts.path == '/slow': time.sleep(12); self.send(RINKO); return
        if parts.path == '/rinko-replay': self.send(RINKO); return
        if parts.path == '/nai-replay':
            try:
                outer=json.loads(body)
                inner=json.loads(outer['messages'][0]['content'])
                assert inner['model'] == outer['model'] == 'nai-diffusion-5-full'
                assert inner['prompt'] == 'A small blue circle on a white background.'
                assert inner['size'] == [512,512] and inner['steps'] == 23 and inner['n_samples'] == 1
                assert 'moderation' not in outer
            except (AssertionError,ValueError,KeyError,TypeError):
                self.send(b'{"error":{"message":"invalid NAI protocol"}}',400); return
            self.send(NAI); return
        if parts.path == '/status504': self.send(b'{"error":{"message":"gateway timeout"}}',504); return
        if parts.path == '/empty': self.send(b''); return
        if parts.path == '/gzip': self.send(gzip.compress(JSON), headers={'Content-Encoding':'gzip'}); return
        if parts.path == '/chunked':
            self.send_response(200); self.send_header('Content-Type','text/event-stream')
            self.send_header('Transfer-Encoding','chunked'); self.end_headers()
            content='![result](data:image/png;base64,'+PNG+')'
            events=[': keepalive\n\n']+[f'data: {json.dumps({"choices":[{"index":0,"delta":{"content":fragment}}]})}\n\n' for fragment in [content[:40],content[40:]]]+['data: [DONE]\n\n']
            for event in events:
                chunk=event.encode(); self.wfile.write(f'{len(chunk):X}\r\n'.encode()+chunk+b'\r\n'); self.wfile.flush(); time.sleep(.1)
            self.wfile.write(b'0\r\n\r\n'); self.wfile.flush(); return
        self.send(JSON)

if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1',8765),Handler).serve_forever()
