#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"
mkdir -p build/Previews
TASK_SIMULATOR="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; devices=[d for _,group in sorted(json.load(sys.stdin)["devices"].items(), key=lambda pair: [int(x) for x in pair[0].split("iOS-")[-1].split("-") if x.isdigit()], reverse=True) for d in group if d.get("isAvailable") and "iPhone" in d["name"]]; assert devices; print(devices[0]["udid"])')"
xcrun simctl boot "$TASK_SIMULATOR" || true
xcrun simctl bootstatus "$TASK_SIMULATOR" -b
xcrun simctl install "$TASK_SIMULATOR" build/TestDerivedData/Build/Products/Debug-iphonesimulator/LumaCanvas.app
for appearance in light dark; do
  xcrun simctl ui "$TASK_SIMULATOR" appearance "$appearance"
  xcrun simctl terminate "$TASK_SIMULATOR" app.lumacanvas.ios || true
  xcrun simctl launch "$TASK_SIMULATOR" app.lumacanvas.ios ui-test-fixture
  sleep 10
  xcrun simctl io "$TASK_SIMULATOR" screenshot "build/Previews/$appearance.png"
  for screen in more gallery detail conversation; do
    xcrun simctl terminate "$TASK_SIMULATOR" app.lumacanvas.ios || true
    if [[ "$screen" == "conversation" ]]; then
      xcrun simctl launch "$TASK_SIMULATOR" app.lumacanvas.ios ui-test-fixture ui-preview-conversation
    elif [[ "$screen" == "detail" ]]; then
      xcrun simctl launch "$TASK_SIMULATOR" app.lumacanvas.ios ui-test-fixture ui-test-gallery ui-preview-detail
    elif [[ "$screen" == "gallery" ]]; then
      xcrun simctl launch "$TASK_SIMULATOR" app.lumacanvas.ios ui-test-fixture ui-test-gallery ui-preview-gallery
    else
      xcrun simctl launch "$TASK_SIMULATOR" app.lumacanvas.ios ui-test-fixture ui-preview-more
    fi
    sleep 10
    xcrun simctl io "$TASK_SIMULATOR" screenshot "build/Previews/$screen-$appearance.png"
  done
done
