import Foundation
import ImageIO

/// Some OpenAI-compatible gateways send SSE or heartbeat comments even when
/// stream=false. Decode the response once, without resubmitting the paid POST.
enum GenerationResponse {
    enum Payload { case image(Data), json([String: Any]) }

    static func parse(_ data: Data, response: URLResponse, apiKey: String) throws -> Payload {
        if data.count <= ImageAPIClient.maximumImageBytes,
           let source = CGImageSourceCreateWithData(data as CFData, nil),
           CGImageSourceGetCount(source) > 0 {
            return .image(data)
        }
        var text = String(data: data, encoding: .utf8) ?? ""
        if text.first == "\u{feff}" { text.removeFirst() }
        text = text.replacingOccurrences(of: "\r\n", with: "\n")
        // A non-streaming response can be prefixed with gateway keepalive lines.
        var lines = text.components(separatedBy: "\n")
        while let first = lines.first, first.isEmpty || first.hasPrefix(":") { lines.removeFirst() }
        text = lines.joined(separator: "\n")
        if let root = object(text) { return try checked(root, response: response, apiKey: apiKey) }

        if lines.contains(where: { $0.hasPrefix("data:") }) {
            var events: [String] = [], fields: [String] = []
            for line in lines + [""] {
                if line.isEmpty {
                    if !fields.isEmpty { events.append(fields.joined(separator: "\n")); fields.removeAll() }
                } else if line.hasPrefix("data:") {
                    var value = String(line.dropFirst(5))
                    if value.first == " " { value.removeFirst() }
                    fields.append(value)
                }
            }
            var content = ""
            var imageParts: [[String: Any]] = []
            var finalRoot: [String: Any]?
            for event in events where event != "[DONE]" {
                guard let root = object(event) else {
                    throw AppError.invalidResponse("流式响应不完整或格式错误，无法读取图片。请求已提交，请先检查服务商记录。")
                }
                _ = try checked(root, response: response, apiKey: apiKey)
                if root["data"] is [[String: Any]] { finalRoot = root }
                guard let choices = root["choices"] as? [[String: Any]],
                      let choice = choices.first(where: { ($0["index"] as? Int ?? 0) == 0 }) else { continue }
                if choice["message"] is [String: Any] { finalRoot = root }
                if let delta = choice["delta"] as? [String: Any] {
                    if let part = delta["content"] as? String { content += part }
                    if let parts = delta["content"] as? [[String: Any]] {
                        for part in parts {
                            if let fragment = part["text"] as? String { content += fragment }
                            if part["image_url"] != nil || part["b64_json"] != nil { imageParts.append(part) }
                        }
                    }
                    if let images = delta["images"] as? [[String: Any]] { imageParts += images }
                }
            }
            if let finalRoot { return .json(finalRoot) }
            if !content.isEmpty || !imageParts.isEmpty {
                return .json(["choices": [["message": ["content": content, "images": imageParts]]]])
            }
            throw AppError.invalidResponse("服务返回了流式响应，但没有图片内容。请求已提交，请检查模型和服务商记录。")
        }
        let http = response as? HTTPURLResponse
        let type = (http?.value(forHTTPHeaderField: "Content-Type") ?? response.mimeType ?? "未知类型")
            .components(separatedBy: ";").first ?? "未知类型"
        let format = text.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("<") ? "网页内容" : data.isEmpty ? "空内容" : "无法识别的内容"
        throw AppError.invalidResponse("服务返回\(format)（HTTP \(http?.statusCode ?? 0)，\(type)，\(data.count) 字节），不是可读取的生图结果。请求已提交，请检查服务商记录及完整接口地址。")
    }

    private static func object(_ text: String) -> [String: Any]? {
        guard let data = text.data(using: .utf8) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }

    private static func checked(_ root: [String: Any], response: URLResponse, apiKey: String) throws -> Payload {
        if let error = root["error"], !(error is NSNull) {
            var message = (error as? [String: Any])?["message"] as? String
                ?? (error as? String) ?? "服务未能生成图片。"
            let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
            if !key.isEmpty { message = message.replacingOccurrences(of: key, with: "[密钥已隐藏]") }
            throw AppError.server((response as? HTTPURLResponse)?.statusCode ?? 200, String(message.prefix(500)))
        }
        return .json(root)
    }
}
