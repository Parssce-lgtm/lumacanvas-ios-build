import Foundation

enum NetworkAccess {
    static func configure(_ configuration: URLSessionConfiguration) {
        configuration.allowsCellularAccess = true
        configuration.allowsExpensiveNetworkAccess = true
        configuration.allowsConstrainedNetworkAccess = true
        // Use iOS routing and DNS; never pin a connection to Wi-Fi, a VPN or a proxy.
        configuration.waitsForConnectivity = true
    }
    static func message(_ error: Error) -> String {
        guard let network = error as? URLError else { return error.localizedDescription }
        switch network.code {
        case .notConnectedToInternet, .dataNotAllowed:
            return "当前网络不可用。请检查系统设置中映想的无线数据权限；应用支持 Wi-Fi 和蜂窝数据。"
        case .cannotFindHost, .dnsLookupFailed, .cannotConnectToHost:
            return "无法直连 API 站点。请检查站点地址、DNS 和服务商的网络可达性；应用不会自动换站点或重发请求。"
        case .networkConnectionLost:
            return "连接已中断。若刚切换网络，请先检查服务商记录，再手动重试，避免重复提交。"
        case .secureConnectionFailed, .serverCertificateUntrusted:
            return "API 站点的 HTTPS 连接或证书异常，请检查服务商配置。"
        default: return error.localizedDescription
        }
    }
}
