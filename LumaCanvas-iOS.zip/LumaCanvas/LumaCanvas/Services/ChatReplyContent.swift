import Foundation

/// Display provider-supplied reasoning separately; unfinished tags never leak into the reply.
struct ChatReplyParts: Equatable {
    var answer = ""
    var thinking = ""
    var isThinking = false
    init(_ text: String) {
        var remaining = text[...]
        while let opening = remaining.range(of: "<think>", options: .caseInsensitive) {
            answer += remaining[..<opening.lowerBound]
            let thought = remaining[opening.upperBound...]
            if let closing = thought.range(of: "</think>", options: .caseInsensitive) {
                if !thinking.isEmpty { thinking += "\n\n" }
                thinking += thought[..<closing.lowerBound]
                remaining = thought[closing.upperBound...]
            } else {
                thinking += thought; isThinking = true; remaining = ""; break
            }
        }
        answer += remaining
        // A provider may split the opening tag across several streaming events.
        for length in stride(from: min(6, answer.count), through: 1, by: -1) {
            if "<think>".hasPrefix(answer.suffix(length).lowercased()) { answer.removeLast(length); break }
        }
        answer = answer.trimmingCharacters(in: .whitespacesAndNewlines)
        thinking = thinking.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
