import UIKit
import CoreText
import QuickLook
import SwiftUI

enum ChatDocuments {
    static func make(text: String, name: String) -> ChatAttachment {
        let safe = String(name.split(separator: "/").last ?? "文件.txt").replacingOccurrences(of: "\\", with: "_")
        if safe.lowercased().hasSuffix(".pdf") {
            let attributed = ChatFormatting.attributed(text, color: .black)
            let framesetter = CTFramesetterCreateWithAttributedString(attributed)
            let bounds = CGRect(x: 0, y: 0, width: 595, height: 842)
            let data = UIGraphicsPDFRenderer(bounds: bounds).pdfData { context in
                var start = 0
                repeat {
                    context.beginPage()
                    let cg = context.cgContext
                    cg.saveGState(); cg.translateBy(x: 0, y: bounds.height); cg.scaleBy(x: 1, y: -1)
                    let frame = CTFramesetterCreateFrame(framesetter, CFRange(location: start, length: 0), CGPath(rect: bounds.insetBy(dx: 40, dy: 40), transform: nil), nil)
                    CTFrameDraw(frame, cg); cg.restoreGState()
                    let length = CTFrameGetVisibleStringRange(frame).length
                    if length == 0 { break }; start += length
                } while start < attributed.length
            }
            return ChatAttachment(name: safe, mimeType: "application/pdf", data: data)
        }
        return ChatAttachment(name: safe.hasSuffix(".txt") ? safe : safe + ".txt", mimeType: "text/plain", data: Data(text.utf8))
    }
    /// Only closed, bounded TXT/PDF blocks become files. No model code is executed.
    static func extract(_ text: String) -> (String, [ChatAttachment]) {
        guard let regex = try? NSRegularExpression(pattern: "```file:([^\\r\\n]+\\.(?:txt|pdf))\\r?\\n([\\s\\S]*?)\\r?\\n```", options: .caseInsensitive) else { return (text, []) }
        let matches = regex.matches(in: text, range: NSRange(location: 0, length: (text as NSString).length)).prefix(4)
        var visible = text, files: [ChatAttachment] = []
        for match in matches.reversed() {
            let name = (text as NSString).substring(with: match.range(at: 1)).trimmingCharacters(in: .whitespaces)
            let content = (text as NSString).substring(with: match.range(at: 2))
            guard content.utf8.count <= 512 * 1024 else { continue }
            let file = make(text: content, name: name)
            guard (try? ChatAttachment.validate(files + [file])) != nil else { continue }
            files.insert(file, at: 0)
            if let range = Range(match.range, in: visible) { visible.replaceSubrange(range, with: "已制作文件：\(file.name)") }
        }
        return (visible, files)
    }
    static func preview(_ file: ChatAttachment) throws -> ChatDocumentPreview {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("ChatDocuments/\(file.id)", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let url = directory.appendingPathComponent(file.name.replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "\\", with: "_"))
        try file.data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        return ChatDocumentPreview(url: url)
    }
}
struct ChatDocumentPreview: Identifiable { var id = UUID(); let url: URL }
struct ChatDocumentViewer: UIViewControllerRepresentable {
    let document: ChatDocumentPreview
    func makeCoordinator() -> Coordinator { Coordinator(document.url) }
    func makeUIViewController(context: Context) -> QLPreviewController {
        let view = QLPreviewController(); view.dataSource = context.coordinator; return view
    }
    func updateUIViewController(_ view: QLPreviewController, context: Context) {}
    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let url: URL
        init(_ url: URL) { self.url = url }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem { url as NSURL }
    }
}
