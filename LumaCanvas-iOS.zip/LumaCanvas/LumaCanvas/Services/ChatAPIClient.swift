import Foundation

struct ChatMessage: Identifiable, Equatable, Codable {
    let id: UUID
    let role: String
    let text: String
    let attachments: [ChatAttachment]
    init(id: UUID = UUID(), role: String, text: String, attachments: [ChatAttachment] = []) {
        self.id = id; self.role = role; self.text = text; self.attachments = attachments
    }
    enum CodingKeys: String, CodingKey { case id, role, text, attachments }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(UUID.self, forKey: .id)
        role = try values.decode(String.self, forKey: .role)
        text = try values.decode(String.self, forKey: .text)
        attachments = try values.decodeIfPresent([ChatAttachment].self, forKey: .attachments) ?? []
    }
}

struct ChatAPIClient {
    var transport: any ImageTransport = SessionImageTransport(authenticated: true)

    func reply(configuration: APIConfiguration, messages: [ChatMessage], adultMode: Bool) async throws -> String {
        let request = try Self.request(configuration: configuration, messages: messages, adultMode: adultMode)
        let (data, response) = try await transport.receive(request, byteLimit: 4 * 1024 * 1024)
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse else { throw AppError.invalidResponse("聊天接口没有返回有效 HTTP 响应。") }
        guard (200...299).contains(http.statusCode) else {
            let message: String
            switch http.statusCode {
            case 401, 403: message = "请检查密钥及聊天模型访问权限。"
            case 404: message = "请检查聊天地址及模型名称是否正确。"
            case 429: message = "请求过于频繁或额度不足，请稍后再试。"
            case 504: message = "聊天服务超时，请稍后再试。"
            default: message = "聊天请求失败，请检查服务商状态。"
            }
            throw AppError.server(http.statusCode, message)
        }
        return try Self.responseText(data)
    }

    static func request(configuration: APIConfiguration, messages: [ChatMessage], adultMode: Bool) throws -> URLRequest {
        try configuration.validateConversation()
        guard !messages.isEmpty, messages.last?.role == "user" else {
            throw AppError.configuration("请先输入聊天内容。")
        }
        let system = adultMode
            ? "请以中文或用户使用的语言交流。用户已确认成年，可以讨论成年人健康、亲密关系及其他成熟话题。避免暴力、血腥和政治内容；遵守服务商的内容规则，不把用户确认视为绕过安全规则的授权。"
            : "请以中文或用户使用的语言友好交流，默认使用适合一般读者的表达。避免暴力、血腥和政治内容，并遵守服务商的内容规则。"
        var context: [[String: Any]] = [["role": "system", "content": system]]
        for message in messages.suffix(40) {
            try ChatAttachment.validate(message.attachments)
            if message.attachments.isEmpty { context.append(["role": message.role, "content": message.text]) }
            else {
                var parts = message.attachments.map { $0.contentPart() }
                if !message.text.isEmpty { parts.insert(["type": "text", "text": message.text], at: 0) }
                context.append(["role": message.role, "content": parts])
            }
        }
        var request = URLRequest(url: try configuration.conversationURL())
        request.httpMethod = "POST"
        request.timeoutInterval = configuration.timeout
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(configuration.apiKey.trimmingCharacters(in: .whitespacesAndNewlines))", forHTTPHeaderField: "Authorization")
        try configuration.headers().forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "model": configuration.conversationModel.trimmingCharacters(in: .whitespacesAndNewlines),
            "messages": context, "stream": false
        ])
        guard (request.httpBody?.count ?? 0) <= 32 * 1024 * 1024 else {
            throw AppError.configuration("当前对话的附件上下文过大，请开启新对话后发送。")
        }
        return request
    }

    static func responseText(_ data: Data) throws -> String {
        guard !data.isEmpty else { throw AppError.invalidResponse("聊天服务返回空内容；请求未自动重发。") }
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw AppError.invalidResponse("聊天服务没有返回 JSON，请检查完整聊天地址。")
        }
        guard let choices = root["choices"] as? [[String: Any]], let message = choices.first?["message"] as? [String: Any] else {
            throw AppError.invalidResponse("聊天响应格式不兼容，请检查模型是否支持 Chat Completions。")
        }
        let text: String
        if let string = message["content"] as? String { text = string }
        else if let parts = message["content"] as? [[String: Any]] {
            text = parts.compactMap { $0["text"] as? String }.joined(separator: "\n")
        } else if let refusal = message["refusal"] as? String { text = refusal }
        else { text = "" }
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw AppError.invalidResponse("聊天模型没有返回文字。请检查模型类型或服务商内容限制。")
        }
        return text
    }
}
