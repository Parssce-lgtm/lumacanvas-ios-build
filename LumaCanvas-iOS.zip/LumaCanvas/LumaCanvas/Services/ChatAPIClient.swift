import Foundation

protocol ChatLineTransport {
    func receiveLines(_ request: URLRequest, byteLimit: Int,
                      consume: @escaping (String) async throws -> Bool) async throws
}

extension SessionImageTransport: ChatLineTransport {
    func receiveLines(_ request: URLRequest, byteLimit: Int,
                      consume: @escaping (String) async throws -> Bool) async throws {
        let (bytes, response) = try await session.bytes(for: request)
        defer { bytes.task.cancel() }
        try ChatAPIClient.validate(response)
        var count = 0
        var line = Data()
        var previousCR = false
        for try await byte in bytes {
            count += 1
            guard count <= byteLimit else { throw AppError.invalidResponse("聊天回复过长。") }
            if byte == 10 || byte == 13 {
                if byte == 10 && previousCR { previousCR = false; continue }
                previousCR = byte == 13
                guard let value = String(data: line, encoding: .utf8) else { throw AppError.invalidResponse("聊天文字编码不兼容。") }
                line.removeAll(keepingCapacity: true)
                try Task.checkCancellation()
                let shouldStop = try await consume(value)
                if shouldStop { return }
            } else { previousCR = false; line.append(byte) }
        }
        if !line.isEmpty {
            guard let value = String(data: line, encoding: .utf8) else { throw AppError.invalidResponse("聊天文字编码不兼容。") }
            _ = try await consume(value)
        }
    }
}

/// SSE framing is independent of network chunk/UTF-8 boundaries.
struct ChatStreamDecoder {
    private var event: [String] = []
    private(set) var text = ""
    private(set) var done = false
    private(set) var finished = false
    mutating func line(_ line: String) throws -> String? {
        if line.hasPrefix("data:") {
            event.append(String(line.dropFirst(5)).trimmingCharacters(in: .whitespaces))
            return nil
        }
        guard line.isEmpty, !event.isEmpty else { return nil }
        let payload = event.joined(separator: "\n"); event.removeAll(keepingCapacity: true)
        if payload == "[DONE]" { done = true; return nil }
        guard let root = try JSONSerialization.jsonObject(with: Data(payload.utf8)) as? [String: Any] else {
            throw AppError.invalidResponse("聊天流式响应格式不兼容。")
        }
        if root["error"] != nil { throw AppError.invalidResponse("聊天服务在回复过程中返回错误，请检查服务商记录。") }
        let choice = (root["choices"] as? [[String: Any]])?.first
        if let reason = choice?["finish_reason"] as? String, !reason.isEmpty { finished = true }
        let delta = choice?["delta"] as? [String: Any] ?? [:]
        let parts = (delta["content"] as? [[String: Any]])?.compactMap { $0["text"] as? String }.joined()
        let value = delta["content"] as? String ?? parts ?? delta["refusal"] as? String ?? ""
        text += value
        return value.isEmpty ? nil : text
    }
}

struct ChatMessage: Identifiable, Equatable, Codable {
    let id: UUID
    let role: String
    let text: String
    let attachments: [ChatAttachment]
    let sourceText: String?
    init(id: UUID = UUID(), role: String, text: String, attachments: [ChatAttachment] = [], sourceText: String? = nil) {
        self.id = id; self.role = role; self.text = text; self.attachments = attachments; self.sourceText = sourceText
    }
    enum CodingKeys: String, CodingKey { case id, role, text, attachments, sourceText }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(UUID.self, forKey: .id)
        role = try values.decode(String.self, forKey: .role)
        text = try values.decode(String.self, forKey: .text)
        sourceText = try values.decodeIfPresent(String.self, forKey: .sourceText)
        attachments = try values.decodeIfPresent([ChatAttachment].self, forKey: .attachments) ?? []
    }
}

struct ChatAPIClient {
    var transport: any ImageTransport = SessionImageTransport(authenticated: true)

    func reply(configuration: APIConfiguration, messages: [ChatMessage], adultMode: Bool,
               onUpdate: @escaping @MainActor (String) -> Void = { _ in }) async throws -> String {
        let request = try Self.request(configuration: configuration, messages: messages, adultMode: adultMode)
        if let stream = transport as? any ChatLineTransport {
            var decoder = ChatStreamDecoder()
            var fallback = ""
            var sawSSE = false
            try await stream.receiveLines(request, byteLimit: 4 * 1024 * 1024) { line in
                if line.hasPrefix("data:") { sawSSE = true }
                if sawSSE {
                    if let text = try decoder.line(line) { await onUpdate(text) }
                } else if !line.hasPrefix(":") { fallback += line + "\n" }
                return decoder.done
            }
            if sawSSE {
                if let text = try decoder.line("") { await onUpdate(text) }
                guard decoder.done || decoder.finished else { throw AppError.invalidResponse("聊天连接中断，已收到的内容已保留，请手动重试。") }
                guard !decoder.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    throw AppError.invalidResponse("聊天模型没有返回文字。")
                }
                return decoder.text
            }
            // Some gateways ignore stream=true and return one JSON object. Never resend.
            let text = try Self.responseText(Data(fallback.utf8)); await onUpdate(text); return text
        }
        let (data, response) = try await transport.receive(request, byteLimit: 4 * 1024 * 1024)
        try Task.checkCancellation()
        try Self.validate(response)
        let text = try Self.responseText(data); await onUpdate(text); return text
    }

    static func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { throw AppError.invalidResponse("聊天接口没有返回有效 HTTP 响应。") }
        guard (200...299).contains(http.statusCode) else {
            let message: String
            switch http.statusCode {
            case 401, 403: message = "请检查密钥及聊天模型访问权限。"
            case 404: message = "请检查聊天地址及模型名称是否正确。"
            case 429: message = "请求过于频繁或额度不足，请稍后再试。"
            case 504: message = "聊天服务超时，请稍后再试。"
            default: message = "聊天请求失败，请检查服务商状态。"
            }
            throw AppError.server(http.statusCode, message)
        }
    }

    static func request(configuration: APIConfiguration, messages: [ChatMessage], adultMode: Bool) throws -> URLRequest {
        try configuration.validateConversation()
        guard !messages.isEmpty, messages.last?.role == "user" else {
            throw AppError.configuration("请先输入聊天内容。")
        }
        let system = adultMode
            ? "请以中文或用户使用的语言交流。用户已确认成年，可以讨论成年人健康、亲密关系及其他成熟话题。避免暴力、血腥和政治内容；遵守服务商的内容规则，不把用户确认视为绕过安全规则的授权。"
            : "请以中文或用户使用的语言友好交流，默认使用适合一般读者的表达。避免暴力、血腥和政治内容，并遵守服务商的内容规则。"
        let documents = "\n可用 Markdown 表达标题、加粗和列表。用户请求制作 TXT/PDF 文件时，使用独立代码块：```file:文件名.txt 或 ```file:文件名.pdf，换行后写完整文件内容，末尾换行并用 ``` 关闭。PDF 内容由应用排版，文件块之外简短说明。不要声称已执行程序或编造下载链接。"
        var context: [[String: Any]] = [["role": "system", "content": system + documents]]
        for message in messages.suffix(40) {
            try ChatAttachment.validate(message.attachments)
            if message.attachments.isEmpty || message.role == "assistant" { context.append(["role": message.role, "content": message.sourceText ?? message.text]) }
            else {
                var parts = message.attachments.map { $0.contentPart() }
                if !message.text.isEmpty { parts.insert(["type": "text", "text": message.text], at: 0) }
                context.append(["role": message.role, "content": parts])
            }
        }
        var request = URLRequest(url: try configuration.conversationURL())
        request.httpMethod = "POST"
        request.timeoutInterval = configuration.timeout
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("text/event-stream, application/json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(configuration.apiKey.trimmingCharacters(in: .whitespacesAndNewlines))", forHTTPHeaderField: "Authorization")
        try configuration.headers().forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "model": configuration.conversationModel.trimmingCharacters(in: .whitespacesAndNewlines),
            "messages": context, "stream": true
        ])
        guard (request.httpBody?.count ?? 0) <= 32 * 1024 * 1024 else {
            throw AppError.configuration("当前对话的附件上下文过大，请开启新对话后发送。")
        }
        return request
    }

    static func responseText(_ data: Data) throws -> String {
        guard !data.isEmpty else { throw AppError.invalidResponse("聊天服务返回空内容；请求未自动重发。") }
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw AppError.invalidResponse("聊天服务没有返回 JSON，请检查完整聊天地址。")
        }
        guard let choices = root["choices"] as? [[String: Any]], let message = choices.first?["message"] as? [String: Any] else {
            throw AppError.invalidResponse("聊天响应格式不兼容，请检查模型是否支持 Chat Completions。")
        }
        let text: String
        if let string = message["content"] as? String { text = string }
        else if let parts = message["content"] as? [[String: Any]] {
            text = parts.compactMap { $0["text"] as? String }.joined(separator: "\n")
        } else if let refusal = message["refusal"] as? String { text = refusal }
        else { text = "" }
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw AppError.invalidResponse("聊天模型没有返回文字。请检查模型类型或服务商内容限制。")
        }
        return text
    }
}
