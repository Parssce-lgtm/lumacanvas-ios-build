import Foundation
import CryptoKit

/// Rejects redirects to another origin when the request carries a credential.
/// Image downloads use an independent session with no API headers or cookies.
final class HTTPSRedirectPolicy: NSObject, URLSessionTaskDelegate {
    let authenticated: Bool
    init(authenticated: Bool) { self.authenticated = authenticated }

    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        guard let destination = request.url, destination.scheme?.lowercased() == "https" else {
            completionHandler(nil)
            return
        }
        if authenticated {
            guard let original = task.originalRequest?.url,
                  original.host?.lowercased() == destination.host?.lowercased(),
                  (original.port ?? 443) == (destination.port ?? 443) else {
                completionHandler(nil)
                return
            }
        }
        completionHandler(request)
    }
}

struct APIImageResult {
    let data: Data
    let revisedPrompt: String?
}

protocol ImageTransport {
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse)
}

final class SessionImageTransport: ImageTransport {
    private let session: URLSession
    private let authenticated: Bool

    init(authenticated: Bool) {
        self.authenticated = authenticated
        let configuration = URLSessionConfiguration.ephemeral
        NetworkAccess.configure(configuration)
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.urlCache = nil
        configuration.timeoutIntervalForResource = 660
        session = URLSession(configuration: configuration,
            delegate: HTTPSRedirectPolicy(authenticated: authenticated), delegateQueue: nil)
    }

    deinit { session.invalidateAndCancel() }

    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        if authenticated {
            let job = UUID()
            defer { BackgroundTransfers.foreground.cleanup(job: job) }
            return try await ForegroundImageTransport(job: job).receive(request, byteLimit: byteLimit)
        }
        let (file, response) = try await session.download(for: request)
        defer { try? FileManager.default.removeItem(at: file) }
        try Task.checkCancellation()
        let attributes = try FileManager.default.attributesOfItem(atPath: file.path)
        guard let bytes = attributes[.size] as? NSNumber, bytes.intValue <= byteLimit else {
            throw AppError.invalidResponse("返回内容过大，请降低图片尺寸后再试。")
        }
        return (try Data(contentsOf: file), response)
    }
}

final class ImageAPIClient {
    private let apiTransport: any ImageTransport
    private let downloadTransport: any ImageTransport
    static let maximumImageBytes = 50 * 1024 * 1024

    init(apiTransport: any ImageTransport = SessionImageTransport(authenticated: true),
         downloadTransport: any ImageTransport = SessionImageTransport(authenticated: false)) {
        self.apiTransport = apiTransport
        self.downloadTransport = downloadTransport
    }

    func generate(prompt: String, configuration: APIConfiguration, size: String, sensitivity: Sensitivity = .off, referenceData: Data? = nil, referenceImages: [Data]? = nil) async throws -> APIImageResult {
        let request = try Self.makeRequest(prompt: prompt, configuration: configuration, size: size, sensitivity: sensitivity, referenceData: referenceData, referenceImages: referenceImages)
        // Download to a temporary file so a large provider response does not grow an in-memory buffer without a bound.
        let (data, response) = try await apiTransport.receive(request, byteLimit: 80 * 1024 * 1024)
        try Task.checkCancellation()
        try Self.check(response, data: data, apiKey: configuration.apiKey)
        if data.isEmpty, let http = response as? HTTPURLResponse,
           let mode = http.value(forHTTPHeaderField: "X-Luma-Transport") {
            let transport = mode == "standard" ? "常规 POST" : "系统后台"
            let sent = http.value(forHTTPHeaderField: "X-Luma-Uploaded-Bytes") ?? "未知"
            let received = http.value(forHTTPHeaderField: "X-Luma-Received-Bytes") ?? "未知"
            let declared = http.value(forHTTPHeaderField: "X-Luma-Expected-Bytes") ?? "未知"
            let expected = declared == "-1" ? "未声明" : declared
            throw AppError.invalidResponse("返回空内容（HTTP \(http.statusCode)，0 字节）。\n请求方式：\(transport)\n已上传：\(sent) 字节；系统接收：\(received) 字节；声明长度：\(expected) 字节。\n请求未自动重发。可复制这些信息联系服务商排查；切换传输方式仅影响下一次手动生成。")
        }
        let root: [String: Any]
        switch try GenerationResponse.parse(data, response: response, apiKey: configuration.apiKey) {
        case .image(let image): return APIImageResult(data: image, revisedPrompt: nil)
        case .json(let object): root = object
        }
        let source = try Self.imageSource(root: root, mode: configuration.mode)
        let revised = source.revisedPrompt
        if let base64 = source.base64 {
            return APIImageResult(data: try Self.decodeBase64(base64), revisedPrompt: revised)
        }
        if let location = source.url {
            if location.hasPrefix("data:") {
                return APIImageResult(data: try Self.decodeBase64(location), revisedPrompt: revised)
            }
            let url = try APIConfiguration.httpsURL(location)
            var download = URLRequest(url: url)
            download.timeoutInterval = configuration.timeout
            download.setValue("image/*", forHTTPHeaderField: "Accept")
            // Never send Authorization or extra headers to image hosts, even to the same hostname.
            let (image, imageResponse) = try await downloadTransport.receive(download, byteLimit: Self.maximumImageBytes)
            try Task.checkCancellation()
            try Self.check(imageResponse, data: image, apiKey: configuration.apiKey)
            return APIImageResult(data: image, revisedPrompt: revised)
        }
        throw AppError.invalidResponse("响应中缺少 b64_json 或 url 图片字段。")
    }

    func fetchModels(configuration: APIConfiguration) async throws -> [String] {
        try await fetchModelCatalog(configuration: configuration).map(\.id)
    }

    func fetchModelCatalog(configuration: APIConfiguration) async throws -> [ModelOption] {
        try configuration.validate(requireModel: false)
        let url = try APIConfiguration.httpsURL(configuration.modelsEndpoint)
        // The model endpoint may be changed, but must have the same origin as generation.
        let endpoint = try APIConfiguration.httpsURL(configuration.endpoint)
        guard endpoint.host?.lowercased() == url.host?.lowercased(),
              (endpoint.port ?? 443) == (url.port ?? 443) else {
            throw AppError.configuration("模型列表地址与生图地址必须使用相同域名和端口。")
        }
        var request = URLRequest(url: url)
        request.timeoutInterval = min(configuration.timeout, 30)
        Self.authorize(&request, configuration: configuration)
        let (data, response) = try await apiTransport.receive(request, byteLimit: 4 * 1024 * 1024)
        try Task.checkCancellation()
        try Self.check(response, data: data, apiKey: configuration.apiKey)
        return try ModelOption.parse(data)
    }

    static func makeRequest(prompt: String, configuration: APIConfiguration, size: String, sensitivity: Sensitivity = .off, referenceData: Data? = nil, referenceImages: [Data]? = nil) throws -> URLRequest {
        try configuration.validate()
        let text = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { throw AppError.configuration("先写下你想生成的画面。") }
        let references = referenceImages ?? referenceData.map { [$0] } ?? []
        try ReferenceImageStore.validatePayload(references)
        let url = try !references.isEmpty && configuration.mode == .images
            ? configuration.referenceEndpoint() : APIConfiguration.httpsURL(configuration.endpoint)
        var body = try APIConfiguration.jsonObject(configuration.extraBody, label: "额外请求参数")
        body["model"] = configuration.model.trimmingCharacters(in: .whitespacesAndNewlines)
        let actualSize = size.trimmingCharacters(in: .whitespacesAndNewlines)
        if configuration.mode == .images {
            body["prompt"] = text
            body["n"] = 1
            if !actualSize.isEmpty { body["size"] = actualSize }
            let quality = configuration.quality.trimmingCharacters(in: .whitespacesAndNewlines)
            if !quality.isEmpty { body["quality"] = quality }
            if !configuration.responseFormat.isEmpty { body["response_format"] = configuration.responseFormat }
        } else if configuration.usesNAIParameters {
            // BestNAI requires the first user content to be a JSON STRING, not
            // a prose instruction or a Chat Completions image_url array.
            guard references.isEmpty else {
                throw AppError.configuration("NAI 参数接口的参考图协议与普通图片消息不同。本版参数模式支持文生图；请移除参考图，或在确认服务商支持后选择普通文字格式。")
            }
            if !configuration.model.lowercased().contains("nai-diffusion-5"), text.unicodeScalars.contains(where: {
                (0x3400...0x9FFF).contains($0.value) || (0x3040...0x30FF).contains($0.value) || (0xAC00...0xD7AF).contains($0.value)
            }) {
                throw AppError.configuration("NAI 4.5 参数接口不接受中日韩提示词，请改用英文标签，或选择支持这些语言的 NAI 5 模型。请求尚未提交。")
            }
            let extraNAI = body.removeValue(forKey: "nai")
            if let extraNAI, !(extraNAI is [String: Any]) {
                throw AppError.configuration("额外参数中的 nai 须为 JSON 对象。")
            }
            var parameters = (extraNAI as? [String: Any]) ?? [:]
            parameters["model"] = configuration.model.trimmingCharacters(in: .whitespacesAndNewlines)
            parameters["prompt"] = text
            parameters["n_samples"] = 1
            if !actualSize.isEmpty, actualSize != "auto" {
                let dimensions = actualSize.lowercased().split(separator: "x").compactMap { Int($0) }
                guard dimensions.count == 2, dimensions.allSatisfy({ (64...2048).contains($0) && $0 % 64 == 0 }),
                      dimensions[0] * dimensions[1] <= 3_145_728 else {
                    throw AppError.configuration("NAI 尺寸须为 64 的倍数，边长 64～2048。请使用自动尺寸，或在设置中填写如 832x1216。")
                }
                parameters["size"] = dimensions
            }
            if parameters["steps"] == nil { parameters["steps"] = 23 }
            if parameters["scale"] == nil { parameters["scale"] = 5 }
            if parameters["sampler"] == nil { parameters["sampler"] = "k_euler_ancestral" }
            if parameters["noise_schedule"] == nil { parameters["noise_schedule"] = "karras" }
            if parameters["quality"] == nil { parameters["quality"] = true }
            if parameters["uc_preset"] == nil { parameters["uc_preset"] = "light" }
            let encoded = try JSONSerialization.data(withJSONObject: parameters, options: .sortedKeys)
            body["messages"] = [["role": "user", "content": String(decoding: encoded, as: UTF8.self)]]
            body["stream"] = configuration.chatStreaming
        } else {
            let hint = actualSize.isEmpty || actualSize == "auto" ? "" : "\n图片尺寸偏好：\(actualSize)（以模型支持的画幅为准）。"
            let message = text + "\n请根据描述生成图片并返回图片。" + hint
            if !references.isEmpty {
                var parts: [[String: Any]] = [["type": "text", "text": message]]
                parts += references.map { ["type": "image_url", "image_url": ["url": "data:image/png;base64," + $0.base64EncodedString()]] }
                body["messages"] = [["role": "user", "content": parts]]
            } else { body["messages"] = [["role": "user", "content": message]] }
            body["stream"] = configuration.chatStreaming
        }
        // Provider extension in Chat Completions; never claim this bypasses
        // provider rules or retry a paid request when the parameter is rejected.
        if !configuration.usesNAIParameters, let moderation = sensitivity.parameter { body["moderation"] = moderation }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = configuration.timeout
        if !references.isEmpty, configuration.mode == .images {
            // Deterministic encoding is necessary to rejoin the same background
            // upload after relaunch rather than submitting a second paid job.
            // Preserve the original single-image encoding for already-submitted jobs.
            var digest = SHA256()
            for image in references { digest.update(data: image) }
            let boundary = "LumaCanvas-" + digest.finalize().prefix(12).map { String(format: "%02x", $0) }.joined()
            var multipart = Data()
            for key in body.keys.sorted() {
                guard !key.contains("\""), !key.contains("\r"), !key.contains("\n"), !key.contains("\\") else {
                    throw AppError.configuration("额外参数名称不能包含引号或换行。")
                }
                let value = body[key]!
                let encoded: String
                if let string = value as? String { encoded = string }
                else {
                    encoded = String(decoding: try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys, .fragmentsAllowed]), as: UTF8.self)
                }
                multipart.append(Data("--\(boundary)\r\nContent-Disposition: form-data; name=\"\(key)\"\r\n\r\n\(encoded)\r\n".utf8))
            }
            for (index, image) in references.enumerated() {
                let name = references.count == 1 ? "reference.png" : "reference-\(index + 1).png"
                multipart.append(Data("--\(boundary)\r\nContent-Disposition: form-data; name=\"image[]\"; filename=\"\(name)\"\r\nContent-Type: image/png\r\n\r\n".utf8))
                multipart.append(image)
                multipart.append(Data("\r\n".utf8))
            }
            multipart.append(Data("--\(boundary)--\r\n".utf8))
            request.httpBody = multipart
            request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        } else {
            request.httpBody = try JSONSerialization.data(withJSONObject: body, options: .sortedKeys)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        request.setValue(String(request.httpBody?.count ?? 0), forHTTPHeaderField: "Content-Length")
        authorize(&request, configuration: configuration)
        return request
    }

    private struct ImageSource {
        var base64: String?
        var url: String?
        var revisedPrompt: String?
    }

    private static func imageSource(root: [String: Any], mode: GenerationMode) throws -> ImageSource {
        if let rows = root["data"] as? [[String: Any]], let first = rows.first,
           let source = sourceInObject(first) {
            return ImageSource(base64: source.base64, url: source.url, revisedPrompt: first["revised_prompt"] as? String)
        }
        if mode == .chatCompletions,
           let choices = root["choices"] as? [[String: Any]],
           let message = choices.first?["message"] as? [String: Any] {
            if let images = message["images"] as? [[String: Any]] {
                for image in images { if let source = sourceInObject(image) { return source } }
            }
            if let parts = message["content"] as? [[String: Any]] {
                for part in parts {
                    if let source = sourceInObject(part) { return source }
                    if let text = part["text"] as? String, let source = sourceInText(text) { return source }
                }
            }
            if let text = message["content"] as? String, let source = sourceInText(text) { return source }
            throw AppError.invalidResponse("该接口只返回了文字，没有可识别的图片。请选择生图模型，或切换“标准 Images”接口模式。")
        }
        if root["task_id"] != nil || (root["id"] != nil && root["choices"] == nil) {
            throw AppError.invalidResponse("该模型返回异步任务。本版本支持同步接口，请选择同步生图模型。")
        }
        throw AppError.invalidResponse("响应中没有图片。请检查模型与接口模式；支持 data 图片数组或对话中的图片内容。")
    }

    private static func sourceInObject(_ object: [String: Any]) -> ImageSource? {
        if let base64 = object["b64_json"] as? String, !base64.isEmpty { return ImageSource(base64: base64) }
        if let url = object["url"] as? String, !url.isEmpty { return ImageSource(url: url) }
        if let image = object["image_url"] as? [String: Any], let url = image["url"] as? String, !url.isEmpty {
            return ImageSource(url: url)
        }
        if let url = object["image_url"] as? String, !url.isEmpty { return ImageSource(url: url) }
        return nil
    }

    private static func sourceInText(_ text: String) -> ImageSource? {
        let source = text.trimmingCharacters(in: .whitespacesAndNewlines)
        // Only image Markdown and explicit Data URLs are extracted. Ordinary prose hyperlinks are not image results.
        let pattern = #"!\[[^\]]*\]\(\s*<?(data:image/[A-Za-z0-9.+-]+;base64,[A-Za-z0-9+/=]+|https://[^\s)<>]+)>?\s*\)"#
        if let expression = try? NSRegularExpression(pattern: pattern),
           let match = expression.firstMatch(in: source, range: NSRange(source.startIndex..., in: source)),
           let range = Range(match.range(at: 1), in: source) {
            return ImageSource(url: String(source[range]))
        }
        if source.hasPrefix("data:image/"), source.contains(";base64,") { return ImageSource(url: source) }
        if let url = URL(string: source), url.scheme == "https", url.host != nil,
           !source.contains(where: { $0.isWhitespace }) { return ImageSource(url: source) }
        return nil
    }

    private static func authorize(_ request: inout URLRequest, configuration: APIConfiguration) {
        request.setValue("Bearer \(configuration.apiKey.trimmingCharacters(in: .whitespacesAndNewlines))", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        // These headers have already been validated before this function is reached.
        if let headers = try? configuration.headers() {
            headers.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        }
    }

    static func decodeBase64(_ value: String) throws -> Data {
        var source = value
        if source.hasPrefix("data:") {
            guard let comma = source.firstIndex(of: ","), source[..<comma].hasSuffix(";base64") else {
                throw AppError.invalidResponse("图片 Data URL 的格式不正确。")
            }
            source = String(source[source.index(after: comma)...])
        }
        source = source.components(separatedBy: .whitespacesAndNewlines).joined()
        guard source.utf8.count <= ((maximumImageBytes + 2) / 3) * 4,
              let data = Data(base64Encoded: source), !data.isEmpty,
              data.count <= maximumImageBytes else {
            throw AppError.invalidResponse("图片 Base64 无效或图片超过 50 MB。")
        }
        return data
    }

    static func check(_ response: URLResponse, data: Data, apiKey: String) throws {
        guard let http = response as? HTTPURLResponse else {
            throw AppError.invalidResponse("无法读取服务器状态。")
        }
        guard (200...299).contains(http.statusCode) else {
            let fallback: String
            switch http.statusCode {
            case 401, 403: fallback = "请检查 API Key、模型权限和令牌分组。"
            case 404: fallback = "接口或模型不存在，请检查完整请求地址和模型名。"
            case 429: fallback = "请求受限或余额不足，请稍后再试并检查账户。"
            case 504: fallback = "服务网关等待模型超时。对话式接口可在设置中开启“流式返回”后手动再试；如果仍报 504，请检查服务商状态。延长 App 超时不能延长服务网关超时。请求不会自动重发。"
            case 300...399: fallback = "接口发生重定向，请填写最终的 HTTPS 接口地址。"
            default: fallback = "服务暂时不可用，请稍后再试。"
            }
            var message = fallback
            if let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                if let error = root["error"] as? [String: Any], let text = error["message"] as? String {
                    message = text
                } else if let text = root["message"] as? String, !text.isEmpty { message = text }
            }
            let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
            if !key.isEmpty { message = message.replacingOccurrences(of: key, with: "[密钥已隐藏]") }
            throw AppError.server(http.statusCode, String(message.prefix(500)))
        }
    }
}
