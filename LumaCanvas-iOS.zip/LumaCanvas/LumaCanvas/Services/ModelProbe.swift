import Foundation
import UIKit
import SwiftUI

@MainActor
final class ModelTestStore: ObservableObject {
    struct Record {
        let configuration: APIConfiguration
        var running = true
        var result: ModelProbeResult?
    }
    @Published private(set) var records: [UUID: Record] = [:]
    private var tasks: [UUID: Task<Void, Never>] = [:]
    private var jobs: [UUID: UUID] = [:]
    private var backgroundTokens: [UUID: UIBackgroundTaskIdentifier] = [:]

    func start(_ configuration: APIConfiguration, client suppliedClient: ImageAPIClient? = nil) {
        let instance = configuration.id
        guard tasks[instance] == nil else { return }
        let job = UUID(); jobs[instance] = job
        records[instance] = Record(configuration: configuration)
        backgroundTokens[instance] = UIApplication.shared.beginBackgroundTask(withName: "测试模型") { [weak self] in
            Task { @MainActor in self?.endBackgroundTime(instance) }
        }
        let transport: any ImageTransport = configuration.transfer == .standard
            ? ForegroundImageTransport(job: job) : BackgroundImageTransport(job: job)
        let client = suppliedClient ?? ImageAPIClient(apiTransport: transport, downloadTransport: transport)
        tasks[instance] = Task { @MainActor [weak self] in
            guard let self else { return }
            defer {
                if self.jobs[instance] == job {
                    self.tasks[instance] = nil; self.jobs[instance] = nil; self.endBackgroundTime(instance)
                    self.records[instance]?.running = false
                }
                BackgroundTransfers.shared.cleanup(job: job)
                BackgroundTransfers.foreground.cleanup(job: job)
            }
            do {
                let result = try await ModelProbe(client: client).test(configuration: configuration)
                try Task.checkCancellation()
                guard self.jobs[instance] == job else { return }
                self.records[instance]?.result = result
            } catch is CancellationError { }
            catch { if self.jobs[instance] == job { self.records[instance]?.result = ModelProbe.failure(error) } }
        }
    }
    func cancel(_ instance: UUID) {
        tasks[instance]?.cancel(); tasks[instance] = nil; jobs[instance] = nil
        records[instance]?.running = false
        records[instance]?.result = .init(status: .unavailable, detail: "已停止等待；服务端可能仍在处理，不会自动重发。")
        endBackgroundTime(instance)
    }
    private func endBackgroundTime(_ instance: UUID) {
        if let token = backgroundTokens.removeValue(forKey: instance), token != .invalid { UIApplication.shared.endBackgroundTask(token) }
    }
}

struct ModelProbeResult: Equatable {
    enum Status { case available, invalidModel, unavailable, timeout, invalidConfiguration }
    var status: Status
    var detail: String
    var title: String {
        switch status {
        case .available: return "可用"
        case .invalidModel: return "请检查模型是否正确"
        case .unavailable: return "不可用"
        case .timeout: return "超时"
        case .invalidConfiguration: return "请检查 API 设置"
        }
    }
}

struct ModelProbe {
    var client = ImageAPIClient()
    var timeoutOverride: Double? = nil

    func test(configuration: APIConfiguration) async throws -> ModelProbeResult {
        do {
            if configuration.model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                return .init(status: .invalidModel, detail: "请填写要测试的模型名称。")
            }
            try configuration.validate()
            let deadline = timeoutOverride ?? configuration.timeout
            let result = try await withThrowingTaskGroup(of: APIImageResult.self) { group in
                group.addTask {
                    try await client.generate(prompt: configuration.isNAIModel ? "A simple blue circle on a white background." : "生成一张简单的蓝色圆形图标，白色背景。",
                        configuration: configuration, size: configuration.size)
                }
                group.addTask {
                    try await Task.sleep(nanoseconds: UInt64(max(0.001, deadline) * 1_000_000_000))
                    throw URLError(.timedOut)
                }
                defer { group.cancelAll() }
                guard let first = try await group.next() else { throw URLError(.badServerResponse) }
                return first
            }
            try Task.checkCancellation()
            guard UIImage(data: result.data)?.cgImage != nil else {
                return .init(status: .unavailable, detail: "服务返回的内容无法解码为图片，请检查模型、接口模式和返回格式。")
            }
            return .init(status: .available, detail: "当前模型已成功返回图片。测试不替换主页面作品。")
        } catch is CancellationError { throw CancellationError() }
        catch let error as URLError where error.code == .cancelled { throw CancellationError() }
        catch { return Self.failure(error) }
    }

    static func failure(_ error: Error) -> ModelProbeResult {
        if let error = error as? URLError, error.code == .timedOut {
            return .init(status: .timeout, detail: "在设定时间内未获得图片；服务端可能仍在处理，不会自动重新提交。")
        }
        if let error = error as? AppError {
            switch error {
            case .configuration(let message):
                return .init(status: .invalidConfiguration, detail: message)
            case .server(let code, let message):
                if code == 408 || code == 504 { return .init(status: .timeout, detail: message) }
                let text = message.lowercased()
                let invalidModel = ["model_not_found", "invalid_model", "unknown model", "model does not exist", "model not found",
                    "no such model", "unrecognized model", "模型不存在", "无效模型", "模型名称错误"].contains(where: text.contains)
                if code == 404 || invalidModel {
                    return .init(status: .invalidModel, detail: "也请核对接口地址。\n" + message)
                }
                return .init(status: .unavailable, detail: message)
            default: break
            }
        }
        return .init(status: .unavailable, detail: error.localizedDescription)
    }
}
