import Foundation
import UIKit
import ImageIO

struct ReferenceImage: Codable, Equatable {
    var id: UUID
    var name: String
}

enum ReferenceImageStore {
    static let maximumInputBytes = 50 * 1024 * 1024
    static let maximumCount = 8
    static let maximumTotalBytes = 40 * 1024 * 1024

    static func validatePayload(_ images: [Data]) throws {
        guard images.count <= maximumCount else { throw AppError.configuration("最多选择 8 张参考图。") }
        guard images.allSatisfy({ !$0.isEmpty && $0.count <= 20 * 1024 * 1024 }),
              images.reduce(0, { $0 + $1.count }) <= maximumTotalBytes else {
            throw AppError.configuration("参考图无效或过大：每张处理后不超过 20 MB，总计不超过 40 MB。")
        }
    }

    static func read(_ images: [ReferenceImage]) throws -> [Data] {
        try images.map { image in
            guard let data = try read(Optional(image)) else { throw AppError.storage("参考图缓存无法读取，请重新选择。") }
            return data
        }
    }

    static func readFile(_ url: URL) throws -> Data {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let size = try url.resourceValues(forKeys: [.fileSizeKey, .isDirectoryKey])
        guard size.isDirectory != true, let count = size.fileSize,
              count > 0, count <= maximumInputBytes else {
            throw AppError.configuration("请选择不超过 50 MB 的图片文件。")
        }
        return try Data(contentsOf: url, options: .mappedIfSafe)
    }
    static func url(for image: ReferenceImage) throws -> URL {
        let directory = try FileManager.default.url(for: .applicationSupportDirectory,
            in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("References", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent(image.id.uuidString + ".png")
    }
    static func normalizedData(_ data: Data) throws -> Data {
        guard !data.isEmpty, data.count <= maximumInputBytes,
              let source = CGImageSourceCreateWithData(data as CFData, nil),
              let thumbnail = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 2048
              ] as CFDictionary) else {
            throw AppError.configuration("请选择可读取的图片文件，原文件不能超过 50 MB。")
        }
        let preview = UIImage(cgImage: thumbnail)
        guard let png = preview.pngData(), png.count <= 20 * 1024 * 1024 else {
            throw AppError.configuration("参考图过大，请选择较小的图片。")
        }
        return png
    }
    static func save(_ data: Data, name: String) throws -> (ReferenceImage, UIImage) {
        let png = try normalizedData(data)
        guard let preview = UIImage(data: png) else { throw AppError.configuration("无法读取参考图。") }
        let image = ReferenceImage(id: UUID(), name: name)
        try png.write(to: url(for: image), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        return (image, preview)
    }
    static func read(_ image: ReferenceImage?) throws -> Data? {
        guard let image else { return nil }
        let file = try url(for: image)
        guard let size = try FileManager.default.attributesOfItem(atPath: file.path)[.size] as? NSNumber,
              size.intValue <= 20 * 1024 * 1024 else {
            throw AppError.storage("参考图缓存无法读取，请重新选择图片。")
        }
        return try Data(contentsOf: file)
    }
    static func remove(_ image: ReferenceImage?) {
        if let image, let file = try? url(for: image) { try? FileManager.default.removeItem(at: file) }
    }
}
