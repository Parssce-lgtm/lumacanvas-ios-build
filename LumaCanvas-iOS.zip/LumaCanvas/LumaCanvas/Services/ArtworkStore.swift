import Foundation
import UIKit
import ImageIO

extension Notification.Name {
    static let artworkGalleryChanged = Notification.Name("app.lumacanvas.gallery.changed")
}

/// Listing loads small metadata; opening an item loads that image's full PNG.
actor ArtworkStore {
    static let shared = ArtworkStore()
    private let root: URL?
    init(root: URL? = nil) { self.root = root }

    private func folder() throws -> URL {
        let directory = try root ?? FileManager.default.url(for: .applicationSupportDirectory,
            in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("LumaCanvas", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true,
            attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
        return directory
    }
    private func gallery() throws -> URL {
        let path = try folder().appendingPathComponent("Gallery", isDirectory: true)
        try FileManager.default.createDirectory(at: path, withIntermediateDirectories: true,
            attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
        return path
    }
    private func preserve(_ artwork: GeneratedArtwork) throws {
        let directory = try gallery()
        let name = artwork.id.uuidString
        let metadata = directory.appendingPathComponent(name + ".json")
        let png = directory.appendingPathComponent(name + ".png")
        if FileManager.default.fileExists(atPath: metadata.path), FileManager.default.fileExists(atPath: png.path) { return }
        guard let source = CGImageSourceCreateWithData(artwork.pngData as CFData, nil),
              CGImageSourceGetCount(source) > 0 else { throw AppError.storage("图片无法保存到图库。") }
        try artwork.pngData.write(to: png, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        if let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: 360
        ] as CFDictionary), let data = UIImage(cgImage: image).jpegData(compressionQuality: 0.78) {
            try data.write(to: directory.appendingPathComponent(name + "-preview.jpg"),
                options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        }
        try JSONEncoder().encode(ArtworkSummary(artwork)).write(to: metadata,
            options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
    func save(_ artwork: GeneratedArtwork) throws {
        try preserve(artwork)
        let encoder = PropertyListEncoder(); encoder.outputFormat = .binary
        try encoder.encode(artwork).write(to: folder().appendingPathComponent("latest-artwork.plist"),
            options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        NotificationCenter.default.post(name: .artworkGalleryChanged, object: nil)
    }
    func load() throws -> GeneratedArtwork? {
        let url = try folder().appendingPathComponent("latest-artwork.plist")
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        let artwork = try PropertyListDecoder().decode(GeneratedArtwork.self, from: Data(contentsOf: url))
        try preserve(artwork)
        return artwork
    }
    func list() throws -> [ArtworkSummary] {
        _ = try? load()
        let directory = try gallery()
        return try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
            .filter { $0.pathExtension == "json" }
            .compactMap { url -> ArtworkSummary? in
                guard let data = try? Data(contentsOf: url),
                      let item = try? JSONDecoder().decode(ArtworkSummary.self, from: data),
                      FileManager.default.fileExists(atPath: directory.appendingPathComponent(item.id.uuidString + ".png").path) else { return nil }
                return item
            }.sorted { $0.createdAt == $1.createdAt ? $0.id.uuidString > $1.id.uuidString : $0.createdAt > $1.createdAt }
    }
    func thumbnail(_ id: UUID) throws -> Data? {
        let url = try gallery().appendingPathComponent(id.uuidString + "-preview.jpg")
        return FileManager.default.fileExists(atPath: url.path) ? try Data(contentsOf: url) : nil
    }
    func delete(_ id: UUID) throws {
        let latest = try folder().appendingPathComponent("latest-artwork.plist")
        let latestArtwork = (try? Data(contentsOf: latest)).flatMap { try? PropertyListDecoder().decode(GeneratedArtwork.self, from: $0) }
        // Clear the legacy latest cache first so list()/load() cannot recreate a deleted item.
        if latestArtwork?.id == id { try FileManager.default.removeItem(at: latest) }
        let directory = try gallery()
        for suffix in [".json", ".png", "-preview.jpg"] {
            let file = directory.appendingPathComponent(id.uuidString + suffix)
            if FileManager.default.fileExists(atPath: file.path) { try FileManager.default.removeItem(at: file) }
        }
        if latestArtwork?.id == id, let remaining = try list().first {
            try save(artwork(remaining.id))
        }
        NotificationCenter.default.post(name: .artworkGalleryChanged, object: nil)
    }
    func artwork(_ id: UUID) throws -> GeneratedArtwork {
        let directory = try gallery()
        let item = try JSONDecoder().decode(ArtworkSummary.self,
            from: Data(contentsOf: directory.appendingPathComponent(id.uuidString + ".json")))
        let png = try Data(contentsOf: directory.appendingPathComponent(id.uuidString + ".png"))
        guard UIImage(data: png) != nil else { throw AppError.storage("图库图片无法读取。") }
        return item.artwork(png: png)
    }
}
