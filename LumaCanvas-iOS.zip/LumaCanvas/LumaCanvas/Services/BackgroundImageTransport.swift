import Foundation
import CryptoKit
import UIKit

struct PendingGeneration: Codable {
    var id: UUID
    var prompt: String
    var size: String
    var sensitivity: Sensitivity
    var configuration: APIConfiguration
    var startedAt: Date
    var reference: ReferenceImage? = nil
    var references: [ReferenceImage]? = nil
    var transfer: GenerationTransfer? = nil
    var draftID: UUID? = nil
    // Existing submitted jobs must rejoin their original background session.
    var resolvedTransfer: GenerationTransfer { transfer ?? .background }
    var allReferences: [ReferenceImage] { references ?? reference.map { [$0] } ?? [] }
    static func load() throws -> Self? {
        guard let data = try KeychainStore.readData(account: "pending-generation-v2") else { return nil }
        return try JSONDecoder().decode(Self.self, from: data)
    }
    func save() throws { try KeychainStore.writeData(JSONEncoder().encode(self), account: "pending-generation-v2") }
    static func clear() throws { try KeychainStore.writeData(nil, account: "pending-generation-v2") }
}

final class BackgroundImageTransport: ImageTransport {
    let job: UUID
    init(job: UUID) { self.job = job }
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        try Task.checkCancellation()
        return try await withTaskCancellationHandler(operation: {
            try await BackgroundTransfers.shared.receive(request, job: job, byteLimit: byteLimit)
        }, onCancel: { BackgroundTransfers.shared.cancel(job: self.job) })
    }
}

final class ForegroundImageTransport: ImageTransport {
    let job: UUID
    init(job: UUID) { self.job = job }
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        try Task.checkCancellation()
        return try await withTaskCancellationHandler(operation: {
            try await BackgroundTransfers.foreground.receive(request, job: job, byteLimit: byteLimit)
        }, onCancel: { BackgroundTransfers.foreground.cancel(job: self.job) })
    }
}

/// File-backed uploads and downloads continue while iOS suspends the UI. Responses
/// are durable, so relaunching rejoins an existing task instead of repeating a POST.
final class BackgroundTransfers: NSObject, URLSessionDataDelegate, URLSessionDownloadDelegate {
    static let shared = BackgroundTransfers(background: true)
    static let foreground = BackgroundTransfers(background: false)
    static let identifier = "app.lumacanvas.ios.render.v2"
    private let queue = DispatchQueue(label: "app.lumacanvas.background-storage")
    private var waiters: [String: CheckedContinuation<(Data, URLResponse), Error>] = [:]
    private var cancelled = Set<UUID>()
    private let directory: URL
    private let background: Bool
    var completionHandler: (() -> Void)?
    private var session: URLSession!

    private struct Receipt: Codable {
        var url: String
        var status: Int
        var headers: [String: String]
        var error: String?
        var transport: String? = nil
        var uploaded: Int64? = nil
        var received: Int64? = nil
        var expected: Int64? = nil
    }

    private init(background: Bool) {
        self.background = background
        directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(background ? "BackgroundTransfers" : "StandardTransfers", isDirectory: true)
        super.init()
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true,
            attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
        let config = background ? URLSessionConfiguration.background(withIdentifier: Self.identifier) : .ephemeral
        if background {
            config.isDiscretionary = false
            config.sessionSendsLaunchEvents = true
        }
        config.waitsForConnectivity = true
        config.timeoutIntervalForResource = 660
        config.httpCookieStorage = nil
        config.httpShouldSetCookies = false
        config.urlCache = nil
        let delegates = OperationQueue()
        delegates.maxConcurrentOperationCount = 1
        session = URLSession(configuration: config, delegate: self, delegateQueue: delegates)
    }

    private func file(_ key: String, _ suffix: String) -> URL {
        directory.appendingPathComponent(key + "." + suffix)
    }
    private func cache(_ key: String) throws -> (Data, URLResponse)? {
        let receiptFile = file(key, "receipt")
        guard FileManager.default.fileExists(atPath: receiptFile.path) else { return nil }
        let receipt = try JSONDecoder().decode(Receipt.self, from: Data(contentsOf: receiptFile))
        if let error = receipt.error { throw AppError.invalidResponse(error) }
        var headers = receipt.headers
        headers["X-Luma-Transport"] = receipt.transport ?? "background"
        if let value = receipt.uploaded { headers["X-Luma-Uploaded-Bytes"] = String(value) }
        if let value = receipt.received { headers["X-Luma-Received-Bytes"] = String(value) }
        if let value = receipt.expected { headers["X-Luma-Expected-Bytes"] = String(value) }
        guard let url = URL(string: receipt.url),
              let response = HTTPURLResponse(url: url, statusCode: receipt.status, httpVersion: nil, headerFields: headers) else {
            throw AppError.invalidResponse("后台响应无法恢复。")
        }
        return (try Data(contentsOf: file(key, "response")), response)
    }

    func receive(_ request: URLRequest, job: UUID, byteLimit: Int) async throws -> (Data, URLResponse) {
        var fingerprint = Data((request.url!.absoluteString + (request.httpMethod ?? "GET")).utf8)
        fingerprint.append(request.httpBody ?? Data())
        fingerprint.append(Data((request.value(forHTTPHeaderField: "Authorization") ?? "").utf8))
        let hash = SHA256.hash(data: fingerprint).map { String(format: "%02x", $0) }.joined()
        let key = job.uuidString + "-" + hash
        return try await withCheckedThrowingContinuation { continuation in
            session.getAllTasks { tasks in
                self.queue.async {
                    do {
                        guard !self.cancelled.contains(job) else { throw CancellationError() }
                        if let result = try self.cache(key) { continuation.resume(returning: result); return }
                        guard self.waiters[key] == nil else { throw AppError.invalidResponse("已有生成任务正在等待。") }
                        self.waiters[key] = continuation
                        if let existing = tasks.first(where: { $0.taskDescription?.hasPrefix(key + "|") == true }) {
                            existing.resume()
                            return
                        }
                        // A durable marker prevents accidentally resubmitting a paid POST
                        // if the OS no longer has its task and no response was delivered.
                        let marker = self.file(key, "submitted")
                        if FileManager.default.fileExists(atPath: marker.path) {
                            self.waiters.removeValue(forKey: key)
                            throw AppError.invalidResponse("上次请求已提交，但系统未保留响应。请检查服务商记录后再生成，避免重复计费。")
                        }
                        var upload = request
                        let task: URLSessionTask
                        if !self.background {
                            // A regular POST data task retains httpBody. Never convert
                            // or resubmit a failed background upload as another POST.
                            task = self.session.dataTask(with: request)
                        } else if let body = request.httpBody {
                            let bodyFile = self.file(key, "request")
                            try body.write(to: bodyFile, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
                            upload.httpBody = nil
                            task = self.session.uploadTask(with: upload, fromFile: bodyFile)
                        } else { task = self.session.downloadTask(with: request) }
                        task.taskDescription = key + "|" + String(byteLimit)
                        try Data().write(to: marker, options: .atomic)
                        task.resume()
                    } catch {
                        self.waiters.removeValue(forKey: key)
                        continuation.resume(throwing: error)
                    }
                }
            }
        }
    }

    func cancel(job: UUID) {
        queue.async { self.cancelled.insert(job) }
        session.getAllTasks { tasks in
            tasks.filter { $0.taskDescription?.hasPrefix(job.uuidString + "-") == true }.forEach { $0.cancel() }
        }
    }
    func cleanup(job: UUID) {
        queue.async {
            if let files = try? FileManager.default.contentsOfDirectory(at: self.directory, includingPropertiesForKeys: nil) {
                for url in files where url.lastPathComponent.hasPrefix(job.uuidString + "-") { try? FileManager.default.removeItem(at: url) }
            }
        }
    }
    private func identity(_ task: URLSessionTask) -> (String, Int)? {
        guard let description = task.taskDescription else { return nil }
        let pieces = description.split(separator: "|")
        guard pieces.count == 2, let limit = Int(pieces[1]) else { return nil }
        return (String(pieces[0]), limit)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let (_, limit) = identity(dataTask), response.expectedContentLength <= Int64(limit) else {
            completionHandler(.cancel); return
        }
        if !background {
            guard let (key, _) = identity(dataTask) else { completionHandler(.cancel); return }
            do {
                try queue.sync {
                    try Data().write(to: file(key, "response"), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
                }
                completionHandler(.allow)
            } catch { completionHandler(.cancel) }
            return
        }
        // Let the system own the response body as a download file. Upload data
        // callbacks alone are not a durable response store after suspension.
        // This converts the SAME request; it does not issue another paid POST.
        completionHandler(.becomeDownload)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didBecome downloadTask: URLSessionDownloadTask) {
        downloadTask.taskDescription = dataTask.taskDescription
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        guard let destination = request.url, destination.scheme?.lowercased() == "https" else {
            completionHandler(nil); return
        }
        if task.originalRequest?.value(forHTTPHeaderField: "Authorization") != nil {
            guard let original = task.originalRequest?.url,
                  original.host?.lowercased() == destination.host?.lowercased(),
                  (original.port ?? 443) == (destination.port ?? 443),
                  request.httpMethod == task.originalRequest?.httpMethod else {
                completionHandler(nil); return
            }
        }
        completionHandler(request)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        if let (_, limit) = identity(downloadTask), totalBytesWritten > Int64(limit) {
            downloadTask.cancel()
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard let (key, limit) = identity(dataTask) else { return }
        queue.sync {
            let url = file(key, "response")
            if !FileManager.default.fileExists(atPath: url.path) {
                FileManager.default.createFile(atPath: url.path, contents: nil,
                    attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
            }
            do {
                let handle = try FileHandle(forWritingTo: url)
                defer { try? handle.close() }
                let count = try handle.seekToEnd()
                guard count + UInt64(data.count) <= UInt64(limit) else { dataTask.cancel(); return }
                try handle.write(contentsOf: data)
            } catch { dataTask.cancel() }
        }
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let (key, limit) = identity(downloadTask) else { return }
        queue.sync {
            do {
                let attributes = try FileManager.default.attributesOfItem(atPath: location.path)
                guard ((attributes[.size] as? NSNumber)?.intValue ?? Int.max) <= limit else { downloadTask.cancel(); return }
                let destination = file(key, "response")
                try? FileManager.default.removeItem(at: destination)
                try FileManager.default.copyItem(at: location, to: destination)
                try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: destination.path)
            } catch { downloadTask.cancel() }
        }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let (key, _) = identity(task) else { return }
        queue.async {
            let http = task.response as? HTTPURLResponse
            let headers = http?.allHeaderFields.reduce(into: [String: String]()) { result, pair in
                if let name = pair.key as? String { result[name] = String(describing: pair.value) }
            } ?? [:]
            let receipt = Receipt(url: task.response?.url?.absoluteString ?? task.originalRequest?.url?.absoluteString ?? "",
                status: http?.statusCode ?? 0, headers: headers,
                error: error.map { (self.background ? "后台" : "常规") + "请求未完成：" + $0.localizedDescription },
                transport: self.background ? "background" : "standard",
                uploaded: task.countOfBytesSent, received: task.countOfBytesReceived, expected: task.countOfBytesExpectedToReceive)
            do {
                if error == nil, !FileManager.default.fileExists(atPath: self.file(key, "response").path) {
                    // A genuinely empty HTTP response still needs a readable file;
                    // absence after receiving bytes is a client-side transfer failure.
                    guard task.countOfBytesReceived == 0 else {
                        throw AppError.storage("请求已完成，但系统响应文件未保存。请检查服务商记录后再生成，避免重复计费。")
                    }
                    try Data().write(to: self.file(key, "response"), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
                }
                try JSONEncoder().encode(receipt).write(to: self.file(key, "receipt"), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
                try? FileManager.default.removeItem(at: self.file(key, "request"))
                if let waiter = self.waiters.removeValue(forKey: key) {
                    if let error { waiter.resume(throwing: error); return }
                    do { guard let result = try self.cache(key) else { throw AppError.invalidResponse("后台响应为空。") }; waiter.resume(returning: result) }
                    catch { waiter.resume(throwing: error) }
                }
            } catch { self.waiters.removeValue(forKey: key)?.resume(throwing: error) }
        }
    }
    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        queue.async {
            DispatchQueue.main.async { self.completionHandler?(); self.completionHandler = nil }
        }
    }
}

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        #if DEBUG
        if UITestFixtures.enabled { return true }
        #endif
        _ = BackgroundTransfers.shared
        Task { await NetworkBootstrap.start() }
        return true
    }
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        guard identifier == BackgroundTransfers.identifier else { completionHandler(); return }
        BackgroundTransfers.shared.completionHandler = completionHandler
    }
}
