import Foundation

struct SiteDiscovery {
    static func defaults(site: String, mode: GenerationMode) throws -> (String, String) {
        var text = site.trimmingCharacters(in: .whitespacesAndNewlines)
        if !text.contains("://") { text = "https://" + text }
        let url = try APIConfiguration.httpsURL(text)
        guard url.query == nil else { throw AppError.configuration("API 站点请填写基础地址，不包含查询参数。") }
        var components = URLComponents(url: url, resolvingAgainstBaseURL: false)!
        var path = components.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        for suffix in ["images/generations", "chat/completions", "models"] where path.hasSuffix(suffix) {
            path = String(path.dropLast(suffix.count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        }
        if !path.hasSuffix("v1") { path = path.isEmpty ? "v1" : path + "/v1" }
        components.path = "/" + path + "/" + (mode == .images ? "images/generations" : "chat/completions")
        let endpoint = components.url!.absoluteString
        components.path = "/" + path + "/models"
        return (endpoint, components.url!.absoluteString)
    }

    static func detect(_ input: APIConfiguration) async throws -> (APIConfiguration, String) {
        var draft = input
        let routes = try defaults(site: input.site, mode: input.mode)
        draft.endpoint = routes.0
        draft.modelsEndpoint = routes.1
        // Read public New API routing metadata only. No speculative generation POSTs.
        let base = try APIConfiguration.httpsURL(draft.site.contains("://") ? draft.site : "https://" + draft.site)
        var components = URLComponents(url: base, resolvingAgainstBaseURL: false)!
        components.path = "/api/pricing"
        components.query = nil
        var request = URLRequest(url: components.url!)
        request.timeoutInterval = 10
        let transport = SessionImageTransport(authenticated: false)
        if let (data, response) = try? await transport.receive(request, byteLimit: 4 * 1024 * 1024),
           (response as? HTTPURLResponse)?.statusCode == 200,
           let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let endpoints = root["supported_endpoint"] as? [String: [String: Any]],
           let path = endpoints["openai"]?["path"] as? String, path == "/v1/chat/completions" {
            draft.mode = .chatCompletions
            draft.endpoint = try defaults(site: draft.site, mode: .chatCompletions).0
        }
        try Task.checkCancellation()
        if !draft.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            do {
                let models = try await ImageAPIClient().fetchModels(configuration: draft)
                return (draft, "模型地址已验证，读取到 \(models.count) 个模型；生图地址按路由信息补全。")
            } catch is CancellationError { throw CancellationError() }
            catch { return (draft, "已补全地址，模型地址未验证成功，可手动修改。") }
        }
        return (draft, "已自动补全常见接口地址；填写 Key 后可读取模型验证。")
    }
}

enum NetworkBootstrap {
    static func start() async {
        guard !UserDefaults.standard.bool(forKey: "didRequestNetwork-v2") else { return }
        UserDefaults.standard.set(true, forKey: "didRequestNetwork-v2")
        let config = URLSessionConfiguration.ephemeral
        config.httpCookieStorage = nil
        config.httpShouldSetCookies = false
        config.urlCache = nil
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: URL(string: "https://www.apple.com/library/test/success.html")!)
        request.httpMethod = "HEAD"
        request.timeoutInterval = 8
        _ = try? await session.data(for: request)
    }
}
