import SwiftUI
import UniformTypeIdentifiers
import PhotosUI

struct ContentView: View {
    @ObservedObject var configuration: ConfigurationStore
    @StateObject private var canvas = CanvasViewModel()
    @Environment(\.scenePhase) private var scenePhase
    @State private var showSettings = false
    @State private var showMore = false
    @State private var showGallery = false
    @State private var showExporter = false
    @State private var exportDocument: PNGDocument?
    @State private var exportName = "Luma"
    @State private var showFullScreen = false
    @State private var artworkFrame: CGRect = .zero
    @State private var inputSession = UUID()
    @State private var showDetails = false
    @State private var photoSelections: [PhotosPickerItem] = []
    @State private var showPhotos = false
    @State private var showReferenceFile = false
    @State private var loadingReference = false
    @State private var ratio: ArtworkRatio = .auto
    @State private var landscape = true
    @FocusState private var promptFocused: Bool

    var body: some View {
        VStack(spacing: 0) {
            header
            GeometryReader { geometry in
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        promptCard
                        if !canvas.references.isEmpty { referenceStrip }
                        ratioSelector
                        sensitivitySelector
                        preview(height: max(280, min(480, geometry.size.width - 32)))
                        previewFooter
                    }
                    .padding(16)
                    .frame(maxWidth: 680).frame(maxWidth: .infinity)
                }
                .scrollDismissesKeyboard(.interactively)
                .modifier(CanvasScrollEdge())
            }
            TimelineView(.periodic(from: .now, by: 1)) { timeline in bottomBar(now: timeline.date) }
        }
        .modifier(MoreDrawer(isPresented: $showMore, openGallery: { showGallery = true },
            newConversation: {
                dismissPromptKeyboard()
                inputSession = UUID(); photoSelections = []
                canvas.newConversation()
                ratio = .auto; canvas.selectedSize = configuration.value.size
            }, openSettings: { showSettings = true }))
        .onChange(of: showMore) { opened in
            if opened { dismissPromptKeyboard() }
        }
        .tint(Theme.accent)
        .overlay(alignment: .top) {
            if let toast = canvas.toast {
                Text(toast).font(.footnote.weight(.medium))
                    .padding(.horizontal, 18).padding(.vertical, 12)
                    .background(.regularMaterial, in: Capsule())
                    .padding(.top, 52).allowsHitTesting(false)
            }
        }
        .photosPicker(isPresented: $showPhotos, selection: $photoSelections,
                      maxSelectionCount: max(1, ReferenceImageStore.maximumCount - canvas.references.count),
                      selectionBehavior: .ordered, matching: .images, preferredItemEncoding: .compatible)
        .task(id: photoSelections) {
            guard !photoSelections.isEmpty else { return }
            let selections = photoSelections
            let session = inputSession
            loadingReference = true
            defer { loadingReference = false; photoSelections = [] }
            do {
                var images: [(Data, String)] = []
                for (index, selected) in selections.enumerated() {
                    guard let data = try await selected.loadTransferable(type: Data.self),
                          data.count <= ReferenceImageStore.maximumInputBytes else {
                        throw AppError.configuration("无法读取所选照片，或原图超过 50 MB。")
                    }
                    try Task.checkCancellation()
                    let png = try await Task.detached(priority: .userInitiated) {
                        try ReferenceImageStore.normalizedData(data)
                    }.value
                    try Task.checkCancellation()
                    images.append((png, "相册图片 \(index + 1)"))
                    try ReferenceImageStore.validatePayload(images.map { $0.0 })
                }
                if session == inputSession { canvas.addReferences(images) }
            } catch is CancellationError { }
            catch { canvas.alertMessage = error.localizedDescription }
        }
        // File providers may label a PNG/HEIC as generic data. Validate its actual
        // contents with ImageIO rather than disabling it based on its extension.
        .fileImporter(isPresented: $showReferenceFile, allowedContentTypes: [.item], allowsMultipleSelection: true) { result in
            let session = inputSession
            Task { @MainActor in
                loadingReference = true
                defer { loadingReference = false }
                do {
                    let urls = try result.get()
                    guard urls.count + canvas.references.count <= ReferenceImageStore.maximumCount else {
                        throw AppError.configuration("最多选择 8 张参考图，请先移除部分图片。")
                    }
                    let images = try await Task.detached(priority: .userInitiated) {
                        var selected: [(Data, String)] = []
                        for url in urls {
                            let png = try ReferenceImageStore.normalizedData(ReferenceImageStore.readFile(url))
                            selected.append((png, url.lastPathComponent))
                            try ReferenceImageStore.validatePayload(selected.map { $0.0 })
                        }
                        return selected
                    }.value
                    if session == inputSession { canvas.addReferences(images) }
                } catch { canvas.alertMessage = error.localizedDescription }
            }
        }
        .sheet(isPresented: $showSettings) { SettingsView(store: configuration) }
        .sheet(isPresented: $showGallery) {
            GalleryView(store: canvas.storage) { artwork in
                guard canvas.resumeEditing(artwork) else { return }
                inputSession = UUID(); photoSelections = []
                ratio = .auto; canvas.selectedSize = configuration.value.size
                showGallery = false; showMore = false
            }
        }
        .sheet(isPresented: $showDetails) {
            if let artwork = canvas.artwork { ArtworkDetailsView(artwork: artwork) }
        }
        .modifier(ArtworkZoomPresentation(isPresented: $showFullScreen, image: canvas.image, sourceFrame: artworkFrame))
        .fileExporter(isPresented: $showExporter, document: exportDocument,
                      contentType: .png, defaultFilename: exportName) { result in
            switch result {
            case .success: canvas.showToast("已导出到文件")
            case .failure(let error): canvas.alertMessage = "导出失败：\(error.localizedDescription)"
            }
            exportDocument = nil
        }
        .alert("提示", isPresented: Binding(get: { canvas.alertMessage != nil },
            set: { if !$0 { canvas.alertMessage = nil } })) {
                Button("知道了", role: .cancel) { canvas.alertMessage = nil }
                Button("复制信息") {
                    UIPasteboard.general.string = canvas.alertMessage
                    canvas.alertMessage = nil
                    canvas.showToast("已复制错误信息")
                }
            } message: { Text(canvas.alertMessage ?? "") }
        .task {
            canvas.selectedSize = configuration.value.size
            if let error = configuration.loadError { canvas.alertMessage = error }
            await canvas.restore()
            #if DEBUG
            if ProcessInfo.processInfo.arguments.contains("ui-preview-more") { showMore = true }
            if ProcessInfo.processInfo.arguments.contains("ui-preview-gallery") || ProcessInfo.processInfo.arguments.contains("ui-preview-detail") { showGallery = true }
            #endif
        }
        .onChange(of: configuration.value) { value in
            canvas.selectedSize = value.size
            ratio = .auto
            canvas.resetConfirmation()
        }
        .onChange(of: canvas.prompt) { _ in canvas.resetConfirmation() }
        .onChange(of: canvas.selectedSize) { _ in canvas.resetConfirmation() }
        .onChange(of: canvas.sensitivity) { _ in canvas.resetConfirmation() }
        .onChange(of: scenePhase) { phase in
            if phase == .active { Task { await canvas.restore() } }
        }
    }

    private var header: some View {
        HStack {
            Button {
                dismissPromptKeyboard(); showMore.toggle()
            } label: {
                Image(systemName: "line.3.horizontal").font(.system(size: 22, weight: .medium))
                    .frame(width: 48, height: 48)
            }.buttonStyle(RatioGlassStyle(circular: true))
                .accessibilityLabel("更多").accessibilityIdentifier("more-button")
            Spacer()
            Text("映想").font(.system(size: 20, weight: .semibold))
            Spacer()
            Color.clear.frame(width: 48, height: 48)
        }.padding(.horizontal, 16).padding(.vertical, 6)
            .modifier(CanvasHeaderFade())
    }

    private var promptCard: some View {
        HStack(alignment: .top, spacing: 12) {
            Menu {
                Button { showPhotos = true } label: { Label("选择相册", systemImage: "photo.on.rectangle") }
                    .disabled(canvas.references.count >= ReferenceImageStore.maximumCount)
                Button { showReferenceFile = true } label: { Label("选择文件", systemImage: "folder") }
                    .disabled(canvas.references.count >= ReferenceImageStore.maximumCount)
                if canvas.reference != nil {
                    Button("移除全部参考图", role: .destructive) { canvas.removeReference() }
                }
            } label: {
                VStack(spacing: 10) {
                    if let preview = canvas.referencePreview {
                        Image(uiImage: preview).resizable().scaledToFill()
                            .frame(width: 76, height: 88).clipShape(RoundedRectangle(cornerRadius: 14))
                    } else {
                        Image(systemName: "photo.badge.plus").font(.system(size: 27, weight: .light))
                            .frame(height: 88)
                    }
                    if loadingReference { ProgressView() }
                    else { Text(canvas.references.isEmpty ? "参考图" : "参考图 · \(canvas.references.count)").font(.subheadline.weight(.medium)) }
                }.frame(width: 104, height: 172)
                    .foregroundStyle(Theme.accent).modifier(GlassSurface())
            }.buttonStyle(.plain).disabled(canvas.isGenerating || loadingReference)
                .accessibilityLabel(canvas.reference == nil ? "添加参考图，相册或文件" : "添加或移除参考图，已选 \(canvas.references.count) 张")
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text("提示词").font(.subheadline.weight(.semibold))
                    Spacer()
                    if !canvas.prompt.isEmpty {
                        Button("清空") { canvas.prompt = "" }.font(.caption)
                    }
                }
                TextEditor(text: $canvas.prompt)
                    .frame(height: 110).scrollContentBackground(.hidden)
                    .focused($promptFocused).accessibilityLabel("提示词")
                    .accessibilityIdentifier("prompt-editor")
            }.padding(16).modifier(GlassSurface())
        }
    }

    private var referenceStrip: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("已选 \(canvas.references.count)/8 张 · 可继续添加或单独移除")
                .font(.caption).foregroundStyle(.secondary)
                .accessibilityIdentifier("reference-count")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(canvas.references, id: \.id) { reference in
                        ZStack(alignment: .topTrailing) {
                            if let image = canvas.referencePreviews[reference.id] {
                                Image(uiImage: image).resizable().scaledToFill()
                                    .frame(width: 74, height: 74)
                                    .clipShape(RoundedRectangle(cornerRadius: 14))
                            }
                            Button { canvas.removeReference(reference) } label: {
                                Image(systemName: "xmark.circle.fill").font(.title3)
                                    .symbolRenderingMode(.palette).foregroundStyle(.white, .black.opacity(0.6))
                            }.buttonStyle(.plain).disabled(canvas.isGenerating || loadingReference)
                                .accessibilityLabel("移除 \(reference.name)")
                        }.padding(3)
                    }
                }
            }
        }
    }

    private var ratioSelector: some View {
        GeometryReader { geometry in
            let width = max(46, (geometry.size.width - 44 - 10 - 24) / 5)
            HStack(spacing: 10) {
                Button {
                    landscape.toggle()
                    if ratio == .auto { ratio = .wide }
                    canvas.selectedSize = ratio.size(landscape: landscape, nai: configuration.value.usesNAIParameters)
                } label: {
                    Image(systemName: landscape ? "rectangle" : "rectangle.portrait")
                        .font(.system(size: 19, weight: .medium))
                        .frame(width: 44, height: 44).contentShape(Circle())
                }.buttonStyle(RatioGlassStyle(circular: true))
                    .accessibilityIdentifier("orientation-button")
                    .accessibilityLabel("切换横图或竖图")
                    .accessibilityValue(landscape ? "横图" : "竖图")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(ArtworkRatio.allCases) { value in
                            Button {
                                ratio = value
                                if value != .auto && value != .square { landscape = value != .portrait }
                                canvas.selectedSize = value == .auto ? "auto" : value.size(landscape: landscape, nai: configuration.value.usesNAIParameters)
                            } label: {
                                Text(value.title).font(.system(size: 13, weight: .medium))
                                    .lineLimit(1).minimumScaleFactor(0.85)
                                    .frame(width: width, height: 44).contentShape(Capsule())
                            }.buttonStyle(RatioGlassStyle(selected: ratio == value))
                                .accessibilityIdentifier("ratio-\(value.rawValue)")
                                .accessibilityAddTraits(ratio == value ? .isSelected : [])
                        }
                    }.padding(.vertical, 16)
                }.modifier(UnclippedScroll())
            }.frame(height: 80)
        }.frame(height: 80)
    }

    private var sensitivitySelector: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Text("敏感度审查").font(.subheadline)
                Spacer()
                Picker("敏感度审查", selection: $canvas.sensitivity) {
                    ForEach(Sensitivity.allCases) { Text($0.title).tag($0) }
                }.pickerStyle(.segmented).frame(maxWidth: 190)
                    .disabled(configuration.value.usesNAIParameters)
            }
            Text(configuration.value.usesNAIParameters ? "当前 NAI 参数接口不支持审查扩展，由服务商执行审查。" : "高为标准过滤，低请求宽松过滤；关不发送审查参数。两种接口均可用，以服务商支持为准。")
                .font(.caption2).foregroundStyle(.secondary)
        }.padding(.horizontal, 4)
    }

    private func preview(height: CGFloat) -> some View {
        ZStack {
            Theme.canvas
            if let image = canvas.image {
                Image(uiImage: image).resizable().scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                Image(systemName: "photo").font(.system(size: 42, weight: .ultraLight))
                    .foregroundStyle(.tertiary)
            }
            if canvas.isGenerating {
                VStack(spacing: 12) {
                    ProgressView()
                    Text("正在生成").font(.subheadline.weight(.medium))
                    Button("停止等待") { canvas.cancel() }.font(.caption)
                }.padding(22).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))
            }
        }
        .frame(height: height)
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .modifier(ArtworkFrameReader())
        .onPreferenceChange(ArtworkFramePreference.self) { artworkFrame = $0 }
        .contentShape(Rectangle())
        .onTapGesture { if canvas.image != nil && !canvas.isGenerating { showFullScreen = true } }
        .accessibilityLabel(canvas.image == nil ? "图片预览区域" : "生成图片，点击放大")
        .accessibilityAddTraits(canvas.image == nil ? [] : .isButton)
    }

    private var previewFooter: some View {
        HStack(spacing: 6) {
            Circle().fill(configuration.value.isReady ? Color.green : Color.secondary).frame(width: 5, height: 5)
            Text(configuration.value.isReady ? configuration.value.name : "请先配置 API").font(.caption)
            Spacer()
            if let artwork = canvas.artwork {
                Text("\(artwork.pixelWidth) × \(artwork.pixelHeight)").font(.caption)
                Button { showDetails = true } label: { Image(systemName: "info.circle") }
                    .accessibilityLabel("作品信息")
            }
        }.foregroundStyle(.secondary).padding(.horizontal, 4)
    }

    private func dismissPromptKeyboard() {
        promptFocused = false
        let windows = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.flatMap { $0.windows }
        windows.forEach { $0.endEditing(true) }
        // Apply once more after SwiftUI commits the focus-state transaction.
        DispatchQueue.main.async { windows.forEach { $0.endEditing(true) } }
    }

    private func bottomBar(now: Date) -> some View {
        let remaining = max(0, Int(ceil(canvas.cooldownUntil.timeIntervalSince(now))))
        let ready = !canvas.prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !canvas.isGenerating && !loadingReference && remaining == 0
        return VStack(spacing: 10) {
            Button {
                dismissPromptKeyboard()
                if canvas.isGenerating { canvas.showToast("正在生成，请稍候") }
                else if loadingReference { canvas.showToast("正在读取参考图，请稍候") }
                else if remaining > 0 { canvas.showToast("请等待冷却结束") }
                else if canvas.prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { canvas.showToast("请先输入提示词") }
                else if configuration.value.isReady { canvas.generate(configuration: configuration.value) }
                else { showSettings = true }
            } label: {
                Label(canvas.isGenerating ? "正在生成" : remaining > 0 ? "生成 · \(remaining)s" : canvas.confirmationArmed ? "再次点击确认生成" : "生成", systemImage: "sparkles").frame(maxWidth: .infinity, minHeight: 30)
            }.modifier(GlassButton(primary: ready, clear: true))
                .accessibilityIdentifier("generate-button")
            HStack(spacing: 10) {
                Button {
                    guard canvas.artwork != nil else { canvas.showToast("请先生成图片"); return }
                    guard !canvas.isSavingPhoto else { canvas.showToast("正在保存，请稍候"); return }
                    Task { await canvas.savePhoto() }
                } label: {
                    Label(canvas.isSavingPhoto ? "正在保存" : "保存相册", systemImage: "square.and.arrow.down").frame(maxWidth: .infinity, minHeight: 30)
                }.modifier(GlassButton(clear: true))
                    .accessibilityIdentifier("save-photo-button")
                    .accessibilityValue(canvas.artwork == nil ? "尚无图片" : "可保存")
                Button {
                    guard let artwork = canvas.artwork else { canvas.showToast("请先生成图片"); return }
                    exportDocument = PNGDocument(data: artwork.pngData)
                    exportName = artwork.fileName
                    showExporter = true
                } label: { Label("转存文件", systemImage: "folder").frame(maxWidth: .infinity, minHeight: 30) }
                    .modifier(GlassButton(clear: true))
                    .accessibilityIdentifier("export-file-button")
            }
        }
        .padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 8)
        .frame(maxWidth: 680).frame(maxWidth: .infinity)
        .background(KeyboardTapExclusion())
    }
}

private struct CanvasHeaderFade: ViewModifier {
    @Environment(\.drawerProgress) private var progress
    func body(content: Content) -> some View {
        content.background {
            Rectangle().fill(.ultraThinMaterial)
                // Overdraw the blur sampling region so its vertical edge never appears on a rebound.
                .padding(.horizontal, -48)
                .mask(LinearGradient(stops: [.init(color: .black, location: 0),
                    .init(color: .black.opacity(0.7), location: 0.5), .init(color: .clear, location: 1)],
                    startPoint: .top, endPoint: .bottom))
                .opacity(1 - progress)
                .clipped()
                .ignoresSafeArea(edges: .top)
        }
    }
}

private struct CanvasScrollEdge: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.scrollEdgeEffectHidden(true, for: .all)
        } else { content }
    }
}
