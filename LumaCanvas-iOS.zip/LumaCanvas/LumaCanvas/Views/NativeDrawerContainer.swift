import SwiftUI
import Combine

/// UIKit owns the translated viewport; the hosted chat never changes identity.
struct NativeDrawerContainer: UIViewControllerRepresentable {
    let presentation: DrawerPresentation
    let content: AnyView
    let sidebar: AnyView
    let dark: Bool
    let reduceMotion: Bool

    func makeUIViewController(context: Context) -> Controller {
        Controller(presentation: presentation, content: content, sidebar: sidebar, dark: dark, reduceMotion: reduceMotion)
    }
    func updateUIViewController(_ controller: Controller, context: Context) {
        controller.main.rootView = content
        controller.sidebar.rootView = sidebar
        controller.dark = dark
        controller.reduceMotion = reduceMotion
        controller.updateColors()
    }
    final class Controller: UIViewController {
        let presentation: DrawerPresentation
        let main: UIHostingController<AnyView>
        let sidebar: UIHostingController<AnyView>
        var dark: Bool
        var reduceMotion: Bool
        private var observation: AnyCancellable?
        private let dim = UIView()
        private var opened = false
        private var animator: UIViewPropertyAnimator?

        init(presentation: DrawerPresentation, content: AnyView, sidebar: AnyView, dark: Bool, reduceMotion: Bool) {
            self.presentation = presentation
            main = UIHostingController(rootView: content)
            self.sidebar = UIHostingController(rootView: sidebar)
            self.dark = dark; self.reduceMotion = reduceMotion
            super.init(nibName: nil, bundle: nil)
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) is unsupported") }
        override func viewDidLoad() {
            super.viewDidLoad()
            view.clipsToBounds = true
            if #available(iOS 16.4, *) { main.safeAreaRegions = [] }
            for child in [sidebar, main] {
                addChild(child); view.addSubview(child.view); child.didMove(toParent: self)
            }
            sidebar.view.backgroundColor = .systemBackground
            main.view.layer.cornerCurve = .continuous
            main.view.clipsToBounds = true
            main.view.addSubview(dim)
            dim.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(close)))
            dim.isAccessibilityElement = true
            dim.accessibilityLabel = "关闭更多"
            dim.accessibilityTraits = .button
            updateColors()
            observation = presentation.$isPresented.removeDuplicates().sink { [weak self] value in
                self?.setOpened(value)
            }
        }
        override func viewDidLayoutSubviews() {
            super.viewDidLayoutSubviews()
            sidebar.view.frame = CGRect(origin: .zero, size: CGSize(width: view.bounds.width * 0.75, height: view.bounds.height))
            // Bounds and center avoid resetting an in-flight translated frame.
            main.view.bounds = view.bounds
            main.view.center = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
            dim.frame = main.view.bounds
            main.view.bringSubviewToFront(dim)
            if animator == nil { main.view.transform = CGAffineTransform(translationX: opened ? view.bounds.width * 0.75 : 0, y: 0) }
        }
        func updateColors() {
            view.backgroundColor = .systemBackground
            main.view.backgroundColor = .systemGroupedBackground
            dim.backgroundColor = dark ? .black : .white
        }
        private func setOpened(_ value: Bool) {
            guard isViewLoaded else { return }
            opened = value
            animator?.stopAnimation(false)
            animator?.finishAnimation(at: .current)
            sidebar.view.isHidden = false
            sidebar.view.accessibilityElementsHidden = !value
            dim.isUserInteractionEnabled = value
            dim.accessibilityElementsHidden = !value
            view.layoutIfNeeded()
            let next = UIViewPropertyAnimator(duration: reduceMotion ? 0.15 : 0.38,
                controlPoint1: CGPoint(x: 0.2, y: 0.8), controlPoint2: CGPoint(x: 0.2, y: 1))
            animator = next
            next.addAnimations { [weak self] in
                guard let self else { return }
                self.main.view.transform = CGAffineTransform(translationX: value ? self.view.bounds.width * 0.75 : 0, y: 0)
                self.main.view.layer.cornerRadius = value ? 38 : 0
                self.dim.alpha = value ? (self.dark ? 0.25 : 0.3) : 0
            }
            next.addCompletion { [weak self, weak next] _ in
                guard let self, self.animator === next else { return }
                self.animator = nil
                self.sidebar.view.isHidden = !value
            }
            next.startAnimation()
        }
        @objc private func close() { presentation.isPresented = false }
    }
}
