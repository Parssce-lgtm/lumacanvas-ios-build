import SwiftUI
import Combine

/// UIKit owns the translated viewport; the hosted chat never changes identity.
struct NativeDrawerContainer: UIViewControllerRepresentable {
    let presentation: DrawerPresentation
    let content: AnyView
    let sidebar: AnyView
    let dark: Bool
    let reduceMotion: Bool
    let openAnywhere: Bool

    func makeUIViewController(context: Context) -> Controller {
        Controller(presentation: presentation, content: content, sidebar: sidebar, dark: dark, reduceMotion: reduceMotion, openAnywhere: openAnywhere)
    }
    func updateUIViewController(_ controller: Controller, context: Context) {
        controller.main.rootView = content
        controller.sidebar.rootView = sidebar
        controller.dark = dark
        controller.reduceMotion = reduceMotion
        controller.openAnywhere = openAnywhere
        controller.updateColors()
    }
    final class Controller: UIViewController, UIGestureRecognizerDelegate {
        let presentation: DrawerPresentation
        let main: UIHostingController<AnyView>
        let sidebar: UIHostingController<AnyView>
        var dark: Bool
        var reduceMotion: Bool
        var openAnywhere: Bool
        private var observation: AnyCancellable?
        private let dim = UIView()
        private let mainSurface = UIView()
        private var opened = false
        private var transitionID = 0
        private var animating = false
        private var dragging = false
        private var dragOrigin: CGFloat = 0
        private var offset: CGFloat = 0
        private lazy var pan = UIPanGestureRecognizer(target: self, action: #selector(swiped(_:)))

        init(presentation: DrawerPresentation, content: AnyView, sidebar: AnyView, dark: Bool, reduceMotion: Bool, openAnywhere: Bool) {
            self.presentation = presentation
            main = UIHostingController(rootView: content)
            self.sidebar = UIHostingController(rootView: sidebar)
            self.dark = dark; self.reduceMotion = reduceMotion; self.openAnywhere = openAnywhere
            super.init(nibName: nil, bundle: nil)
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) is unsupported") }
        override func viewDidLoad() {
            super.viewDidLoad()
            view.clipsToBounds = true
            if #available(iOS 16.4, *) { main.safeAreaRegions = [] }
            addChild(sidebar); view.addSubview(sidebar.view); sidebar.didMove(toParent: self)
            view.addSubview(mainSurface)
            addChild(main); mainSurface.addSubview(main.view); main.didMove(toParent: self)
            sidebar.view.backgroundColor = .systemBackground
            mainSurface.layer.cornerCurve = .continuous
            mainSurface.clipsToBounds = true
            mainSurface.addSubview(dim)
            dim.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(close)))
            dim.isAccessibilityElement = true
            dim.accessibilityLabel = "关闭更多"
            dim.accessibilityTraits = .button
            updateColors()
            pan.delegate = self; pan.cancelsTouchesInView = true
            pan.delaysTouchesBegan = false; pan.delaysTouchesEnded = true
            view.addGestureRecognizer(pan)
            dim.alpha = 0; dim.isUserInteractionEnabled = false
            sidebar.view.isHidden = true
            observation = presentation.$isPresented.removeDuplicates().receive(on: RunLoop.main).sink { [weak self] value in
                self?.setOpened(value)
            }
        }
        override func viewDidLayoutSubviews() {
            super.viewDidLayoutSubviews()
            sidebar.view.frame = CGRect(origin: .zero, size: CGSize(width: view.bounds.width * 0.75, height: view.bounds.height))
            // Bounds and center avoid resetting an in-flight translated frame.
            mainSurface.bounds = view.bounds
            mainSurface.center = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
            main.view.frame = mainSurface.bounds
            dim.frame = mainSurface.bounds
            mainSurface.bringSubviewToFront(dim)
            if !animating && !dragging { apply(offset: opened ? view.bounds.width * 0.75 : 0) }
        }
        func updateColors() {
            view.backgroundColor = .systemBackground
            main.view.backgroundColor = .systemGroupedBackground
            dim.backgroundColor = dark ? .black : .white
        }
        private func setOpened(_ value: Bool) {
            guard isViewLoaded, opened != value else { return }
            settle(value, velocity: 0)
        }
        private func apply(offset value: CGFloat) {
            offset = min(max(0, value), view.bounds.width * 0.75)
            let progress = offset / max(1, view.bounds.width * 0.75)
            mainSurface.transform = CGAffineTransform(translationX: offset, y: 0)
            mainSurface.layer.cornerRadius = 38 * progress
            dim.alpha = (dark ? 0.25 : 0.3) * progress
        }
        /// Interrupt at the currently displayed position, including mid-animation reversals.
        func beginDrag() {
            let current = mainSurface.layer.presentation()?.transform.m41 ?? offset
            transitionID += 1
            mainSurface.layer.removeAllAnimations(); dim.layer.removeAllAnimations()
            animating = false; dragging = true
            sidebar.view.isHidden = false
            apply(offset: current); dragOrigin = offset
        }
        func updateDrag(translation: CGFloat) {
            guard dragging else { return }
            apply(offset: dragOrigin + translation)
        }
        func endDrag(velocity: CGFloat, cancelled: Bool = false) {
            guard dragging else { return }
            let target = cancelled ? opened : offset + velocity * 0.15 > view.bounds.width * 0.375
            dragging = false
            settle(target, velocity: velocity)
            presentation.isPresented = target
        }
        private func settle(_ value: Bool, velocity: CGFloat) {
            dragging = false
            opened = value
            transitionID += 1
            let revision = transitionID
            sidebar.view.isHidden = false
            sidebar.view.accessibilityElementsHidden = !value
            dim.isUserInteractionEnabled = value
            dim.accessibilityElementsHidden = !value
            view.layoutIfNeeded()
            animating = true
            let destination = value ? view.bounds.width * 0.75 : 0
            let distance = destination - offset
            let initialVelocity = abs(distance) > 1 ? min(8, max(-8, velocity / distance)) : 0
            UIView.animate(withDuration: reduceMotion ? 0.15 : 0.4, delay: 0,
                usingSpringWithDamping: reduceMotion ? 1 : 0.88, initialSpringVelocity: initialVelocity,
                options: [.beginFromCurrentState, .allowUserInteraction]) { [weak self] in
                guard let self else { return }
                self.apply(offset: destination)
            } completion: { [weak self] _ in
                guard let self, self.transitionID == revision else { return }
                self.animating = false
                self.sidebar.view.isHidden = !value
            }
        }
        @objc private func swiped(_ gesture: UIPanGestureRecognizer) {
            switch gesture.state {
            case .began: beginDrag(); updateDrag(translation: gesture.translation(in: view).x)
            case .changed: updateDrag(translation: gesture.translation(in: view).x)
            case .ended: endDrag(velocity: gesture.velocity(in: view).x)
            case .cancelled, .failed: endDrag(velocity: 0, cancelled: true)
            default: break
            }
        }
        func gestureRecognizerShouldBegin(_ gesture: UIGestureRecognizer) -> Bool {
            let speed = pan.velocity(in: view)
            guard abs(speed.x) > abs(speed.y) * 1.35 else { return false }
            if animating { return true }
            if presentation.isPresented { return speed.x < 0 }
            let origin = pan.location(in: view).x - pan.translation(in: view).x
            return speed.x > 0 && (openAnywhere || origin < 32)
        }
        func gestureRecognizer(_ gesture: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { false }
        @objc private func close() { presentation.isPresented = false }
    }
}
