import SwiftUI

struct SettingsHomeView: View {
    @ObservedObject var store: ConfigurationStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    NavigationLink {
                        SettingsView(store: store, embedded: true)
                    } label: {
                        HStack(spacing: 14) {
                            Image(systemName: "slider.horizontal.3").font(.system(size: 23)).frame(width: 30)
                            VStack(alignment: .leading, spacing: 4) {
                                Text("API 设置")
                                Text(store.value.name).font(.caption).foregroundStyle(.secondary)
                            }
                        }.padding(.vertical, 8)
                    }.accessibilityIdentifier("settings-api-link")
                }
                Section("应用") {
                    LabeledContent("外观", value: "跟随系统")
                    LabeledContent("版本", value: "1.17（41）")
                }
            }
            .navigationTitle("设置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
            .tint(Theme.accent)
        }
    }
}
