import SwiftUI
import UIKit

enum AppHaptics {
    static func light() { UIImpactFeedbackGenerator(style: .soft).impactOccurred(intensity: 0.65) }
    static func saved() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
}

/// Text selection uses the native edit menu, without a lifted message snapshot.
struct ChatText: UIViewRepresentable {
    let text: String
    var markdown = true
    var menuFirst = false
    var select: (() -> Void)?
    var edit: (() -> Void)?
    var retry: (() -> Void)?
    var share: (() -> Void)?
    @Environment(\.colorScheme) private var colorScheme
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> UITextView {
        let view = UITextView()
        view.isEditable = false; view.isSelectable = !menuFirst; view.isScrollEnabled = false
        view.backgroundColor = .clear; view.textContainerInset = .zero
        view.textContainer.lineFragmentPadding = 0; view.delegate = context.coordinator
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        context.coordinator.view = view
        let menu = UIEditMenuInteraction(delegate: context.coordinator)
        view.addInteraction(menu); context.coordinator.menu = menu
        let hold = UILongPressGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.showMessageMenu(_:)))
        hold.minimumPressDuration = 0.5; hold.isEnabled = menuFirst
        view.addGestureRecognizer(hold); context.coordinator.hold = hold
        return view
    }
    func updateUIView(_ view: UITextView, context: Context) {
        context.coordinator.parent = self
        context.coordinator.hold?.isEnabled = menuFirst
        view.isSelectable = !menuFirst
        let dark = colorScheme == .dark
        if context.coordinator.renderedText != text || context.coordinator.renderedMarkdown != markdown || context.coordinator.renderedDark != dark {
            view.attributedText = ChatFormatting.attributed(text, markdown: markdown, color: dark ? .white : .black)
            context.coordinator.renderedText = text
            context.coordinator.renderedMarkdown = markdown
            context.coordinator.renderedDark = dark
        }
    }
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: UITextView, context: Context) -> CGSize? {
        guard let width = proposal.width, width > 0 else { return nil }
        let natural = uiView.attributedText.boundingRect(with: CGSize(width: width, height: .greatestFiniteMagnitude), options: [.usesLineFragmentOrigin, .usesFontLeading], context: nil)
        let fittedWidth = min(width, max(24, ceil(natural.width) + 1))
        return CGSize(width: fittedWidth, height: ceil(uiView.sizeThatFits(CGSize(width: fittedWidth, height: .greatestFiniteMagnitude)).height))
    }
    final class Coordinator: NSObject, UITextViewDelegate, UIEditMenuInteractionDelegate {
        var parent: ChatText
        weak var view: UITextView?
        var menu: UIEditMenuInteraction?
        var hold: UILongPressGestureRecognizer?
        var renderedText: String?
        var renderedMarkdown = true
        var renderedDark = false
        init(_ parent: ChatText) { self.parent = parent }
        @objc func showMessageMenu(_ gesture: UILongPressGestureRecognizer) {
            guard gesture.state == .began, let view, parent.menuFirst else { return }
            menu?.presentEditMenu(with: UIEditMenuConfiguration(identifier: nil, sourcePoint: gesture.location(in: view)))
        }
        func editMenuInteraction(_ interaction: UIEditMenuInteraction, menuFor configuration: UIEditMenuConfiguration, suggestedActions: [UIMenuElement]) -> UIMenu? {
            var actions: [UIMenuElement] = [
                UIAction(title: "复制", image: UIImage(systemName: "doc.on.doc")) { [weak self] _ in
                    UIPasteboard.general.string = self?.parent.text; AppHaptics.light()
                },
                UIAction(title: "选择文本", image: UIImage(systemName: "text.cursor")) { [weak self] _ in
                    self?.parent.select?()
                }
            ]
            if let edit = parent.edit { actions.append(UIAction(title: "编辑", image: UIImage(systemName: "pencil")) { _ in edit() }) }
            if let retry = parent.retry {
                actions.append(UIMenu(title: "更多", image: UIImage(systemName: "ellipsis"), children: [
                    UIAction(title: "重试", image: UIImage(systemName: "arrow.clockwise")) { _ in AppHaptics.light(); retry() }
                ]))
            }
            if let share = parent.share { actions.append(UIAction(title: "分享", image: UIImage(systemName: "square.and.arrow.up")) { _ in share() }) }
            return UIMenu(children: actions)
        }
        func textView(_ textView: UITextView, editMenuForTextIn range: NSRange, suggestedActions: [UIMenuElement]) -> UIMenu? {
            var actions = suggestedActions
            if let edit = parent.edit { actions.append(UIAction(title: "编辑", image: UIImage(systemName: "pencil")) { _ in edit() }) }
            if let retry = parent.retry {
                actions.append(UIMenu(title: "更多", image: UIImage(systemName: "ellipsis"), children: [
                    UIAction(title: "重试", image: UIImage(systemName: "arrow.clockwise")) { _ in AppHaptics.light(); retry() }
                ]))
            }
            if let share = parent.share { actions.append(UIAction(title: "分享", image: UIImage(systemName: "square.and.arrow.up")) { _ in AppHaptics.light(); share() }) }
            return UIMenu(children: actions)
        }
    }
}

enum ChatFormatting {
    static func attributed(_ text: String, markdown: Bool = true, color: UIColor = .label) -> NSAttributedString {
        let result = NSMutableAttributedString(string: "")
        var code = false
        for raw in text.components(separatedBy: "\n") {
            if markdown && raw.hasPrefix("```") { code.toggle(); continue }
            var line = raw
            var font = UIFont.preferredFont(forTextStyle: .body)
            if markdown && !code {
                if let head = line.range(of: "^#{1,6} ", options: .regularExpression) {
                    let count = line[head].filter { $0 == "#" }.count
                    font = UIFont.boldSystemFont(ofSize: count == 1 ? 27 : count == 2 ? 23 : 19)
                    line.removeSubrange(head)
                } else if line.hasPrefix("- ") || line.hasPrefix("* ") { line = "• " + line.dropFirst(2) }
            }
            if code { font = UIFont.monospacedSystemFont(ofSize: 14, weight: .regular) }
            let paragraph = NSMutableParagraphStyle(); paragraph.lineSpacing = 3; paragraph.paragraphSpacing = 7
            let value = NSMutableAttributedString(string: line + "\n", attributes: [.font: font, .foregroundColor: color, .paragraphStyle: paragraph])
            if markdown && !code, let regex = try? NSRegularExpression(pattern: "\\*\\*(.+?)\\*\\*|`([^`]+)`|\\*(\\S[^*]*?)\\*") {
                for match in regex.matches(in: value.string, range: NSRange(location: 0, length: value.length)).reversed() {
                    let group = (1...3).first { match.range(at: $0).location != NSNotFound }!
                    let content = (value.string as NSString).substring(with: match.range(at: group))
                    value.replaceCharacters(in: match.range, with: content)
                    let style: UIFont = group == 1 ? .boldSystemFont(ofSize: font.pointSize) : group == 2 ? .monospacedSystemFont(ofSize: 14, weight: .regular) : .italicSystemFont(ofSize: font.pointSize)
                    value.addAttribute(.font, value: style, range: NSRange(location: match.range.location, length: (content as NSString).length))
                }
            }
            result.append(value)
        }
        if result.length > 0 { result.deleteCharacters(in: NSRange(location: result.length - 1, length: 1)) }
        return result
    }
}
