import SwiftUI
import UniformTypeIdentifiers

struct GalleryView: View {
    let store: ArtworkStore
    @Environment(\.dismiss) private var dismiss
    @State private var items: [ArtworkSummary] = []
    @State private var selected: GeneratedArtwork?
    @State private var errorMessage: String?
    @State private var loading = true

    var body: some View {
        NavigationStack {
            Group {
                if loading { ProgressView("正在读取图库") }
                else if items.isEmpty {
                    VStack(spacing: 14) {
                        Image(systemName: "photo.on.rectangle").font(.system(size: 42)).foregroundStyle(.secondary)
                        Text("图库还没有图片").font(.headline)
                        Text("生成成功的图片会自动保存在这里").font(.subheadline).foregroundStyle(.secondary)
                    }.accessibilityIdentifier("gallery-empty")
                } else {
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 145), spacing: 14)], spacing: 18) {
                            ForEach(items) { item in
                                Button {
                                    Task {
                                        do { selected = try await store.artwork(item.id) }
                                        catch { errorMessage = error.localizedDescription }
                                    }
                                } label: {
                                    VStack(alignment: .leading, spacing: 8) {
                                        GalleryThumbnail(id: item.id, store: store)
                                        Text(item.prompt.isEmpty ? "生成图片" : item.prompt)
                                            .font(.subheadline).lineLimit(2).foregroundStyle(.primary)
                                        Text(item.createdAt, format: .dateTime.month().day().hour().minute())
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                }.buttonStyle(.plain)
                                    .accessibilityLabel("查看图片，\(item.prompt)")
                                    .accessibilityIdentifier("gallery-item-\(item.id.uuidString)")
                            }
                        }.padding(16)
                    }.modifier(SoftTopEdge())
                }
            }.frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Theme.background.ignoresSafeArea())
                .navigationTitle("图库").navigationBarTitleDisplayMode(.large)
                .toolbar { ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") { dismiss() }
                } }
        }.tint(Theme.accent)
            .task { await reload() }
            .onReceive(NotificationCenter.default.publisher(for: .artworkGalleryChanged).receive(on: DispatchQueue.main)) { _ in
                Task { await reload() }
            }
            .fullScreenCover(item: $selected) { artwork in GalleryArtworkView(artwork: artwork) }
            .alert("提示", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("知道了", role: .cancel) { errorMessage = nil }
            } message: { Text(errorMessage ?? "") }
    }
    @MainActor private func reload() async {
        defer { loading = false }
        do { items = try await store.list() }
        catch { errorMessage = error.localizedDescription }
    }
}

private struct GalleryThumbnail: View {
    let id: UUID
    let store: ArtworkStore
    @State private var image: UIImage?
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Theme.canvas
                if let image {
                    Image(uiImage: image).resizable().scaledToFill()
                        .frame(width: geometry.size.width, height: geometry.size.height).clipped()
                } else { Image(systemName: "photo").foregroundStyle(.secondary) }
            }
        }.aspectRatio(0.85, contentMode: .fit).clipShape(RoundedRectangle(cornerRadius: 18))
            .task(id: id) {
                let data = try? await store.thumbnail(id)
                if let data { image = UIImage(data: data) }
            }
    }
}

private struct GalleryArtworkView: View {
    let artwork: GeneratedArtwork
    @Environment(\.dismiss) private var dismiss
    @State private var fullScreen = false
    @State private var exporting = false
    @State private var saving = false
    @State private var message: String?
    private var image: UIImage? { UIImage(data: artwork.pngData) }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    if let image {
                        Button { fullScreen = true } label: {
                            Image(uiImage: image).resizable().scaledToFit()
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                        }.buttonStyle(.plain).accessibilityLabel("放大图片")
                    }
                    Text(artwork.prompt).font(.body).textSelection(.enabled)
                    Text("\(artwork.pixelWidth) × \(artwork.pixelHeight) · \(artwork.model)")
                        .font(.caption).foregroundStyle(.secondary)
                    Text(artwork.createdAt, format: .dateTime.year().month().day().hour().minute())
                        .font(.caption).foregroundStyle(.secondary)
                }.padding(16)
            }.modifier(SoftTopEdge()).background(Theme.background.ignoresSafeArea())
                .navigationTitle("图片").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") { dismiss() }
                } }
                .safeAreaInset(edge: .bottom) {
                    HStack(spacing: 12) {
                        Button {
                            guard !saving else { return }
                            saving = true
                            Task {
                                defer { saving = false }
                                do { try await PhotoLibraryService.save(pngData: artwork.pngData); message = "已保存到相册" }
                                catch { message = error.localizedDescription }
                            }
                        } label: {
                            Label(saving ? "正在保存" : "保存相册", systemImage: "square.and.arrow.down")
                                .frame(maxWidth: .infinity, minHeight: 30)
                        }.modifier(GlassButton(clear: true)).accessibilityIdentifier("gallery-save-button")
                        Button { exporting = true } label: {
                            Label("转存文件", systemImage: "folder").frame(maxWidth: .infinity, minHeight: 30)
                        }.modifier(GlassButton(clear: true)).accessibilityIdentifier("gallery-export-button")
                    }.padding(16)
                }
        }.tint(Theme.accent)
            .fullScreenCover(isPresented: $fullScreen) {
                if let image { FullScreenArtworkView(image: image) }
            }
            .fileExporter(isPresented: $exporting, document: PNGDocument(data: artwork.pngData),
                contentType: .png, defaultFilename: artwork.fileName) { result in
                    if case .failure(let error) = result { message = error.localizedDescription }
                }
            .alert("提示", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("知道了", role: .cancel) { message = nil }
            } message: { Text(message ?? "") }
    }
}
