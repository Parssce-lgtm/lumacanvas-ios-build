import SwiftUI
import UniformTypeIdentifiers

struct GalleryView: View {
    let store: ArtworkStore
    var onContinueEditing: (GeneratedArtwork) -> Void = { _ in }
    @Environment(\.dismiss) private var dismiss
    @State private var items: [ArtworkSummary] = []
    @State private var selected: GeneratedArtwork?
    @State private var shareItem: ArtworkShareItem?
    @State private var deletion: ArtworkSummary?
    @State private var errorMessage: String?
    @State private var loading = true

    var body: some View {
        NavigationStack {
            Group {
                if loading { ProgressView("正在读取图库") }
                else if items.isEmpty {
                    VStack(spacing: 14) {
                        Image(systemName: "photo.on.rectangle").font(.system(size: 42)).foregroundStyle(.secondary)
                        Text("图库还没有图片").font(.headline)
                        Text("生成成功的图片会自动保存在这里").font(.subheadline).foregroundStyle(.secondary)
                    }.accessibilityIdentifier("gallery-empty")
                } else {
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 145), spacing: 14)], spacing: 18) {
                            ForEach(items) { item in
                                Button { withArtwork(item) { selected = $0 } } label: {
                                    VStack(alignment: .leading, spacing: 8) {
                                        GalleryThumbnail(id: item.id, store: store)
                                        Text(item.prompt.isEmpty ? "生成图片" : item.prompt)
                                            .font(.subheadline).lineLimit(2).foregroundStyle(.primary)
                                        Text(item.createdAt, format: .dateTime.month().day().hour().minute())
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                }.buttonStyle(.plain)
                                    .accessibilityLabel("查看图片，\(item.prompt)")
                                    .accessibilityIdentifier("gallery-item-\(item.id.uuidString)")
                                    .contextMenu {
                                        Button { withArtwork(item) { artwork in
                                            do { shareItem = try ArtworkShareItem(artwork) }
                                            catch { errorMessage = error.localizedDescription }
                                        } } label: { Label("分享", systemImage: "square.and.arrow.up") }
                                        Button { withArtwork(item, action: onContinueEditing) } label: {
                                            Label("继续编辑", systemImage: "square.and.pencil")
                                        }
                                        Button(role: .destructive) { deletion = item } label: {
                                            Label("删除照片", systemImage: "trash")
                                        }
                                    }
                            }
                        }.padding(16)
                    }.modifier(SoftTopEdge())
                }
            }.frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Theme.background.ignoresSafeArea())
                .navigationTitle("图库").navigationBarTitleDisplayMode(.large)
                .toolbar { ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") { dismiss() }
                } }
        }.tint(Theme.accent)
            .modifier(SwipeBack(enabled: selected == nil && shareItem == nil && deletion == nil) { dismiss() })
            .task { await reload() }
            .onReceive(NotificationCenter.default.publisher(for: .artworkGalleryChanged).receive(on: DispatchQueue.main)) { _ in
                Task { await reload() }
            }
            .fullScreenCover(item: $selected) { artwork in
                GalleryArtworkView(artwork: artwork, onContinueEditing: onContinueEditing)
            }
            .sheet(item: $shareItem) { ArtworkShareSheet(item: $0) }
            .confirmationDialog("删除这张照片？", isPresented: Binding(get: { deletion != nil }, set: { if !$0 { deletion = nil } }), titleVisibility: .visible) {
                Button("删除照片", role: .destructive) {
                    guard let item = deletion else { return }
                    deletion = nil
                    Task {
                        do { try await store.delete(item.id); await reload() }
                        catch { errorMessage = error.localizedDescription }
                    }
                }
                Button("取消", role: .cancel) { deletion = nil }
            } message: { Text("仅从应用图库删除，不影响已保存到相册或文件的图片。") }
            .alert("提示", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("知道了", role: .cancel) { errorMessage = nil }
            } message: { Text(errorMessage ?? "") }
    }
    private func withArtwork(_ item: ArtworkSummary, action: @escaping (GeneratedArtwork) -> Void) {
        Task { @MainActor in
            do { action(try await store.artwork(item.id)) }
            catch { errorMessage = error.localizedDescription }
        }
    }
    @MainActor private func reload() async {
        defer { loading = false }
        do { items = try await store.list() }
        catch { errorMessage = error.localizedDescription }
    }
}

private struct GalleryThumbnail: View {
    let id: UUID
    let store: ArtworkStore
    @State private var image: UIImage?
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Theme.canvas
                if let image {
                    Image(uiImage: image).resizable().scaledToFill()
                        .frame(width: geometry.size.width, height: geometry.size.height).clipped()
                } else { Image(systemName: "photo").foregroundStyle(.secondary) }
            }
        }.aspectRatio(0.85, contentMode: .fit).clipShape(RoundedRectangle(cornerRadius: 18))
            .task(id: id) {
                let data = try? await store.thumbnail(id)
                if let data { image = UIImage(data: data) }
            }
    }
}

private struct GalleryArtworkView: View {
    let artwork: GeneratedArtwork
    let onContinueEditing: (GeneratedArtwork) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var fullScreen = false
    @State private var artworkFrame: CGRect = .zero
    @State private var exporting = false
    @State private var shareItem: ArtworkShareItem?
    @State private var saving = false
    @State private var message: String?
    private var image: UIImage? { UIImage(data: artwork.pngData) }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    if let image {
                        Button { fullScreen = true } label: {
                            Image(uiImage: image).resizable().scaledToFit()
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                        }.buttonStyle(.plain).accessibilityLabel("放大图片")
                            .modifier(ArtworkFrameReader())
                            .onPreferenceChange(ArtworkFramePreference.self) { artworkFrame = $0 }
                    }
                    Button { onContinueEditing(artwork) } label: {
                        Label("继续编辑", systemImage: "square.and.pencil").frame(maxWidth: .infinity, minHeight: 30)
                    }.modifier(GlassButton(primary: true)).accessibilityIdentifier("gallery-edit-button")
                    Text(artwork.prompt).font(.body).textSelection(.enabled)
                    Text("\(artwork.pixelWidth) × \(artwork.pixelHeight) · \(artwork.model)")
                        .font(.caption).foregroundStyle(.secondary)
                    Text(artwork.createdAt, format: .dateTime.year().month().day().hour().minute())
                        .font(.caption).foregroundStyle(.secondary)
                }.padding(16)
            }.modifier(SoftTopEdge()).background(Theme.background.ignoresSafeArea())
                .navigationTitle("图片").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button { dismiss() } label: { Image(systemName: "chevron.left") }.accessibilityLabel("返回图库")
                    }
                    ToolbarItemGroup(placement: .navigationBarTrailing) {
                        Button {
                            do { shareItem = try ArtworkShareItem(artwork) }
                            catch { message = error.localizedDescription }
                        } label: { Image(systemName: "square.and.arrow.up") }.accessibilityLabel("分享图片")
                        Button("完成") { dismiss() }
                    }
                }
                .safeAreaInset(edge: .bottom) {
                    HStack(spacing: 12) {
                        Button {
                            guard !saving else { return }
                            saving = true
                            Task {
                                defer { saving = false }
                                do { try await PhotoLibraryService.save(pngData: artwork.pngData); message = "已保存到相册" }
                                catch { message = error.localizedDescription }
                            }
                        } label: {
                            Label(saving ? "正在保存" : "保存相册", systemImage: "square.and.arrow.down")
                                .frame(maxWidth: .infinity, minHeight: 30)
                        }.modifier(GlassButton(clear: true)).accessibilityIdentifier("gallery-save-button")
                        Button { exporting = true } label: {
                            Label("转存文件", systemImage: "folder").frame(maxWidth: .infinity, minHeight: 30)
                        }.modifier(GlassButton(clear: true)).accessibilityIdentifier("gallery-export-button")
                    }.padding(16)
                }
        }.tint(Theme.accent)
            .modifier(SwipeBack(enabled: !fullScreen && !exporting && shareItem == nil) { dismiss() })
            .modifier(ArtworkZoomPresentation(isPresented: $fullScreen, image: image, sourceFrame: artworkFrame))
            .sheet(item: $shareItem) { ArtworkShareSheet(item: $0) }
            .fileExporter(isPresented: $exporting, document: PNGDocument(data: artwork.pngData),
                contentType: .png, defaultFilename: artwork.fileName) { result in
                    if case .failure(let error) = result { message = error.localizedDescription }
                }
            .alert("提示", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("知道了", role: .cancel) { message = nil }
            } message: { Text(message ?? "") }
    }
}
