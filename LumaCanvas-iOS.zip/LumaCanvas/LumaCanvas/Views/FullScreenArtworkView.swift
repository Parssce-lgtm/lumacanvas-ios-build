import SwiftUI

struct FullScreenArtworkView: View {
    let image: UIImage
    @Environment(\.dismiss) private var dismiss
    @State private var scale: CGFloat = 1
    @GestureState private var gestureScale: CGFloat = 1
    @State private var offset: CGSize = .zero
    @GestureState private var drag: CGSize = .zero

    var body: some View {
        ZStack {
            Color.black.opacity(scale > 1 ? 1 : max(0.3, 1 - Double(abs(drag.height)) / 500)).ignoresSafeArea()
            GeometryReader { geometry in
                Image(uiImage: image)
                    .resizable().scaledToFit()
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .scaleEffect(min(5, max(1, scale * gestureScale)))
                    .offset(x: offset.width + drag.width, y: offset.height + drag.height)
                    .gesture(MagnificationGesture()
                        .updating($gestureScale) { value, state, _ in state = value }
                        .onEnded { value in
                            scale = min(5, max(1, scale * value))
                            if scale == 1 { offset = .zero }
                        })
                    .simultaneousGesture(DragGesture()
                        .updating($drag) { value, state, _ in state = value.translation }
                        .onEnded { value in
                            if scale > 1 {
                                offset.width += value.translation.width
                                offset.height += value.translation.height
                            } else if abs(value.translation.height) > 90 || abs(value.predictedEndTranslation.height) > 180 {
                                dismiss()
                            }
                        })
                    .onTapGesture(count: 2) { withAnimation { scale = scale == 1 ? 2 : 1; offset = .zero } }
            }.clipped()
            VStack {
                HStack {
                    Button { scale = 1; offset = .zero } label: {
                        Label("重置", systemImage: "arrow.counterclockwise")
                            .font(.system(size: 13)).padding(12)
                            .background(.white.opacity(0.15), in: Capsule())
                    }
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark").font(.system(size: 16, weight: .semibold))
                            .frame(width: 42, height: 42).background(.white.opacity(0.15), in: Circle())
                    }.accessibilityLabel("关闭全屏预览")
                }.padding(20)
                Spacer()
                Text("双指缩放 · 双击放大 · 上下滑动关闭")
                    .font(.system(size: 12)).foregroundStyle(.white.opacity(0.6)).padding(.bottom, 20)
            }.foregroundStyle(.white)
        }
        .statusBarHidden()
    }
}
