import SwiftUI
import UIKit

enum Theme {
    static let background = Color(uiColor: .systemGroupedBackground)
    static let ink = Color.primary
    static let muted = Color.secondary
    static let accent = Color(uiColor: .systemBlue)
    static let canvas = Color(uiColor: .secondarySystemGroupedBackground)
}

private struct DrawerProgressKey: EnvironmentKey {
    static let defaultValue: CGFloat = 0
}

extension EnvironmentValues {
    var drawerProgress: CGFloat {
        get { self[DrawerProgressKey.self] }
        set { self[DrawerProgressKey.self] = newValue }
    }
}

struct GlassSurface: ViewModifier {
    var capsule = false
    var primary = false
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            if capsule {
                content.glassEffect(primary ? .regular.tint(Theme.accent).interactive() : .regular.interactive(), in: Capsule())
            } else { content.glassEffect(.regular, in: RoundedRectangle(cornerRadius: 24)) }
        } else {
            if capsule {
                content.background(primary ? AnyShapeStyle(Theme.accent) : AnyShapeStyle(.ultraThinMaterial), in: Capsule())
            } else { content.background(.regularMaterial, in: RoundedRectangle(cornerRadius: 24)) }
        }
    }
}

struct SoftButtonStyle: ButtonStyle {
    var primary = false
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .semibold))
            .frame(maxWidth: .infinity, minHeight: 52)
            .foregroundStyle(primary ? Color.white : Theme.ink)
            .modifier(GlassSurface(capsule: true, primary: primary))
            .opacity(enabled ? (configuration.isPressed ? 0.72 : 1) : 0.4)
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.easeOut(duration: 0.18), value: configuration.isPressed)
    }
}

/// Native button styles keep the system's touch and long-press glass animation.
struct GlassButton: ViewModifier {
    var primary = false
    var compact = false
    var clear = false
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            if primary {
                content.buttonStyle(.glassProminent).buttonBorderShape(.capsule).controlSize(compact ? .small : .large)
            } else {
                content.buttonStyle(.glass(clear ? .clear : .regular)).buttonBorderShape(.capsule).controlSize(compact ? .small : .large)
            }
        } else { content.buttonStyle(SoftButtonStyle(primary: primary)) }
    }
}

struct SoftTopEdge: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.scrollEdgeEffectStyle(.soft, for: .top).scrollEdgeEffectHidden(true, for: .bottom)
        } else { content }
    }
}

/// Explicit transparent glass avoids the native capsule style's additional adaptive fill.
struct CanvasActionStyle: ButtonStyle {
    var primary = false
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 17, weight: .semibold))
            .padding(.horizontal, 16)
            .frame(maxWidth: .infinity, minHeight: 54)
            .foregroundStyle(primary ? Color.white : Theme.accent)
            .contentShape(Capsule())
            .modifier(CanvasActionSurface(primary: primary))
            .modifier(RatioPressFeedback(isPressed: configuration.isPressed))
    }
}

private struct CanvasActionSurface: ViewModifier {
    let primary: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            if primary { content.glassEffect(.clear.tint(Theme.accent).interactive(), in: Capsule()) }
            else { content.glassEffect(.clear.interactive(), in: Capsule()) }
        } else {
            content.background(primary ? Theme.accent : Theme.canvas.opacity(0.55), in: Capsule())
        }
    }
}

struct CanvasActionGroup: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { GlassEffectContainer(spacing: 8) { content } }
        else { content }
    }
}

struct UnclippedScroll: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 17.0, *) { content.scrollClipDisabled() }
        else { content }
    }
}

/// Selection keeps one glass surface; a tap never replaces the button style.
struct RatioGlassStyle: ButtonStyle {
    var selected = false
    var circular = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(selected ? Color.white : Theme.ink)
            .modifier(RatioGlassSurface(selected: selected, circular: circular))
            .modifier(RatioPressFeedback(isPressed: configuration.isPressed))
    }
}

private struct RatioGlassSurface: ViewModifier {
    let selected: Bool
    let circular: Bool

    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            if circular {
                content.glassEffect(.regular.tint(selected ? Theme.accent : .clear).interactive(), in: Circle())
            } else {
                content.glassEffect(.regular.tint(selected ? Theme.accent : .clear).interactive(), in: Capsule())
            }
        } else {
            if circular {
                content.background(selected ? AnyShapeStyle(Theme.accent) : AnyShapeStyle(.ultraThinMaterial), in: Circle())
            } else {
                content.background(selected ? AnyShapeStyle(Theme.accent) : AnyShapeStyle(.ultraThinMaterial), in: Capsule())
            }
        }
    }
}

private struct RatioPressFeedback: ViewModifier {
    let isPressed: Bool
    @State private var highlighted = false
    @State private var releaseTask: Task<Void, Never>?

    func body(content: Content) -> some View {
        content
            .scaleEffect(highlighted ? 0.93 : 1)
            .brightness(highlighted ? 0.04 : 0)
            .animation(.spring(response: 0.22, dampingFraction: 0.8), value: highlighted)
            .onChange(of: isPressed) { pressed in
                releaseTask?.cancel()
                if pressed { highlighted = true }
                else {
                    // Keep quick taps visible without delaying selection on release.
                    releaseTask = Task { @MainActor in
                        do { try await Task.sleep(nanoseconds: 100_000_000) }
                        catch { return }
                        highlighted = false
                    }
                }
            }
            .onDisappear { releaseTask?.cancel() }
    }
}
