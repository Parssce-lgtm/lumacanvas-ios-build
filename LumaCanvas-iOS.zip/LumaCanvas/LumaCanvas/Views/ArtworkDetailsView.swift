import SwiftUI

struct ArtworkDetailsView: View {
    let artwork: GeneratedArtwork
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section("作品信息") {
                    LabeledContent("服务商", value: artwork.provider)
                    LabeledContent("模型", value: artwork.model)
                    LabeledContent("尺寸", value: "\(artwork.pixelWidth) × \(artwork.pixelHeight)")
                    LabeledContent("格式", value: "PNG")
                    LabeledContent("时间") { Text(artwork.createdAt, format: .dateTime) }
                }
                Section("你的提示词") { Text(artwork.prompt).textSelection(.enabled) }
                if let revised = artwork.revisedPrompt, !revised.isEmpty {
                    Section("服务返回的提示词") { Text(revised).textSelection(.enabled) }
                }
            }
            .navigationTitle("作品信息").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
        }
        .tint(Theme.accent)
    }
}
