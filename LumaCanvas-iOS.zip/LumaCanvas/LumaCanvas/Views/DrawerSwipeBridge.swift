import SwiftUI
import UIKit

/// One native horizontal gesture; moving a finger does not re-render message text.
struct DrawerSwipeBridge: UIViewRepresentable {
    var openAnywhere: Bool
    var presented: Bool
    var change: (Bool) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> Surface {
        let view = Surface()
        view.isUserInteractionEnabled = false
        view.moved = { [weak coordinator = context.coordinator] window in coordinator?.attach(window) }
        return view
    }
    func updateUIView(_ view: Surface, context: Context) { context.coordinator.parent = self }
    static func dismantleUIView(_ view: Surface, coordinator: Coordinator) { coordinator.attach(nil) }
    final class Surface: UIView {
        var moved: ((UIWindow?) -> Void)?
        override func didMoveToWindow() { super.didMoveToWindow(); moved?(window) }
    }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var parent: DrawerSwipeBridge
        weak var window: UIWindow?
        private lazy var pan = UIPanGestureRecognizer(target: self, action: #selector(swiped(_:)))
        init(_ parent: DrawerSwipeBridge) { self.parent = parent }
        func attach(_ next: UIWindow?) {
            guard window !== next else { return }
            window?.removeGestureRecognizer(pan); window = next
            pan.delegate = self; pan.cancelsTouchesInView = false
            pan.delaysTouchesBegan = false; pan.delaysTouchesEnded = false
            next?.addGestureRecognizer(pan)
        }
        @objc private func swiped(_ gesture: UIPanGestureRecognizer) {
            guard gesture.state == .ended else { return }
            let travel = gesture.translation(in: window).x
            let speed = gesture.velocity(in: window).x
            if !parent.presented, travel > 42 || (travel > 12 && speed > 450) { parent.change(true) }
            else if parent.presented, travel < -42 || (travel < -12 && speed < -450) { parent.change(false) }
        }
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            let velocity = pan.velocity(in: window)
            guard abs(velocity.x) > abs(velocity.y) * 1.35 else { return false }
            if parent.presented { return velocity.x < 0 }
            let origin = pan.location(in: window).x - pan.translation(in: window).x
            return velocity.x > 0 && (parent.openAnywhere || origin < 32)
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
    }
}

/// Observe header taps at the window so transparent SwiftUI layers cannot eat them.
struct DrawerToggleButton: UIViewRepresentable {
    let identifier: String
    let action: () -> Void
    func makeCoordinator() -> Coordinator { Coordinator(action) }
    func makeUIView(context: Context) -> Surface {
        let button = Surface(type: .custom)
        button.setImage(UIImage(systemName: "line.3.horizontal", withConfiguration: UIImage.SymbolConfiguration(pointSize: 22, weight: .medium)), for: .normal)
        button.tintColor = .label
        button.accessibilityLabel = "更多"
        button.accessibilityIdentifier = identifier
        button.moved = { [weak coordinator = context.coordinator, weak button] in coordinator?.attach(button) }
        button.addTarget(context.coordinator, action: #selector(Coordinator.accessibilityActivate), for: .touchUpInside)
        return button
    }
    func updateUIView(_ view: Surface, context: Context) { context.coordinator.action = action }
    static func dismantleUIView(_ view: Surface, coordinator: Coordinator) { coordinator.attach(nil) }
    final class Surface: UIButton {
        var moved: (() -> Void)?
        override func didMoveToWindow() { super.didMoveToWindow(); moved?() }
    }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var action: () -> Void
        weak var button: UIButton?
        weak var window: UIWindow?
        private lazy var tap = UITapGestureRecognizer(target: self, action: #selector(tapped(_:)))
        init(_ action: @escaping () -> Void) { self.action = action }
        func attach(_ button: UIButton?) {
            window?.removeGestureRecognizer(tap)
            self.button = button; window = button?.window
            tap.delegate = self; tap.cancelsTouchesInView = false
            tap.delaysTouchesBegan = false; tap.delaysTouchesEnded = false
            window?.addGestureRecognizer(tap)
        }
        @objc func accessibilityActivate() { action() }
        @objc private func tapped(_ gesture: UITapGestureRecognizer) { if gesture.state == .ended { action() } }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            guard let button, let window, !button.isHidden, button.alpha > 0.01 else { return false }
            return button.convert(button.bounds, to: window).contains(touch.location(in: window))
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
    }
}
