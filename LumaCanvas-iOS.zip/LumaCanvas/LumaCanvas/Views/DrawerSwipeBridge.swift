import SwiftUI
import UIKit

/// A non-exclusive window gesture also receives swipes that start inside a scroll view.
struct DrawerSwipeBridge: UIViewRepresentable {
    var openAnywhere: Bool
    var presented: Bool
    var change: (Bool) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> Surface {
        let view = Surface()
        view.isUserInteractionEnabled = false
        view.moved = { [weak coordinator = context.coordinator] window in coordinator?.attach(window) }
        return view
    }
    func updateUIView(_ view: Surface, context: Context) {
        context.coordinator.parent = self
        context.coordinator.configure()
    }
    static func dismantleUIView(_ view: Surface, coordinator: Coordinator) { coordinator.attach(nil) }
    final class Surface: UIView {
        var moved: ((UIWindow?) -> Void)?
        override func didMoveToWindow() { super.didMoveToWindow(); moved?(window) }
    }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var parent: DrawerSwipeBridge
        weak var window: UIWindow?
        private lazy var right = UISwipeGestureRecognizer(target: self, action: #selector(open(_:)))
        private lazy var left = UISwipeGestureRecognizer(target: self, action: #selector(close(_:)))
        init(_ parent: DrawerSwipeBridge) { self.parent = parent }
        func attach(_ next: UIWindow?) {
            guard window !== next else { return }
            window?.removeGestureRecognizer(right); window?.removeGestureRecognizer(left)
            window = next
            right.direction = .right; left.direction = .left
            for gesture in [right, left] {
                gesture.delegate = self; gesture.cancelsTouchesInView = false
                next?.addGestureRecognizer(gesture)
            }
            configure()
        }
        func configure() { right.isEnabled = parent.openAnywhere && !parent.presented; left.isEnabled = parent.presented }
        @objc private func open(_ gesture: UISwipeGestureRecognizer) { if gesture.state == .ended { parent.change(true) } }
        @objc private func close(_ gesture: UISwipeGestureRecognizer) { if gesture.state == .ended { parent.change(false) } }
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            // Modal settings, gallery and share pages keep their own gestures.
            window?.rootViewController?.presentedViewController == nil
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool { true }
    }
}
