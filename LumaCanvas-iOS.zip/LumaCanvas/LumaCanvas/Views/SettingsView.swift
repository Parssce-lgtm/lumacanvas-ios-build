import SwiftUI

struct SettingsView: View {
    @ObservedObject var store: ConfigurationStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: APIConfiguration
    @State private var revealKey = false
    @State private var errorMessage: String?
    @State private var models: [ModelOption] = []
    @State private var fetchingModels = false
    @State private var modelsTask: Task<Void, Never>?
    @State private var showModels = false
    @State private var selectingChatModel = false
    @State private var showDeleteConfirmation = false
    @State private var statusMessage: String?
    @State private var discoveryTask: Task<Void, Never>?
    @State private var discovering = false
    @State private var siteFromSwitch: String?
    @State private var probeTask: Task<Void, Never>?
    @State private var probeID: UUID?
    @State private var probeResult: ModelProbeResult?
    @State private var modelsRequestID: UUID?

    init(store: ConfigurationStore) {
        self.store = store
        _draft = State(initialValue: store.value)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("已保存实例", selection: Binding(
                        get: { draft.id },
                        set: { switchInstance($0) }
                    )) {
                        ForEach(store.instances, id: \.id) { Text($0.name).tag($0.id) }
                    }
                    field("实例名称", text: $draft.name, placeholder: "例如 我的生图 API")
                } footer: {
                    Text("切换时自动保存当前表单，每个实例独立保留。")
                }

                apiSection

                chatSection

                modelListSection

                Section {
                    field("默认尺寸偏好", text: $draft.size, placeholder: "auto")
                    if draft.mode == .images {
                        field("画质（留空则不发送）", text: $draft.quality, placeholder: "例如 auto / high / medium / low")
                        Picker("返回格式", selection: $draft.responseFormat) {
                            Text("自动（不发送参数）").tag("")
                            Text("图片 URL").tag("url")
                            Text("Base64").tag("b64_json")
                        }
                    } else {
                        if draft.isNAIModel {
                            Picker("NAI 请求格式", selection: $draft.naiChatFormat) {
                                ForEach(NAIChatFormat.allCases) { Text($0.title).tag($0) }
                            }
                        }
                        Toggle("流式返回", isOn: $draft.chatStreaming)
                            .accessibilityIdentifier("chat-streaming-toggle")
                    }
                    Stepper(value: $draft.timeout, in: 30...600, step: 30) {
                        Text("等待超时：\(Int(draft.timeout)) 秒")
                    }
                } header: {
                    Text("生成参数")
                } footer: {
                    if draft.usesNAIParameters {
                        Text("自动识别 Rinko 的 NAI 参数协议，将提示词和尺寸编码在消息内。自动尺寸由服务商决定，默认 23 步；本版该模式仅支持文生图，不发送服务商未支持的 moderation 参数。其他网关可手动选择请求格式。")
                    } else {
                        Text(draft.mode == .images ? "GPT Image 模型请保持返回格式为“自动”。参考图使用 images/edits，服务商与模型须支持图片编辑。" : "流式返回发送 stream=true，服务商支持时可减少长时间无回包引起的网关超时，不保证解决上游超时。参考图作为图片消息发送；审查的高/低发送 moderation=auto/low，关不发送，不支持该扩展时请选择关。")
                    }
                }

                Section {
                    Picker("请求传输", selection: $draft.transfer) {
                        ForEach(GenerationTransfer.allCases) { Text($0.title).tag($0) }
                    }.accessibilityIdentifier("request-transfer-picker")
                } header: { Text("连接方式") } footer: {
                    Text("默认使用常规 POST，提高第三方接口兼容性，可获得短时后台运行时间。系统后台传输可在界面挂起后继续，部分服务商可能不兼容。切换不会重发已经提交的请求。")
                }

                Section {
                    jsonEditor("额外请求参数 JSON", text: $draft.extraBody)
                    jsonEditor("额外请求头 JSON", text: $draft.extraHeaders)
                } header: {
                    Text("高级设置")
                } footer: {
                      Text("标准 Images 可添加 {\"background\":\"transparent\",\"output_format\":\"png\"}。对话式参数以服务商文档为准。请求头的值必须是字符串。内置字段不能被覆盖，支持 JSON 与流式图片返回。")
                  }

                Section {
                    Button("保存为新实例") {
                        do { stopRequests(); draft = try store.saveAsNew(draft); statusMessage = "已保存为新实例" }
                        catch { errorMessage = error.localizedDescription }
                    }
                    Text("提示词将发送至上方配置的服务。生成成功的图片和提示词保存在本机图库，可随时查看、保存或导出。")
                        .font(.caption).foregroundStyle(.secondary)
                    Button("删除当前实例", role: .destructive) { showDeleteConfirmation = true }
                        .accessibilityIdentifier("delete-instance-button")
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .modifier(SoftTopEdge())
            .scrollContentBackground(.hidden)
            .background(Theme.background)
            .navigationTitle("API 设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") {
                        do { stopRequests(); try store.save(draft); dismiss() }
                        catch { errorMessage = error.localizedDescription }
                    }.fontWeight(.semibold)
                }
            }
            .tint(Theme.accent)
            .alert("设置提示", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("知道了", role: .cancel) { errorMessage = nil }
            } message: { Text(errorMessage ?? "") }
            .alert("是否删除？", isPresented: $showDeleteConfirmation) {
                Button("删除", role: .destructive) {
                    do {
                        stopRequests()
                        let selected = try store.delete(draft.id)
                        siteFromSwitch = selected.site
                        draft = selected
                        models = []; probeResult = nil
                        statusMessage = selected.site.isEmpty ? "请填写新的 API 配置" : "已删除实例"
                    }
                    catch { errorMessage = error.localizedDescription }
                }
                Button("取消", role: .cancel) {}
            } message: { Text("删除“\(draft.name)”及其配置和密钥？") }
            .sheet(isPresented: $showModels) {
                ModelPickerView(models: models, forChat: selectingChatModel) { selected in
                    if selectingChatModel { draft.conversationModel = selected }
                    else { draft.model = selected }
                    showModels = false
                }
            }
            .onChange(of: draft.site) { value in
                if siteFromSwitch == value { siteFromSwitch = nil }
                else { siteFromSwitch = nil; scheduleDetection() }
            }
            .onChange(of: draft) { _ in
                cancelProbe()
                probeResult = nil
                models = models.map { var item = $0; if item.tested { item.imageGeneration = nil }; item.tested = false; return item }
            }
            .onChange(of: draft.endpoint) { _ in models = [] }
            .onChange(of: draft.modelsEndpoint) { _ in models = [] }
            .onChange(of: draft.apiKey) { _ in models = [] }
            .onDisappear {
                stopRequests()
                do { try store.save(draft) } catch { store.loadError = error.localizedDescription }
            }
        }
    }

    private var apiSection: some View {
        Section("接口与密钥") {
            field("API 站点", text: $draft.site, placeholder: "https://api.example.com", keyboard: .URL)
            Button { detectSite() } label: {
                HStack { Text("检测接口地址"); Spacer(); if discovering { ProgressView() } }
            }.disabled(discovering || draft.site.isEmpty)
            Picker("接口模式", selection: Binding(
                get: { draft.mode },
                set: { mode in
                    draft.mode = mode
                    if let url = URL(string: draft.endpoint),
                       url.path.hasSuffix("/images/generations") || url.path.hasSuffix("/chat/completions") {
                        let base = url.deletingLastPathComponent().deletingLastPathComponent()
                        draft.endpoint = base.appendingPathComponent(mode == .images ? "images/generations" : "chat/completions").absoluteString
                    }
                }
            )) {
                ForEach(GenerationMode.allCases) { Text($0.title).tag($0) }
            }
            field("完整生图地址", text: $draft.endpoint, placeholder: "https://example.com/v1/images/generations", keyboard: .URL)
            if draft.mode == .images {
                field("参考图生图地址（可留空自动推导）", text: $draft.editsEndpoint, placeholder: "https://example.com/v1/images/edits", keyboard: .URL)
            }
            VStack(alignment: .leading, spacing: 8) {
                Text("API Key").font(.caption).foregroundStyle(.secondary)
                HStack {
                    Group {
                        if revealKey { TextField("sk-…", text: $draft.apiKey) }
                        else { SecureField("sk-…", text: $draft.apiKey) }
                    }
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .privacySensitive()
                    Button { revealKey.toggle() } label: {
                        Image(systemName: revealKey ? "eye.slash" : "eye")
                    }.accessibilityLabel(revealKey ? "隐藏密钥" : "显示密钥")
                    .buttonStyle(.borderless)
                }
            }.padding(.vertical, 4)
            field("模型", text: $draft.model, placeholder: "填写服务商支持的生图模型")
        }
    }

    private var chatSection: some View {
        Section {
            field("聊天模型", text: $draft.conversationModel, placeholder: "填写模型名称，或读取列表后选择")
            field("完整聊天地址（留空自动推导）", text: $draft.conversationEndpoint,
                  placeholder: "https://example.com/v1/chat/completions", keyboard: .URL)
            Button {
                selectingChatModel = true
                if models.isEmpty { loadModels() } else { showModels = true }
            } label: {
                HStack { Label("选择聊天模型", systemImage: "bubble.left.and.bubble.right"); Spacer(); if fetchingModels { ProgressView() } }
            }.disabled(fetchingModels).accessibilityIdentifier("select-chat-model-button")
        } header: { Text("聊天") } footer: {
            Text("聊天使用当前实例的密钥和请求头，与生图模型独立保存。支持 OpenAI 兼容 Chat Completions 接口；自定义聊天地址可单独填写。")
        }
    }

    private var modelListSection: some View {
        Section {
            field("模型列表地址", text: $draft.modelsEndpoint, placeholder: "https://example.com/v1/models", keyboard: .URL)
            Button {
                selectingChatModel = false
                loadModels()
            } label: {
                HStack {
                    Label("读取模型列表", systemImage: "arrow.triangle.2.circlepath")
                    Spacer()
                    if fetchingModels { ProgressView() }
                }
            }.disabled(fetchingModels)
            Button { testModel() } label: {
                HStack {
                    Label("测试模型", systemImage: "checkmark.shield")
                    Spacer()
                    if probeID != nil { ProgressView() }
                }
            }.disabled(probeID != nil).accessibilityIdentifier("test-model-button")
            if probeID != nil {
                Button("停止测试", role: .cancel) { cancelProbe() }
            }
            if let probeResult {
                VStack(alignment: .leading, spacing: 6) {
                    Text(probeResult.title).font(.subheadline.weight(.semibold))
                        .accessibilityIdentifier("model-test-result")
                    Text(probeResult.detail).font(.caption).foregroundStyle(.secondary)
                }
            }
            if !models.isEmpty {
                Button("选择模型（\(models.count) 个）") { selectingChatModel = false; showModels = true }
            }
            if let statusMessage {
                Text(statusMessage).font(.caption).foregroundStyle(.secondary)
            }
        } footer: {
            Text("读取列表不提交生图请求。测试模型使用当前填写的模型和参数生成一张简单图片，可能计费，不自动重试；停止等待后服务端可能继续处理。地址均可手动修改。")
        }
    }

    private func field(_ title: String, text: Binding<String>, placeholder: String, keyboard: UIKeyboardType = .default) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            TextField(placeholder, text: text)
                .keyboardType(keyboard).textInputAutocapitalization(.never).autocorrectionDisabled()
                .font(.system(size: 14))
                .accessibilityLabel(title)
        }.padding(.vertical, 5)
    }

    private func jsonEditor(_ title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            TextEditor(text: text)
                .font(.system(size: 12, design: .monospaced))
                .frame(minHeight: 82)
                .textInputAutocapitalization(.never).autocorrectionDisabled()
                .privacySensitive().accessibilityLabel(title)
        }.padding(.vertical, 5)
    }

    private func loadModels() {
        modelsTask?.cancel()
        fetchingModels = true
        let snapshot = draft
        let requestID = UUID()
        modelsRequestID = requestID
        modelsTask = Task { @MainActor in
            defer { if modelsRequestID == requestID { fetchingModels = false; modelsTask = nil } }
            do {
                var modelConfiguration = snapshot
                if selectingChatModel { modelConfiguration.endpoint = try snapshot.conversationURL().absoluteString }
                var fetched = try await apiClient().fetchModelCatalog(configuration: modelConfiguration)
                try Task.checkCancellation()
                guard modelsRequestID == requestID, draft == snapshot else { return }
                if probeResult?.status == .available {
                    fetched.removeAll { $0.id == draft.model }
                    fetched.append(ModelOption(id: draft.model, imageGeneration: true, tested: true))
                }
                models = ModelOption.ordered(fetched)
                if models.isEmpty { statusMessage = "接口可连接，但模型列表为空。" }
                else { statusMessage = "接口可连接，已读取 \(models.count) 个模型。"; showModels = true }
            } catch is CancellationError { }
            catch let error as URLError where error.code == .cancelled { }
            catch { if modelsRequestID == requestID, draft == snapshot { errorMessage = error.localizedDescription } }
        }
    }

    private func apiClient() -> ImageAPIClient {
        #if DEBUG
        if UITestFixtures.enabled { return UITestFixtures.client() }
        #endif
        return ImageAPIClient()
    }

    private func testModel() {
        cancelProbe()
        let snapshot = draft
        let id = UUID()
        probeID = id
        probeResult = nil
        let client = apiClient()
        probeTask = Task { @MainActor in
            defer { if probeID == id { probeID = nil; probeTask = nil } }
            do {
                let result = try await ModelProbe(client: client).test(configuration: snapshot)
                try Task.checkCancellation()
                guard probeID == id, draft == snapshot else { return }
                probeResult = result
                if result.status == .available {
                    models.removeAll { $0.id == snapshot.model }
                    models.append(ModelOption(id: snapshot.model, imageGeneration: true, tested: true))
                    models = ModelOption.ordered(models)
                }
            } catch { }
        }
    }

    private func cancelProbe() {
        probeTask?.cancel(); probeTask = nil; probeID = nil
    }

    private func stopRequests() {
        cancelProbe()
        modelsRequestID = nil
        modelsTask?.cancel(); modelsTask = nil; fetchingModels = false
        discoveryTask?.cancel(); discoveryTask = nil; discovering = false
    }

    private func switchInstance(_ id: UUID) {
        stopRequests()
        do {
            let selected = try store.select(id, saving: draft)
            siteFromSwitch = selected.site
            draft = selected
            models = []; statusMessage = nil
        }
        catch { errorMessage = error.localizedDescription }
    }

    private func scheduleDetection() {
        discoveryTask?.cancel()
        guard !draft.site.isEmpty, let routes = try? SiteDiscovery.defaults(site: draft.site, mode: draft.mode) else { return }
        draft.endpoint = routes.0
        draft.modelsEndpoint = routes.1
        discoveryTask = Task { @MainActor in
            do { try await Task.sleep(nanoseconds: 900_000_000); try Task.checkCancellation(); detectSite() }
            catch { }
        }
    }

    private func detectSite() {
        discoveryTask?.cancel()
        let snapshot = draft
        discovering = true
        discoveryTask = Task { @MainActor in
            defer { discovering = false }
            do {
                let (detected, message) = try await SiteDiscovery.detect(snapshot)
                try Task.checkCancellation()
                guard draft.id == snapshot.id, draft.site == snapshot.site,
                      draft.endpoint == snapshot.endpoint, draft.modelsEndpoint == snapshot.modelsEndpoint else { return }
                draft.mode = detected.mode
                draft.endpoint = detected.endpoint
                draft.modelsEndpoint = detected.modelsEndpoint
                statusMessage = message
            } catch is CancellationError { }
            catch let error as URLError where error.code == .cancelled { }
            catch { statusMessage = error.localizedDescription }
        }
    }
}

struct ModelPickerView: View {
    let models: [ModelOption]
    var forChat = false
    let select: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var search = ""

    private var filtered: [ModelOption] {
        ModelOption.ordered(search.isEmpty ? models : models.filter { $0.id.localizedCaseInsensitiveContains(search) })
    }

    private func rows(_ options: [ModelOption]) -> some View {
        ForEach(options) { model in
            Button { select(model.id) } label: {
                HStack {
                    Text(model.id).font(.system(size: 13, design: .monospaced)).foregroundStyle(Theme.ink)
                    Spacer()
                    if !model.evidence.isEmpty { Text(model.evidence).font(.caption2).foregroundStyle(.secondary) }
                }
            }.accessibilityIdentifier("model-" + model.id)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                let images = filtered.filter { $0.isImageCandidate }
                let others = filtered.filter { !$0.isImageCandidate }
                if forChat {
                    if !others.isEmpty { Section("聊天候选（\(others.count)）") { rows(others) } }
                    if !images.isEmpty { Section("图片模型（\(images.count)）") { rows(images) } }
                } else {
                    if !images.isEmpty { Section("图片生成（\(images.count)）") { rows(images) } }
                    if !others.isEmpty { Section("其他模型（\(others.count)）") { rows(others) } }
                }
                Section {
                    if filtered.isEmpty { Text("没有匹配的模型").foregroundStyle(.secondary) }
                } footer: { Text("分组依据接口能力、测试结果或名称。名称识别仅供参考，实际能否生图请测试当前模型。") }
            }
            .searchable(text: $search, prompt: "搜索 image、模型名称…")
            .navigationTitle(forChat ? "选择聊天模型" : "选择模型").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
        }
    }
}

