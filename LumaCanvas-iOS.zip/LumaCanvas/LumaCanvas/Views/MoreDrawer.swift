import SwiftUI

struct MoreDrawer: ViewModifier {
    @Binding var isPresented: Bool
    let openGallery: () -> Void

    func body(content: Content) -> some View {
        GeometryReader { geometry in
            let width = min(340, geometry.size.width * 0.82)
            ZStack(alignment: .leading) {
                Color(uiColor: .systemBackground).ignoresSafeArea()
                if isPresented {
                    VStack(alignment: .leading, spacing: 28) {
                        HStack {
                            Text("映想").font(.largeTitle.bold())
                            Spacer()
                            Button { close() } label: {
                                Image(systemName: "line.3.horizontal")
                                    .font(.system(size: 20)).frame(width: 44, height: 44)
                        }.modifier(GlassButton(compact: true, clear: true))
                                .accessibilityLabel("关闭更多")
                        }.padding(.bottom, 6)
                        Button {
                            close(); openGallery()
                        } label: {
                            Label("图库", systemImage: "photo.on.rectangle")
                                .font(.system(size: 20, weight: .medium))
                                .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 8)
                        }.buttonStyle(.plain).accessibilityIdentifier("more-gallery-button")
                        HStack(spacing: 12) {
                            Image(systemName: "video").font(.system(size: 22))
                            Text("视频生成").font(.system(size: 20, weight: .medium))
                            Spacer(minLength: 4)
                            Text("暂不可用").font(.caption).foregroundStyle(.secondary)
                        }.foregroundStyle(.secondary).padding(.vertical, 8)
                            .accessibilityElement(children: .combine)
                            .accessibilityIdentifier("more-video-unavailable")
                        Spacer()
                    }
                    .foregroundStyle(.primary).padding(.horizontal, 24).padding(.top, 28)
                    .frame(width: width).frame(maxHeight: .infinity, alignment: .topLeading)
                    .transition(.move(edge: .leading).combined(with: .opacity))
                    .accessibilityIdentifier("more-drawer")
                }
                content
                    .accessibilityHidden(isPresented)
                    .overlay {
                        if isPresented {
                            Color.black.opacity(0.025).contentShape(Rectangle())
                                .onTapGesture { close() }
                                .gesture(DragGesture().onEnded { value in
                                    if value.translation.width < -40 { close() }
                                })
                                .accessibilityLabel("关闭更多")
                                .accessibilityAddTraits(.isButton)
                        }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: isPresented ? 26 : 0))
                    .shadow(color: .black.opacity(isPresented ? 0.12 : 0), radius: 22, x: -8)
                    .offset(x: isPresented ? width : 0)
            }
            .animation(.spring(response: 0.32, dampingFraction: 0.9), value: isPresented)
        }
    }
    private func close() { isPresented = false }
}
