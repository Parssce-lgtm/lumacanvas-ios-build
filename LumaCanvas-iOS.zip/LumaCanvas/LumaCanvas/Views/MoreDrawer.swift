import SwiftUI

enum DrawerMotion {
    static func damping(translation: CGFloat, projected: CGFloat, width: CGFloat) -> Double {
        0.84 - min(1, Double(abs(projected - translation) / max(1, width))) * 0.26
    }
}

struct MoreDrawer: ViewModifier {
    @Binding var isPresented: Bool
    let openGallery: () -> Void
    let openImage: () -> Void
    let openChat: () -> Void
    @ObservedObject var chat: ChatViewModel
    let instanceID: UUID
    let newConversation: () -> Void
    let openSettings: () -> Void
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var dragDisplacement: CGFloat?
    @State private var drawerVisible = false
    @State private var closeTapEnabled = false
    @State private var dragOrigin: CGFloat?
    @State private var renaming: ChatConversation?
    @State private var renameText = ""
    @State private var deleting: ChatConversation?
    @State private var hapticTask: Task<Void, Never>?

    private var bottomInset: CGFloat {
        UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }.first(where: { $0.isKeyWindow })?.safeAreaInsets.bottom ?? 0
    }
    func body(content: Content) -> some View {
        GeometryReader { geometry in
            let width = geometry.size.width * 0.75
            let displacement = dragDisplacement ?? (isPresented ? width : 0)
            let progress = min(1, max(0, displacement / width))
            ZStack(alignment: .topLeading) {
                Color(uiColor: .systemBackground).ignoresSafeArea()
                Group {
                    if isPresented || drawerVisible || dragDisplacement != nil {
                    VStack(alignment: .leading, spacing: 0) {
                        Text("映想").font(.title2.bold()).padding(.bottom, 18)
                        Button(action: openGallery) {
                            Label("图库", systemImage: "photo.on.rectangle")
                                .font(.system(size: 17, weight: .medium))
                                .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12).contentShape(Rectangle())
                        }.buttonStyle(.plain).accessibilityIdentifier("more-gallery-button")
                        Divider()
                        Button(action: openImage) {
                            Label("生图", systemImage: "sparkles")
                                .font(.system(size: 17, weight: .medium))
                                .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12).contentShape(Rectangle())
                        }.buttonStyle(.plain).accessibilityIdentifier("more-image-button")
                        Divider()
                        VStack(alignment: .leading, spacing: 3) {
                            Label("视频生成", systemImage: "video").font(.system(size: 16, weight: .medium))
                                .lineLimit(1).minimumScaleFactor(0.8)
                            Text("暂不可用").font(.caption2).padding(.leading, 28)
                        }.foregroundStyle(.secondary).padding(.vertical, 12)
                            .accessibilityElement(children: .combine).accessibilityIdentifier("more-video-unavailable")
                        Divider()
                        ScrollView {
                            LazyVStack(alignment: .leading, spacing: 0) {
                                ForEach(chat.records(for: instanceID)) { record in
                                    Button {
                                        chat.open(record.id, for: instanceID)
                                        openChat()
                                    } label: {
                                        HStack {
                                            Text(record.title).font(.system(size: 16)).lineLimit(1)
                                            Spacer(minLength: 0)
                                            if record.pinned { Image(systemName: "pin.fill").font(.caption).foregroundStyle(.secondary) }
                                        }.frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12).contentShape(Rectangle())
                                    }.buttonStyle(.plain).contextMenu {
                                        Button { renameText = record.title; renaming = record } label: { Label("重命名", systemImage: "pencil") }
                                        Button { chat.togglePin(record.id) } label: { Label(record.pinned ? "取消置顶" : "置顶", systemImage: "pin") }
                                        Button(role: .destructive) { deleting = record } label: { Label("删除聊天", systemImage: "trash") }
                                    }.accessibilityIdentifier("chat-history-\(record.id.uuidString)")
                                }
                                if chat.records(for: instanceID).isEmpty {
                                    Text("暂无聊天记录").font(.footnote).foregroundStyle(.secondary).padding(.vertical, 12)
                                }
                            }
                        }.modifier(HistoryScrollBehavior()).frame(maxWidth: .infinity, maxHeight: .infinity).padding(.top, 14).padding(.bottom, 16)
                        HStack {
                            Button {
                                newConversation()
                                isPresented = false
                            } label: {
                                Label("新对话", systemImage: "square.and.pencil")
                                    .font(.system(size: 16, weight: .semibold))
                                    .frame(width: min(92, max(76, width - 156)), height: 24)
                            }.modifier(GlassButton(primary: true, compact: true))
                                .accessibilityIdentifier("new-conversation-button")
                            Spacer(minLength: 12)
                            Button(action: openSettings) {
                                Image(systemName: "gearshape").font(.system(size: 24, weight: .medium))
                                    .frame(width: 56, height: 56).contentShape(Circle())
                            }.buttonStyle(HeaderControlStyle())
                                .accessibilityElement(children: .ignore).accessibilityAddTraits(.isButton)
                                .accessibilityLabel("API 设置").accessibilityIdentifier("more-settings-button")
                        }
                    }
                    .foregroundStyle(.primary).padding(.horizontal, 24).padding(.top, 28).padding(.bottom, 30)
                    .frame(width: width, height: geometry.size.height + bottomInset, alignment: .topLeading)
                    .allowsHitTesting(isPresented).accessibilityElement(children: isPresented ? .contain : .ignore)
                    .accessibilityHidden(!isPresented).accessibilityIdentifier("more-drawer")
                    .disabled(!isPresented)
                    }
                }
                content
                    .environment(\.drawerProgress, progress)
                    .padding(.top, geometry.safeAreaInsets.top)
                    .padding(.bottom, bottomInset)
                    .frame(width: geometry.size.width,
                        height: geometry.size.height + geometry.safeAreaInsets.top + bottomInset)
                    .background {
                        RoundedRectangle(cornerRadius: progress * 38, style: .continuous)
                            .fill(Theme.background)
                    }
                    .allowsHitTesting(!isPresented).disabled(isPresented)
                    .overlay {
                        Group {
                            RoundedRectangle(cornerRadius: progress * 38, style: .continuous)
                                .fill(colorScheme == .dark ? Color.black : Color.white)
                                .opacity(progress * (colorScheme == .dark ? 0.25 : 0.3))
                                .contentShape(Rectangle())
                                .onTapGesture { isPresented = false }
                                .accessibilityLabel("关闭更多").accessibilityAddTraits(.isButton)
                                .allowsHitTesting(isPresented && closeTapEnabled).accessibilityHidden(!isPresented)
                        }
                    }
                    .shadow(color: .black.opacity(progress * 0.12), radius: 22, x: -8)
                    // One monotonic timing curve moves the whole page without a clamped spring rebound.
                    .position(x: geometry.size.width / 2 + displacement,
                        y: (geometry.size.height + geometry.safeAreaInsets.top + bottomInset) / 2 - geometry.safeAreaInsets.top)
            }.contentShape(Rectangle())
                .animation(reduceMotion ? .easeOut(duration: 0.15) : .timingCurve(0.2, 0.8, 0.2, 1, duration: 0.38), value: isPresented)
                .simultaneousGesture(DragGesture(minimumDistance: 18)
                    .onChanged { value in
                        // Edge swipe opens the drawer; scrolling and tapping chat controls stay independent.
                        guard isPresented || value.startLocation.x < 32 else { return }
                        guard abs(value.translation.width) > abs(value.translation.height) * 1.3 else { return }
                        if dragOrigin == nil { dragOrigin = isPresented ? width : 0 }
                        var transaction = Transaction(); transaction.animation = nil
                        withTransaction(transaction) { dragDisplacement = min(width, max(0, (dragOrigin ?? 0) + value.translation.width)) }
                    }
                    .onEnded { value in
                        guard dragOrigin != nil else { return }
                        dragOrigin = nil
                        let target: Bool
                        if isPresented { target = !(value.translation.width < -40 || value.predictedEndTranslation.width < -width * 0.5) }
                        else { target = value.translation.width > 50 || value.predictedEndTranslation.width > width * 0.5 }
                        let speed = abs(value.predictedEndTranslation.width - value.translation.width) / max(1, width)
                        let duration = max(0.26, 0.42 - Double(speed) * 0.08)
                        withAnimation(reduceMotion ? .easeOut(duration: 0.15) : .timingCurve(0.2, 0.8, 0.2, 1, duration: duration)) {
                            dragDisplacement = nil
                            isPresented = target
                        }
                    })
                .alert("重命名聊天", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
                    TextField("聊天名称", text: $renameText)
                    Button("保存") { if let record = renaming { chat.rename(record.id, title: renameText) }; renaming = nil }
                    Button("取消", role: .cancel) { renaming = nil }
                }
                .alert("是否删除聊天？", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } })) {
                    Button("删除", role: .destructive) { if let record = deleting { chat.delete(record.id) }; deleting = nil }
                    Button("取消", role: .cancel) { deleting = nil }
                }
                .onChange(of: isPresented) { opened in
                    closeTapEnabled = false
                    if opened { drawerVisible = true }
                    hapticTask?.cancel()
                    hapticTask = Task { @MainActor in
                        do { try await Task.sleep(nanoseconds: 380_000_000) } catch { return }
                        if opened && isPresented { closeTapEnabled = true }
                        if !opened && !isPresented { drawerVisible = false }
                        AppHaptics.light()
                    }
                }

                .onDisappear { hapticTask?.cancel() }
                .accessibilityAction(.escape) { isPresented = false }
        }
    }
}


private struct HistoryScrollBehavior: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 16.4, *) { content.scrollBounceBehavior(.basedOnSize) }
        else { content }
    }
}
