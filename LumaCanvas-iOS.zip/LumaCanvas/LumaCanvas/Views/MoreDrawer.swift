import SwiftUI

enum DrawerMotion {
    static func damping(translation: CGFloat, projected: CGFloat, width: CGFloat) -> Double {
        0.84 - min(1, Double(abs(projected - translation) / max(1, width))) * 0.26
    }
}

struct MoreDrawer: ViewModifier {
    @Binding var isPresented: Bool
    let openGallery: () -> Void
    let newConversation: () -> Void
    let openSettings: () -> Void
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var displacement: CGFloat = 0
    @State private var dragOrigin: CGFloat?

    func body(content: Content) -> some View {
        GeometryReader { geometry in
            let width = min(170, geometry.size.width * 0.41)
            let progress = min(1, max(0, displacement / width))
            ZStack(alignment: .topLeading) {
                Color(uiColor: .systemBackground).ignoresSafeArea()
                if displacement > 0 || isPresented {
                    VStack(alignment: .leading, spacing: 0) {
                        Text("映想").font(.title2.bold()).padding(.bottom, 18)
                        Button {
                            newConversation()
                            isPresented = false
                        } label: {
                            Label("新对话", systemImage: "square.and.pencil")
                                .font(.system(size: 15, weight: .semibold))
                                .frame(maxWidth: .infinity, minHeight: 30)
                        }.modifier(GlassButton(primary: true, compact: true))
                            .accessibilityIdentifier("new-conversation-button")
                            .padding(.bottom, 18)
                        Divider()
                        Button(action: openGallery) {
                            Label("图库", systemImage: "photo.on.rectangle")
                                .font(.system(size: 17, weight: .medium))
                                .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12)
                        }.buttonStyle(.plain).accessibilityIdentifier("more-gallery-button")
                        Divider()
                        VStack(alignment: .leading, spacing: 3) {
                            Label("视频生成", systemImage: "video").font(.system(size: 16, weight: .medium))
                                .lineLimit(1).minimumScaleFactor(0.8)
                            Text("暂不可用").font(.caption2).padding(.leading, 28)
                        }.foregroundStyle(.secondary).padding(.vertical, 12)
                            .accessibilityElement(children: .combine).accessibilityIdentifier("more-video-unavailable")
                        Divider()
                        Spacer()
                        Button(action: openSettings) {
                            Image(systemName: "gearshape").font(.system(size: 22, weight: .medium))
                                .frame(width: 50, height: 50)
                        }.buttonStyle(RatioGlassStyle(circular: true))
                            .accessibilityLabel("API 设置").accessibilityIdentifier("more-settings-button")
                    }
                    .foregroundStyle(.primary).padding(.horizontal, 20).padding(.top, 28).padding(.bottom, 30)
                    .frame(width: width, height: geometry.size.height + geometry.safeAreaInsets.bottom, alignment: .topLeading)
                    .allowsHitTesting(isPresented).accessibilityElement(children: .contain)
                    .accessibilityHidden(!isPresented).accessibilityIdentifier("more-drawer")
                }
                content
                    .environment(\.drawerProgress, progress)
                    .background(Theme.background.ignoresSafeArea())
                    .saturation(1 - progress * 0.6)
                    .allowsHitTesting(!isPresented)
                    .overlay {
                        if progress > 0 {
                            (colorScheme == .dark ? Color.black : Color.white)
                                .opacity(progress * (colorScheme == .dark ? 0.25 : 0.3))
                                .ignoresSafeArea().contentShape(Rectangle())
                                .onTapGesture { isPresented = false }
                                .accessibilityLabel("关闭更多").accessibilityAddTraits(.isButton)
                        }
                    }
                    .shadow(color: .black.opacity(progress * 0.12), radius: 22, x: -8)
                    .offset(x: displacement)
            }.contentShape(Rectangle())
                .simultaneousGesture(DragGesture(minimumDistance: 18)
                    .onChanged { value in
                        guard abs(value.translation.width) > abs(value.translation.height) * 1.3 else { return }
                        if dragOrigin == nil { dragOrigin = isPresented ? width : 0 }
                        var transaction = Transaction(); transaction.animation = nil
                        withTransaction(transaction) { displacement = min(width, max(0, (dragOrigin ?? 0) + value.translation.width)) }
                    }
                    .onEnded { value in
                        guard dragOrigin != nil else { return }
                        dragOrigin = nil
                        let target: Bool
                        if isPresented { target = !(value.translation.width < -40 || value.predictedEndTranslation.width < -width * 0.5) }
                        else { target = value.translation.width > 50 || value.predictedEndTranslation.width > width * 0.5 }
                        let damping = DrawerMotion.damping(translation: value.translation.width,
                            projected: value.predictedEndTranslation.width, width: width)
                        withAnimation(reduceMotion ? .easeOut(duration: 0.15) : .spring(response: 0.46, dampingFraction: damping)) {
                            displacement = target ? width : 0
                            isPresented = target
                        }
                    })
                .onAppear { displacement = isPresented ? width : 0 }
                .onChange(of: isPresented) { opened in
                    let target = opened ? width : 0
                    guard abs(displacement - target) > 0.5 else { return }
                    withAnimation(reduceMotion ? .easeOut(duration: 0.15) : .spring(response: 0.42, dampingFraction: 0.8)) { displacement = target }
                }
                .onChange(of: geometry.size.width) { _ in displacement = isPresented ? width : 0 }
                .accessibilityAction(.escape) { isPresented = false }
        }
    }
}
