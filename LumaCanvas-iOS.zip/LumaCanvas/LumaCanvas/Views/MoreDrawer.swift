import SwiftUI

struct MoreDrawer: ViewModifier {
    @Binding var isPresented: Bool
    let openGallery: () -> Void
    @GestureState private var dragOffset: CGFloat = 0

    func body(content: Content) -> some View {
        GeometryReader { geometry in
            let width = min(170, geometry.size.width * 0.41)
            let offset = min(width, max(0, (isPresented ? width : 0) + dragOffset))
            ZStack(alignment: .leading) {
                Color(uiColor: .systemBackground).ignoresSafeArea()
                VStack(alignment: .leading, spacing: 0) {
                    Text("映想").font(.title2.bold()).padding(.bottom, 20)
                    Divider()
                    Button {
                        isPresented = false
                        openGallery()
                    } label: {
                        Label("图库", systemImage: "photo.on.rectangle")
                            .font(.system(size: 17, weight: .medium))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.vertical, 14)
                    }.buttonStyle(.plain).accessibilityIdentifier("more-gallery-button")
                    Divider()
                    VStack(alignment: .leading, spacing: 4) {
                        Label("视频生成", systemImage: "video")
                            .font(.system(size: 16, weight: .medium))
                            .lineLimit(1).minimumScaleFactor(0.8)
                        Text("暂不可用").font(.caption2).padding(.leading, 28)
                    }.foregroundStyle(.secondary).padding(.vertical, 14)
                        .accessibilityElement(children: .combine)
                        .accessibilityIdentifier("more-video-unavailable")
                    Divider()
                    Spacer()
                }
                .foregroundStyle(.primary).padding(.horizontal, 16).padding(.top, 28)
                .frame(width: width).frame(maxHeight: .infinity, alignment: .topLeading)
                .opacity(offset > 0 ? 1 : 0)
                .allowsHitTesting(isPresented)
                .accessibilityElement(children: .contain)
                .accessibilityHidden(!isPresented)
                .accessibilityIdentifier("more-drawer")

                content
                    // Do not clip the background at the safe-area bounds.
                    .background(Theme.background.ignoresSafeArea())
                    .disabled(isPresented)
                    .overlay {
                        if isPresented {
                            Color.black.opacity(0.025).contentShape(Rectangle())
                                .onTapGesture { isPresented = false }
                                .accessibilityLabel("关闭更多")
                                .accessibilityAddTraits(.isButton)
                        }
                    }
                    .shadow(color: .black.opacity(offset > 0 ? 0.12 : 0), radius: 22, x: -8)
                    .offset(x: offset)
            }
            .contentShape(Rectangle())
            .simultaneousGesture(
                DragGesture(minimumDistance: 18)
                    .updating($dragOffset) { value, state, transaction in
                        guard abs(value.translation.width) > abs(value.translation.height) * 1.3 else { return }
                        transaction.animation = nil
                        state = isPresented ? max(-width, min(0, value.translation.width))
                                            : min(width, max(0, value.translation.width))
                    }
                    .onEnded { value in
                        guard abs(value.translation.width) > abs(value.translation.height) * 1.3 else { return }
                        let projected = value.predictedEndTranslation.width
                        if isPresented {
                            if value.translation.width < -40 || projected < -width * 0.5 { isPresented = false }
                        } else if value.translation.width > 50 || projected > width * 0.5 {
                            isPresented = true
                        }
                    }
            )
            .animation(.spring(response: 0.32, dampingFraction: 0.9), value: isPresented)
            .accessibilityAction(.escape) { isPresented = false }
        }
    }
}
