import SwiftUI

enum DrawerMotion {
    static func damping(translation: CGFloat, projected: CGFloat, width: CGFloat) -> Double {
        0.84 - min(1, Double(abs(projected - translation) / max(1, width))) * 0.26
    }
}

struct MoreDrawer<Main: View>: View {
    let content: Main
    @ObservedObject var presentation: DrawerPresentation
    private var isPresented: Bool {
        get { presentation.isPresented }
        nonmutating set { presentation.isPresented = newValue }
    }
    let openGallery: () -> Void
    let openAnywhere: Bool
    @ObservedObject var canvas: CanvasViewModel
    let openTask: (CanvasGenerationJob) -> Void
    let openImage: () -> Void
    let openChat: () -> Void
    @ObservedObject var chat: ChatViewModel
    let instanceID: UUID
    let newConversation: () -> Void
    let openSettings: () -> Void
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var closeTapEnabled = false
    @State private var renaming: ChatConversation?
    @State private var renameText = ""
    @State private var deletingTask: CanvasGenerationJob?
    @State private var deleting: ChatConversation?
    @State private var hapticTask: Task<Void, Never>?

    private var bottomInset: CGFloat {
        UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }.first(where: { $0.isKeyWindow })?.safeAreaInsets.bottom ?? 0
    }
    var body: some View {
        return GeometryReader { geometry in
            let width = geometry.size.width * 0.75
            let topInset = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.flatMap { $0.windows }.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 0
            NativeDrawerContainer(presentation: presentation, content: AnyView(content), sidebar: AnyView(
                    VStack(alignment: .leading, spacing: 0) {
                        Text("映想").font(.title2.bold()).padding(.bottom, 18)
                        Button(action: openGallery) {
                            HStack {
                                Label("图库", systemImage: "photo.on.rectangle")
                                Spacer()
                                if canvas.galleryUnread { Circle().fill(Theme.accent).frame(width: 6, height: 6) }
                            }
                                .font(.system(size: 17, weight: .medium))
                                .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12).contentShape(Rectangle())
                        }.buttonStyle(.plain).accessibilityIdentifier("more-gallery-button")
                        Divider()
                        Button(action: openImage) {
                            Label("生图", systemImage: "sparkles")
                                .font(.system(size: 17, weight: .medium))
                                .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12).contentShape(Rectangle())
                        }.buttonStyle(.plain).accessibilityIdentifier("more-image-button")
                        if !canvas.sidebarJobs.isEmpty {
                            ScrollView {
                                LazyVStack(spacing: 0) {
                                ForEach(canvas.sidebarJobs) { job in
                            Button { openTask(job) } label: {
                                HStack(spacing: 8) {
                                    Text(job.title).font(.system(size: 14)).lineLimit(1)
                                    Spacer(minLength: 4)
                                    if job.state == .completed { Circle().fill(Theme.accent).frame(width: 6, height: 6) }
                                    else if job.state == .running { ProgressView().controlSize(.mini) }
                                    else { Image(systemName: "exclamationmark.circle").foregroundStyle(.secondary) }
                                }.padding(.leading, 28).frame(maxWidth: .infinity).padding(.vertical, 10).contentShape(Rectangle())
                            }.buttonStyle(.plain).contextMenu {
                                if job.state != .completed {
                                    Button(role: .destructive) { deletingTask = job } label: { Label("删除任务", systemImage: "trash") }
                                }
                            }.accessibilityIdentifier("image-task-\(job.id)")
                        }
                                }
                            }.modifier(HistoryScrollBehavior()).frame(height: min(CGFloat(canvas.sidebarJobs.count) * 40, 160))
                        }
                        Divider()
                        VStack(alignment: .leading, spacing: 3) {
                            Label("视频生成", systemImage: "video").font(.system(size: 16, weight: .medium))
                                .lineLimit(1).minimumScaleFactor(0.8)
                            Text("暂不可用").font(.caption2).padding(.leading, 28)
                        }.foregroundStyle(.secondary).padding(.vertical, 12)
                            .accessibilityElement(children: .combine).accessibilityIdentifier("more-video-unavailable")
                        Divider()
                        ScrollView {
                            LazyVStack(alignment: .leading, spacing: 0) {
                                ForEach(chat.records(for: instanceID)) { record in
                                    Button {
                                        chat.open(record.id, for: instanceID)
                                        openChat()
                                    } label: {
                                        HStack {
                                            Text(record.title).font(.system(size: 16)).lineLimit(1)
                                            Spacer(minLength: 0)
                                            if record.pinned { Image(systemName: "pin.fill").font(.caption).foregroundStyle(.secondary) }
                                        }.frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12).contentShape(Rectangle())
                                    }.buttonStyle(.plain).contextMenu {
                                        Button { renameText = record.title; renaming = record } label: { Label("重命名", systemImage: "pencil") }
                                        Button { chat.togglePin(record.id) } label: { Label(record.pinned ? "取消置顶" : "置顶", systemImage: "pin") }
                                        Button(role: .destructive) { deleting = record } label: { Label("删除聊天", systemImage: "trash") }
                                    }.accessibilityIdentifier("chat-history-\(record.id.uuidString)")
                                }
                                if chat.records(for: instanceID).isEmpty {
                                    Text("暂无聊天记录").font(.footnote).foregroundStyle(.secondary).padding(.vertical, 12)
                                }
                            }
                        }.modifier(HistoryScrollBehavior()).frame(maxWidth: .infinity, maxHeight: .infinity).padding(.top, 14).padding(.bottom, 16)
                        HStack {
                            Button {
                                newConversation()
                                isPresented = false
                            } label: {
                                Label("新对话", systemImage: "square.and.pencil")
                                    .font(.system(size: 16, weight: .semibold))
                                    .frame(width: 104, height: 56)
                            }.buttonStyle(.plain).foregroundStyle(.white).background(Theme.accent, in: Capsule())
                                .accessibilityIdentifier("new-conversation-button")
                            Spacer(minLength: 12)
                            Button(action: openSettings) {
                                Image(systemName: "gearshape").font(.system(size: 24, weight: .medium))
                                    .frame(width: 56, height: 56).contentShape(Circle())
                            }.buttonStyle(HeaderControlStyle())
                                .accessibilityElement(children: .ignore).accessibilityAddTraits(.isButton)
                                .accessibilityLabel("设置").accessibilityIdentifier("more-settings-button")
                        }
                    }
                    .foregroundStyle(.primary).padding(.horizontal, 24).padding(.top, topInset + 28).padding(.bottom, bottomInset + 20)
                    .frame(width: width, height: geometry.size.height, alignment: .topLeading)
                    .ignoresSafeArea(.container)
            ), dark: colorScheme == .dark, reduceMotion: reduceMotion)
                .background(DrawerSwipeBridge(openAnywhere: openAnywhere, presentation: presentation))
                .alert("是否删除任务？", isPresented: Binding(get: { deletingTask != nil }, set: { if !$0 { deletingTask = nil } })) {
                    Button("删除", role: .destructive) { if let job = deletingTask { canvas.deleteUnfinishedTask(job.id) }; deletingTask = nil }
                    Button("取消", role: .cancel) { deletingTask = nil }
                } message: { Text("停止等待并移除此任务。服务端已提交的请求可能仍在执行。") }
                .alert("重命名聊天", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
                    TextField("聊天名称", text: $renameText)
                    Button("保存") { if let record = renaming { chat.rename(record.id, title: renameText) }; renaming = nil }
                    Button("取消", role: .cancel) { renaming = nil }
                }
                .alert("是否删除聊天？", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } })) {
                    Button("删除", role: .destructive) { if let record = deleting { chat.delete(record.id) }; deleting = nil }
                    Button("取消", role: .cancel) { deleting = nil }
                }
                .onChange(of: isPresented) { opened in
                    closeTapEnabled = false
                    hapticTask?.cancel()
                    hapticTask = Task { @MainActor in
                        do { try await Task.sleep(nanoseconds: 380_000_000) } catch { return }
                        if opened && isPresented { closeTapEnabled = true }
                        AppHaptics.light()
                    }
                }

                .onDisappear { hapticTask?.cancel() }
                .accessibilityAction(.escape) { isPresented = false }
        }.ignoresSafeArea(.container)
    }
}


private struct HistoryScrollBehavior: ViewModifier {
    @ViewBuilder var body: some View {
        if #available(iOS 16.4, *) { content.scrollBounceBehavior(.basedOnSize) }
        else { content }
    }
}
