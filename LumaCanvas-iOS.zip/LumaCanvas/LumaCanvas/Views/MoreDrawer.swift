import SwiftUI

enum DrawerMotion {
    static func damping(translation: CGFloat, projected: CGFloat, width: CGFloat) -> Double {
        0.84 - min(1, Double(abs(projected - translation) / max(1, width))) * 0.26
    }
}

struct MoreDrawer: ViewModifier {
    @Binding var isPresented: Bool
    let openGallery: () -> Void
    let newConversation: () -> Void
    let openSettings: () -> Void
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var displacement: CGFloat = 0
    @State private var dragOrigin: CGFloat?

    func body(content: Content) -> some View {
        GeometryReader { geometry in
            let width = geometry.size.width * 0.75
            let progress = min(1, max(0, displacement / width))
            ZStack(alignment: .topLeading) {
                Color(uiColor: .systemBackground).ignoresSafeArea()
                Group {
                    VStack(alignment: .leading, spacing: 0) {
                        Text("映想").font(.title2.bold()).padding(.bottom, 18)
                        Button(action: openGallery) {
                            Label("图库", systemImage: "photo.on.rectangle")
                                .font(.system(size: 17, weight: .medium))
                                .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12)
                        }.buttonStyle(.plain).accessibilityIdentifier("more-gallery-button")
                        Divider()
                        VStack(alignment: .leading, spacing: 3) {
                            Label("视频生成", systemImage: "video").font(.system(size: 16, weight: .medium))
                                .lineLimit(1).minimumScaleFactor(0.8)
                            Text("暂不可用").font(.caption2).padding(.leading, 28)
                        }.foregroundStyle(.secondary).padding(.vertical, 12)
                            .accessibilityElement(children: .combine).accessibilityIdentifier("more-video-unavailable")
                        Divider()
                        Spacer()
                        HStack {
                            Button {
                                newConversation()
                                isPresented = false
                            } label: {
                                Label("新对话", systemImage: "square.and.pencil")
                                    .font(.system(size: 17, weight: .semibold))
                                    .frame(width: min(106, max(76, width - 156)), height: 28)
                            }.modifier(GlassButton(primary: true))
                                .accessibilityIdentifier("new-conversation-button")
                            Spacer(minLength: 12)
                            Button(action: openSettings) {
                                Image(systemName: "gearshape").font(.system(size: 24, weight: .medium))
                                    .frame(width: 56, height: 56)
                            }.buttonStyle(RatioGlassStyle(circular: true))
                                .accessibilityLabel("API 设置").accessibilityIdentifier("more-settings-button")
                        }
                    }
                    .foregroundStyle(.primary).padding(.horizontal, 24).padding(.top, 28).padding(.bottom, 30)
                    .frame(width: width, height: geometry.size.height + geometry.safeAreaInsets.bottom, alignment: .topLeading)
                    .allowsHitTesting(isPresented).accessibilityElement(children: isPresented ? .contain : .ignore)
                    .accessibilityHidden(!isPresented).accessibilityIdentifier("more-drawer")
                }
                content
                    .environment(\.drawerProgress, progress)
                    .padding(.top, geometry.safeAreaInsets.top)
                    .padding(.bottom, geometry.safeAreaInsets.bottom)
                    .frame(width: geometry.size.width,
                        height: geometry.size.height + geometry.safeAreaInsets.top + geometry.safeAreaInsets.bottom)
                    .background {
                        RoundedRectangle(cornerRadius: progress * 38, style: .continuous)
                            .fill(Theme.background)
                    }
                    .allowsHitTesting(!isPresented)
                    .overlay {
                        Group {
                            RoundedRectangle(cornerRadius: progress * 38, style: .continuous)
                                .fill(colorScheme == .dark ? Color.black : Color.white)
                                .opacity(progress * (colorScheme == .dark ? 0.25 : 0.3))
                                .contentShape(Rectangle())
                                .onTapGesture { isPresented = false }
                                .accessibilityLabel("关闭更多").accessibilityAddTraits(.isButton)
                                .allowsHitTesting(isPresented).accessibilityHidden(!isPresented)
                        }
                    }
                    .shadow(color: .black.opacity(progress * 0.12), radius: 22, x: -8)
                    // One monotonic timing curve moves the whole page without a clamped spring rebound.
                    .offset(x: displacement, y: -geometry.safeAreaInsets.top)
            }.contentShape(Rectangle())
                .simultaneousGesture(DragGesture(minimumDistance: 18)
                    .onChanged { value in
                        guard abs(value.translation.width) > abs(value.translation.height) * 1.3 else { return }
                        if dragOrigin == nil { dragOrigin = isPresented ? width : 0 }
                        var transaction = Transaction(); transaction.animation = nil
                        withTransaction(transaction) { displacement = min(width, max(0, (dragOrigin ?? 0) + value.translation.width)) }
                    }
                    .onEnded { value in
                        guard dragOrigin != nil else { return }
                        dragOrigin = nil
                        let target: Bool
                        if isPresented { target = !(value.translation.width < -40 || value.predictedEndTranslation.width < -width * 0.5) }
                        else { target = value.translation.width > 50 || value.predictedEndTranslation.width > width * 0.5 }
                        let speed = abs(value.predictedEndTranslation.width - value.translation.width) / max(1, width)
                        let duration = max(0.26, 0.42 - Double(speed) * 0.08)
                        withAnimation(reduceMotion ? .easeOut(duration: 0.15) : .timingCurve(0.2, 0.8, 0.2, 1, duration: duration)) {
                            displacement = target ? width : 0
                            isPresented = target
                        }
                    })
                .onAppear { displacement = isPresented ? width : 0 }
                .onChange(of: isPresented) { opened in
                    let target = opened ? width : 0
                    guard abs(displacement - target) > 0.5 else { return }
                    withAnimation(reduceMotion ? .easeOut(duration: 0.15) : .timingCurve(0.2, 0.8, 0.2, 1, duration: 0.38)) { displacement = target }
                }
                .onChange(of: geometry.size.width) { _ in displacement = isPresented ? width : 0 }
                .accessibilityAction(.escape) { isPresented = false }
        }
    }
}

