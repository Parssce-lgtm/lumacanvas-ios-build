import SwiftUI
import PhotosUI

private struct ChatTextShare: Identifiable { var id = UUID(); let text: String }

/// Only this row observes token updates; typing, drawer and history do not rebuild.
private struct ChatStreamingRow: View {
    @ObservedObject var reply: ChatStreamingReply
    let onGrowth: () -> Void
    var body: some View {
        Text(AttributedString(ChatFormatting.attributed(reply.text)))
            .font(.system(size: 17)).fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityIdentifier("chat-streaming-reply")
            .task(id: reply.text.count) {
                await Task.yield()
                guard !Task.isCancelled else { return }
                onGrowth()
            }
    }
}

struct ChatView: View {
    @ObservedObject var configuration: ConfigurationStore
    @ObservedObject var chat: ChatViewModel
    @ObservedObject var drawer: DrawerPresentation
    @State private var input = ChatDraftState()
    private var draft: String {
        get { input.text }
        nonmutating set { input.text = newValue }
    }
    @State private var composerHeight: CGFloat = 76
    @State private var showSettings = false
    @State private var showHistory = false
    @State private var confirmAdultMode = false
    @State private var editingMessage: UUID?
    @State private var attachments: [ChatAttachment] = []
    @State private var selectedPhotos: [PhotosPickerItem] = []
    @State private var showPhotos = false
    @State private var showFiles = false
    @State private var showCamera = false
    @State private var importing = false
    @State private var importError: String?
    @State private var importTask: Task<Void, Never>?
    @State private var inputSession = UUID()
    @State private var document: ChatDocumentPreview?
    @State private var textShare: ChatTextShare?
    @State private var selectingText: ChatTextShare?
    @FocusState private var focused: Bool

    private var conversation: ChatConversation { chat.conversation(for: configuration.value.id) }
    private var ready: Bool { (try? configuration.value.validateConversation()) != nil }
    private var canSend: Bool { !importing && (!draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !attachments.isEmpty) }
    private var client: ChatAPIClient {
        #if DEBUG
        if UITestFixtures.enabled { return UITestFixtures.conversationClient() }
        #endif
        return ChatAPIClient()
    }
    var body: some View {
        ZStack(alignment: .top) {
            messages.overlay(alignment: .bottom) {
                composer.background {
                    GeometryReader { proxy in
                        Color.clear.preference(key: ChatComposerHeight.self, value: proxy.size.height)
                    }
                }
            }.onPreferenceChange(ChatComposerHeight.self) { height in
                if abs(height - composerHeight) > 0.5 { composerHeight = height }
            }
            VStack(spacing: 0) { header; statusHeader }
        }.frame(maxWidth: .infinity, maxHeight: .infinity).background(Theme.background)
            .onAppear {
                #if DEBUG
                if ProcessInfo.processInfo.arguments.contains("ui-preview-chat-attachment"), attachments.isEmpty {
                    let png = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg==")!
                    if let photo = try? ChatAttachment.image(png, name: "待发送图片") { attachments = [photo] }
                }
                #endif
            }
            .sheet(item: $document) { ChatDocumentViewer(document: $0) }
            .sheet(item: $textShare) { TextShareSheet(text: $0.text) }
            .sheet(item: $selectingText) { ChatTextSelection(text: $0.text) }
            .sheet(isPresented: $showSettings) { SettingsView(store: configuration) }
            .sheet(isPresented: $showHistory) { ChatHistoryView(chat: chat, instanceID: configuration.value.id) }
            .photosPicker(isPresented: $showPhotos, selection: $selectedPhotos,
                maxSelectionCount: max(1, ChatAttachment.maximumCount - attachments.count),
                selectionBehavior: .ordered, matching: .images, preferredItemEncoding: .compatible)
            .task(id: selectedPhotos) { await importPhotos() }
            .sheet(isPresented: $showFiles) {
                ReferenceFilePicker { result in showFiles = false; importFiles(result) }
            }
            .sheet(isPresented: $showCamera) {
                ChatCameraPicker { result in
                    showCamera = false
                    switch result {
                    case .success(let data): importData(data, name: "相机照片")
                    case .failure(let error): if !(error is CancellationError) { importError = error.localizedDescription }
                    }
                }.ignoresSafeArea()
            }
            .alert("附件提示", isPresented: Binding(get: { importError != nil }, set: { if !$0 { importError = nil } })) {
                Button("知道了", role: .cancel) { importError = nil }
            } message: { Text(importError ?? "") }
            .alert("开启成人模式？", isPresented: $confirmAdultMode) {
                Button("取消", role: .cancel) { }
                Button("确认") { chat.setAdultMode(true, for: configuration.value.id); draft = "" }
            } message: {
                Text("请确认你已年满 18 周岁。此模式允许讨论成熟话题，避免暴力、血腥和政治内容。你需自行承担聊天内容的使用及相关后果；此确认不会解除服务商的内容限制。")
            }
            .onChange(of: configuration.value.id) { _ in
                chat.endTemporaryChats(); clearDraft(); confirmAdultMode = false
            }
            .onChange(of: conversation.id) { _ in clearDraft() }
            .onDisappear { importTask?.cancel(); inputSession = UUID(); chat.endTemporaryChats() }
            .tint(Theme.accent)
    }
    private var header: some View {
        HStack(spacing: 12) {
            DrawerToggleButton(identifier: "chat-more-button", presentation: drawer) { focused = false }
                .frame(width: 50, height: 50)
                .background { Circle().fill(Color.clear).modifier(StaticHeaderGlass()).allowsHitTesting(false) }
            Spacer(minLength: 0)
            HStack(spacing: 0) {
                Button { reset(temporary: false) } label: {
                    Image(systemName: "square.and.pencil").font(.system(size: 20)).frame(width: 52, height: 48)
                }.buttonStyle(.plain).accessibilityLabel("新对话")
                options
            }.modifier(GlassSurface(capsule: true))
        }.padding(.horizontal, 16).padding(.vertical, 6).background(KeyboardTapExclusion())
    }
    private var options: some View {
        Menu {
            Button { reset(temporary: false) } label: { Label("新对话", systemImage: "square.and.pencil") }
            Button { focused = false; showHistory = true } label: { Label("聊天记录", systemImage: "clock") }
            if conversation.temporary {
                Button { focused = false; chat.endTemporary(for: configuration.value.id) } label: {
                    Label("返回普通聊天", systemImage: "bubble.left.and.bubble.right")
                }
            } else {
                Button { reset(temporary: true) } label: { Label("临时聊天", systemImage: "bubble.left.and.exclamationmark.bubble.right") }
                    .accessibilityIdentifier("temporary-chat-button")
            }
            if conversation.adultMode { Button("关闭成人模式") { chat.setAdultMode(false, for: configuration.value.id) } }
            Button { focused = false; showSettings = true } label: { Label("API 设置", systemImage: "gearshape") }
            Text("使用模型：\(configuration.value.conversationModel)")
        } label: {
            Image(systemName: "ellipsis").font(.system(size: 21, weight: .medium)).frame(width: 56, height: 48).contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityLabel("聊天选项")
    }
    private var statusHeader: some View {
        VStack(spacing: 6) {
            if conversation.temporary {
                Label("退出后不保存此聊天", systemImage: "clock.badge.xmark").font(.caption).foregroundStyle(.secondary)
                    .accessibilityIdentifier("temporary-chat-notice")
            }
            if let error = chat.storageError { Text(error).font(.caption).foregroundStyle(.red) }
        }.padding(.horizontal, 16)
    }
    private var messages: some View {
        GeometryReader { geometry in
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 16) {
                        if conversation.messages.isEmpty { emptyState.frame(minHeight: max(0, geometry.size.height - composerHeight - 104)) }
                        ForEach(conversation.messages) { message in messageRow(message).id(message.id) }
                        if chat.sendingInstance == configuration.value.id {
                            HStack(spacing: 8) { ProgressView(); Text("正在回复…").foregroundStyle(.secondary) }
                                .font(.subheadline).accessibilityIdentifier("chat-replying")
                        }
                        if let error = conversation.error { Text(error).font(.footnote).foregroundStyle(.red).accessibilityIdentifier("chat-error") }
                        if let streaming = chat.streamingReply, streaming.instanceID == configuration.value.id {
                            ChatStreamingRow(reply: streaming, onGrowth: { proxy.scrollTo("chat-bottom", anchor: .bottom) })
                        }
                        // The scroll anchor includes the composer space, so the latest message
                        // remains above the input instead of being scrolled behind it.
                        Color.clear.frame(height: composerHeight + 8).id("chat-bottom")
                    }.padding(.horizontal, 14).padding(.top, 72)
                }.scrollDismissesKeyboard(.interactively).modifier(ChatScrollEdges())
                    .task(id: conversation.messages.count) {
                        await Task.yield()
                        proxy.scrollTo("chat-bottom", anchor: .bottom)
                    }
            }
        }
    }
    private func messageRow(_ message: ChatMessage) -> some View {
        let user = message.role == "user"
        return HStack(alignment: .top, spacing: 0) {
            if user { Spacer(minLength: 50) }
            VStack(alignment: user ? .trailing : .leading, spacing: 3) {
                ForEach(message.attachments) { file in sentAttachment(file) }
                if !message.text.isEmpty {
                    Group {
                        if user {
                            Text(message.text).font(.system(size: 17)).fixedSize(horizontal: false, vertical: true)
                        } else {
                            ChatText(text: message.text, share: { share(message.text) }).allowsHitTesting(false)
                        }
                    }
                        .padding(user ? 13 : 0)
                        .background(user ? Color(uiColor: .secondarySystemFill) : .clear, in: RoundedRectangle(cornerRadius: 25))
                        .accessibilityIdentifier("chat-message-\(message.id)")
                }
                if !user { replyActions(message) }
            }.contentShape(RoundedRectangle(cornerRadius: 25))
                .onTapGesture(count: 2) { focused = false; selectingText = ChatTextShare(text: message.text) }
                .contextMenu {
                    Button { copy(message.text) } label: { Label("复制", systemImage: "doc.on.doc") }
                    Button { focused = false; selectingText = ChatTextShare(text: message.text) } label: { Label("选择文本", systemImage: "text.cursor") }
                    if user { Button { edit(message) } label: { Label("编辑", systemImage: "pencil") }.disabled(chat.sendingInstance != nil) }
                    Button { share(message.text) } label: { Label("分享", systemImage: "square.and.arrow.up") }
                    Menu("更多") {
                        Button { retry(message) } label: { Label("重试", systemImage: "arrow.clockwise") }.disabled(chat.sendingInstance != nil)
                    }
                }
        }.frame(maxWidth: .infinity, alignment: user ? .trailing : .leading)
    }
    private func edit(_ message: ChatMessage) {
        editingMessage = message.id; draft = message.text; attachments = message.attachments; focused = true
    }
    @ViewBuilder private func sentAttachment(_ file: ChatAttachment) -> some View {
        if file.isImage, let image = UIImage(data: file.data) {
            Image(uiImage: image).resizable().scaledToFit().frame(maxWidth: 180, maxHeight: 230)
                .clipShape(RoundedRectangle(cornerRadius: 22)).accessibilityLabel(file.name)
        } else {
            Button {
                AppHaptics.light()
                do { document = try ChatDocuments.preview(file) } catch { importError = error.localizedDescription }
            } label: {
                Label(file.name, systemImage: "doc").font(.subheadline).lineLimit(2).padding(14)
                    .background(Theme.canvas, in: RoundedRectangle(cornerRadius: 20))
            }.buttonStyle(.plain).accessibilityLabel("打开文件 \(file.name)")
        }
    }
    private func replyActions(_ message: ChatMessage) -> some View {
        HStack(spacing: 3) {
            Button { copy(message.text) } label: { Image(systemName: "doc.on.doc").frame(width: 34, height: 34).contentShape(Rectangle()) }.accessibilityLabel("复制回复")
            Button { share(message.text) } label: { Image(systemName: "square.and.arrow.up").frame(width: 34, height: 34).contentShape(Rectangle()) }.accessibilityLabel("分享回复")
            Menu {
                Button { retry(message) } label: { Label("重试", systemImage: "arrow.clockwise") }.disabled(chat.sendingInstance != nil)
                Menu("保存为文件") {
                    Button("TXT 文本") { export(message, name: "回复.txt") }
                    Button("PDF 文档") { export(message, name: "回复.pdf") }
                }
            } label: { Image(systemName: "ellipsis").frame(width: 34, height: 34) }
                .accessibilityLabel("回复选项")
                .simultaneousGesture(TapGesture().onEnded { AppHaptics.light() })
        }.font(.system(size: 15)).foregroundStyle(.secondary).buttonStyle(.plain).background(KeyboardTapExclusion())
    }
    private func share(_ text: String) { AppHaptics.light(); textShare = ChatTextShare(text: text) }
    private func export(_ message: ChatMessage, name: String) {
        do { document = try ChatDocuments.preview(ChatDocuments.make(text: message.text, name: name)) }
        catch { importError = error.localizedDescription }
    }
    private var emptyState: some View {
        VStack(spacing: 12) {
            Text(conversation.temporary ? "开始临时聊天" : "有什么可以帮你？").font(.title2.bold())
            if !ready {
                Text("先配置 API 和聊天模型").font(.subheadline).foregroundStyle(.secondary)
                Button("配置聊天模型") { showSettings = true }.padding(10)
            }
        }.frame(maxWidth: .infinity).multilineTextAlignment(.center)
    }
    private var composer: some View {
        VStack(alignment: .leading, spacing: 10) {
            if !attachments.isEmpty { attachmentStrip }
            if importing { ProgressView("正在读取附件…").font(.caption) }
            if editingMessage != nil {
                HStack {
                    Text("编辑消息 · 重新发送为新分支").font(.caption).foregroundStyle(.secondary)
                    Spacer(); Button("取消") { clearDraft() }
                }
            }
            ChatComposerRow(input: input, attachmentMenu: attachmentMenu, focus: $focused,
                hasAttachments: !attachments.isEmpty, importing: importing,
                sending: chat.sendingInstance != nil, send: send, stop: { chat.stop() })
        }.padding(4).modifier(ChatComposerGlass())
            .background(KeyboardTapExclusion()).padding(.horizontal, 16).padding(.bottom, 8).padding(.top, 6)
    }

    private var attachmentMenu: some View {
        Menu {
            Button {
                focused = false
                if UIImagePickerController.isSourceTypeAvailable(.camera) { showCamera = true }
                else { importError = "此设备没有可用相机。" }
            } label: { Label("相机", systemImage: "camera") }
            Button { focused = false; showPhotos = true } label: { Label("照片", systemImage: "photo") }
            Button { focused = false; showFiles = true } label: { Label("文件", systemImage: "folder") }
        } label: { Image(systemName: "plus").font(.system(size: 24)).frame(width: 42, height: 42).contentShape(Rectangle()) }
            .buttonStyle(.plain).disabled(importing || attachments.count >= ChatAttachment.maximumCount)
            .accessibilityLabel("添加附件")
    }
    private var attachmentStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(attachments) { file in
                    ZStack(alignment: .topTrailing) {
                        Group {
                            if file.isImage, let image = UIImage(data: file.data) {
                                Image(uiImage: image).resizable().scaledToFill().frame(width: 82, height: 82).clipped()
                            } else {
                                VStack(spacing: 6) { Image(systemName: "doc.fill"); Text(file.name).font(.caption2).lineLimit(2) }
                                    .frame(width: 82, height: 82).background(Theme.background)
                            }
                        }.clipShape(RoundedRectangle(cornerRadius: 16))
                        Button { attachments.removeAll { $0.id == file.id } } label: {
                            Image(systemName: "xmark").font(.system(size: 11, weight: .bold)).frame(width: 28, height: 28)
                                .foregroundStyle(.white).background(.black.opacity(0.6), in: Circle())
                        }.buttonStyle(.plain).accessibilityLabel("移除附件 \(file.name)")
                    }.padding(.top, 4).accessibilityIdentifier("chat-selected-attachment")
                }
            }
        }.accessibilityIdentifier("chat-attachment-strip")
    }
    private func copy(_ text: String) { AppHaptics.light(); UIPasteboard.general.string = text }
    private func retry(_ message: ChatMessage) { AppHaptics.light(); focused = false; chat.retry(message.id, configuration: configuration.value, client: client) }
    private func clearDraft() {
        importTask?.cancel(); inputSession = UUID(); importing = false
        draft = ""; attachments = []; selectedPhotos = []; editingMessage = nil; focused = false
    }
    private func reset(temporary: Bool) { clearDraft(); chat.newConversation(for: configuration.value.id, temporary: temporary) }
    private func send() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard canSend else { return }
        focused = false
        if text == "开启成人模式", attachments.isEmpty { confirmAdultMode = true; return }
        if text == "关闭成人模式", attachments.isEmpty { chat.setAdultMode(false, for: configuration.value.id); draft = ""; return }
        guard ready else { showSettings = true; return }
        let accepted: Bool
        if let message = editingMessage { accepted = chat.editAndSend(message, text: text, attachments: attachments, configuration: configuration.value, client: client) }
        else { accepted = chat.send(text, attachments: attachments, configuration: configuration.value, client: client) }
        if accepted { clearDraft() }
    }
    private func append(_ files: [ChatAttachment], session: UUID) throws {
        guard inputSession == session else { return }
        try ChatAttachment.validate(attachments + files)
        attachments += files
    }
    private func importPhotos() async {
        guard !selectedPhotos.isEmpty else { return }
        let selections = selectedPhotos, session = inputSession
        importing = true
        defer { if inputSession == session { importing = false; selectedPhotos = [] } }
        do {
            var files: [ChatAttachment] = []
            for (index, photo) in selections.enumerated() {
                guard let data = try await photo.loadTransferable(type: Data.self) else { throw AppError.configuration("无法读取照片。") }
                let file = try await Task.detached(priority: .userInitiated) { try ChatAttachment.image(data, name: "照片 \(index + 1)") }.value
                try Task.checkCancellation(); files.append(file)
            }
            try append(files, session: session)
        } catch is CancellationError { }
        catch { if inputSession == session { importError = error.localizedDescription } }
    }
    private func importFiles(_ result: Result<[URL], Error>) {
        let session = inputSession
        importTask = Task { @MainActor in
            importing = true
            defer { if inputSession == session { importing = false } }
            do {
                let urls = try result.get()
                guard urls.count + attachments.count <= ChatAttachment.maximumCount else { throw AppError.configuration("每条消息最多添加 8 个附件。") }
                let files = try await Task.detached(priority: .userInitiated) { try urls.map { try ChatAttachment.file($0) } }.value
                try Task.checkCancellation(); try append(files, session: session)
            } catch is CancellationError { }
            catch { if inputSession == session { importError = error.localizedDescription } }
        }
    }
    private func importData(_ data: Data, name: String) {
        let session = inputSession
        importTask = Task { @MainActor in
            importing = true
            defer { if inputSession == session { importing = false } }
            do {
                let file = try await Task.detached(priority: .userInitiated) { try ChatAttachment.image(data, name: name) }.value
                try Task.checkCancellation(); try append([file], session: session)
            } catch is CancellationError { }
            catch { if inputSession == session { importError = error.localizedDescription } }
        }
    }
}

private struct ChatControlStyle: ButtonStyle {
    var prominent = false
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.contentShape(Rectangle())
            .foregroundStyle(!enabled ? Color.secondary : prominent ? Color.white : Theme.ink)
            .modifier(GlassSurface(capsule: true, primary: prominent))
            .scaleEffect(configuration.isPressed ? 0.92 : 1)
            .opacity(enabled ? 1 : 0.45)
            .animation(.easeOut(duration: 0.18), value: configuration.isPressed)
    }
}

struct ChatCameraPicker: UIViewControllerRepresentable {
    let completion: (Result<Data, Error>) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion: completion) }
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController(); picker.sourceType = .camera; picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ controller: UIImagePickerController, context: Context) {}
    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let completion: (Result<Data, Error>) -> Void
        init(completion: @escaping (Result<Data, Error>) -> Void) { self.completion = completion }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            guard let image = info[.originalImage] as? UIImage, let data = image.jpegData(compressionQuality: 0.9) else {
                completion(.failure(AppError.configuration("无法读取相机照片。"))); return
            }
            completion(.success(data))
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { completion(.failure(CancellationError())) }
    }
}

struct ChatHistoryView: View {
    @ObservedObject var chat: ChatViewModel
    let instanceID: UUID
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                ForEach(chat.records(for: instanceID)) { record in
                    Button { chat.open(record.id, for: instanceID); dismiss() } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(record.title).foregroundStyle(.primary).lineLimit(2)
                            HStack {
                                Text(record.updatedAt, style: .date)
                                Spacer()
                                Text(record.model).lineLimit(1)
                            }.font(.caption).foregroundStyle(.secondary)
                        }.padding(.vertical, 4)
                    }
                }
                if chat.records(for: instanceID).isEmpty { Text("暂无聊天记录").foregroundStyle(.secondary) }
            }.navigationTitle("聊天记录").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("完成") { dismiss() } } }
        }
    }
}


private struct TextShareSheet: UIViewControllerRepresentable {
    let text: String
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: [text], applicationActivities: nil) }
    func updateUIViewController(_ view: UIActivityViewController, context: Context) {}
}

private struct ChatComposerHeight: PreferenceKey {
    static var defaultValue: CGFloat = 76
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

private struct ChatTextSelection: View {
    let text: String
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                ChatText(text: text, markdown: false)
                    .accessibilityIdentifier("selected-message-text")
                    .padding(20).frame(maxWidth: .infinity, alignment: .leading)
            }.navigationTitle("选择文本").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
        }
    }
}

/// Keystrokes update the row only; the message list and decoded images stay untouched.
@MainActor private final class ChatDraftState: ObservableObject {
    @Published var text = ""
}
private struct ChatComposerRow<AttachmentMenu: View>: View {
    @ObservedObject var input: ChatDraftState
    let attachmentMenu: AttachmentMenu
    var focus: FocusState<Bool>.Binding
    let hasAttachments: Bool
    let importing: Bool
    let sending: Bool
    let send: () -> Void
    let stop: () -> Void
    private var canSend: Bool { !importing && (!input.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || hasAttachments) }
    var body: some View {
        HStack(alignment: .bottom, spacing: 4) {
            attachmentMenu
            TextField("输入消息", text: $input.text, axis: .vertical)
                .lineLimit(1...6).focused(focus).padding(.vertical, 8)
                .accessibilityIdentifier("chat-input")
            if sending {
                Button(action: stop) { Image(systemName: "stop.fill").frame(width: 42, height: 42) }
                    .buttonStyle(ChatControlStyle()).accessibilityLabel("停止等待回复")
            } else {
                Button(action: send) {
                    Image(systemName: "arrow.up").font(.system(size: 20, weight: .semibold)).frame(width: 42, height: 42)
                }.buttonStyle(ChatControlStyle(prominent: canSend)).disabled(!canSend)
                    .accessibilityLabel("发送消息").accessibilityIdentifier("chat-send-button")
            }
        }
    }
}
private struct ChatComposerGlass: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.interactive(), in: RoundedRectangle(cornerRadius: 28))
        } else {
            content.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28))
                .overlay { RoundedRectangle(cornerRadius: 28).stroke(Color.primary.opacity(0.12), lineWidth: 0.75).allowsHitTesting(false) }
        }
    }
}
private struct ChatScrollEdges: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { content.scrollEdgeEffectHidden(true, for: .all) }
        else { content }
    }
}
