import SwiftUI

struct ChatView: View {
    @ObservedObject var configuration: ConfigurationStore
    @ObservedObject var chat: ChatViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var draft = ""
    @State private var showSettings = false
    @State private var confirmAdultMode = false
    @FocusState private var focused: Bool

    private var conversation: ChatConversation { chat.conversation(for: configuration.value.id) }
    private var ready: Bool { (try? configuration.value.validateConversation()) != nil }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 8) {
                    Text(configuration.value.name).lineLimit(1)
                    Spacer()
                    Text(configuration.value.conversationModel.isEmpty ? "未选择聊天模型" : configuration.value.conversationModel)
                        .lineLimit(1).truncationMode(.middle)
                }.font(.caption).foregroundStyle(.secondary).padding(.horizontal, 16).padding(.vertical, 10)
                if conversation.adultMode {
                    HStack {
                        Label("成人模式", systemImage: "person.crop.circle.badge.checkmark")
                        Spacer()
                        Button("关闭") { chat.setAdultMode(false, for: configuration.value.id) }
                    }.font(.caption).padding(.horizontal, 16).padding(.bottom, 8)
                }
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 18) {
                            if conversation.messages.isEmpty { emptyState }
                            ForEach(conversation.messages) { message in
                                HStack {
                                    if message.role == "user" { Spacer(minLength: 44) }
                                    Text(message.text).textSelection(.enabled)
                                        .padding(14)
                                        .background(message.role == "user" ? Theme.accent.opacity(0.12) : Color(uiColor: .secondarySystemBackground),
                                                    in: RoundedRectangle(cornerRadius: 20))
                                    if message.role != "user" { Spacer(minLength: 24) }
                                }.id(message.id)
                            }
                            if chat.sendingInstance == configuration.value.id {
                                HStack(spacing: 8) { ProgressView(); Text("正在回复…").foregroundStyle(.secondary) }
                                    .font(.subheadline).accessibilityIdentifier("chat-replying")
                            }
                            if let error = conversation.error {
                                Text(error).font(.footnote).foregroundStyle(.red)
                                    .accessibilityIdentifier("chat-error")
                            }
                            Color.clear.frame(height: 1).id("chat-bottom")
                        }.padding(16)
                    }.scrollDismissesKeyboard(.interactively)
                        .onChange(of: conversation.messages.count) { _ in
                            withAnimation(.easeOut(duration: 0.2)) { proxy.scrollTo("chat-bottom", anchor: .bottom) }
                        }
                }
                composer
            }.background(Theme.background)
                .navigationTitle("聊天").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button { focused = false; dismiss() } label: { Image(systemName: "chevron.left") }
                            .accessibilityLabel("返回更多")
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Menu {
                            Button {
                                focused = false; draft = ""; chat.newConversation(for: configuration.value.id)
                            } label: { Label("新对话", systemImage: "square.and.pencil") }
                            Button { focused = false; showSettings = true } label: { Label("API 设置", systemImage: "gearshape") }
                        } label: { Image(systemName: "ellipsis") }.accessibilityLabel("聊天选项")
                    }
                }
                .sheet(isPresented: $showSettings) { SettingsView(store: configuration) }
                .alert("开启成人模式？", isPresented: $confirmAdultMode) {
                    Button("取消", role: .cancel) { }
                    Button("确认") { chat.setAdultMode(true, for: configuration.value.id); draft = "" }
                } message: {
                    Text("请确认你已年满 18 周岁。此模式允许讨论成熟话题，避免暴力、血腥和政治内容。你需自行承担聊天内容的使用及相关后果；此确认不会解除服务商的内容限制。")
                }
                .onChange(of: configuration.value.id) { _ in draft = ""; confirmAdultMode = false; focused = false }
                .tint(Theme.accent)
        }
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("开始聊天").font(.title2.bold())
            Text(ready ? "输入消息开始对话。聊天记录仅保留在本次应用运行中，每个实例独立；发送时最多携带最近 40 条消息。" : "先在 API 设置中填写密钥并选择聊天模型。")
                .font(.subheadline).foregroundStyle(.secondary)
            if !ready { Button("配置聊天模型") { showSettings = true } }
            Text("输入“开启成人模式”可查看并确认成熟话题模式。").font(.footnote).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 24)
    }

    private var composer: some View {
        HStack(alignment: .bottom, spacing: 10) {
            TextField("输入消息", text: $draft, axis: .vertical)
                .lineLimit(1...6).focused($focused).padding(14)
                .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 24))
                .accessibilityIdentifier("chat-input")
            if chat.sendingInstance != nil {
                Button { chat.stop() } label: { Image(systemName: "stop.fill").frame(width: 44, height: 44) }
                    .buttonStyle(RatioGlassStyle(circular: true)).accessibilityLabel("停止等待回复")
            } else {
                Button(action: send) {
                    Image(systemName: "arrow.up").font(.system(size: 18, weight: .semibold)).frame(width: 44, height: 44)
                }.buttonStyle(RatioGlassStyle(selected: !draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, circular: true))
                    .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    .accessibilityLabel("发送消息").accessibilityIdentifier("chat-send-button")
            }
        }.padding(.horizontal, 16).padding(.vertical, 12)
            .background(KeyboardTapExclusion())
    }

    private func send() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        focused = false
        if text == "开启成人模式" { confirmAdultMode = true; return }
        if text == "关闭成人模式" { chat.setAdultMode(false, for: configuration.value.id); draft = ""; return }
        guard ready else { showSettings = true; return }
        #if DEBUG
        if UITestFixtures.enabled { chat.send(text, configuration: configuration.value, client: UITestFixtures.conversationClient()) }
        else { chat.send(text, configuration: configuration.value) }
        #else
        chat.send(text, configuration: configuration.value)
        #endif
        draft = ""
    }
}
