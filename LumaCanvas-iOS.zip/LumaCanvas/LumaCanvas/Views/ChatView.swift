import SwiftUI

struct ChatView: View {
    @ObservedObject var configuration: ConfigurationStore
    @ObservedObject var chat: ChatViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var draft = ""
    @State private var showSettings = false
    @State private var showHistory = false
    @State private var confirmAdultMode = false
    @State private var editingMessage: UUID?
    @FocusState private var focused: Bool

    private var conversation: ChatConversation { chat.conversation(for: configuration.value.id) }
    private var ready: Bool { (try? configuration.value.validateConversation()) != nil }
    private var client: ChatAPIClient {
        #if DEBUG
        if UITestFixtures.enabled { return UITestFixtures.conversationClient() }
        #endif
        return ChatAPIClient()
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                statusHeader
                messages
                composer
            }.background(Theme.background)
                .navigationTitle(conversation.temporary ? "临时聊天" : "聊天").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button { focused = false; dismiss() } label: { Image(systemName: "chevron.left") }
                            .accessibilityLabel("返回更多")
                    }
                    ToolbarItem(placement: .navigationBarTrailing) { options }
                }
                .sheet(isPresented: $showSettings) { SettingsView(store: configuration) }
                .sheet(isPresented: $showHistory) { ChatHistoryView(chat: chat, instanceID: configuration.value.id) }
                .alert("开启成人模式？", isPresented: $confirmAdultMode) {
                    Button("取消", role: .cancel) { }
                    Button("确认") { chat.setAdultMode(true, for: configuration.value.id); draft = "" }
                } message: {
                    Text("请确认你已年满 18 周岁。此模式允许讨论成熟话题，避免暴力、血腥和政治内容。你需自行承担聊天内容的使用及相关后果；此确认不会解除服务商的内容限制。")
                }
                .onChange(of: configuration.value.id) { _ in
                    chat.endTemporaryChats(); draft = ""; editingMessage = nil; confirmAdultMode = false; focused = false
                }
                .onChange(of: conversation.id) { _ in draft = ""; editingMessage = nil; focused = false }
                .onDisappear { chat.endTemporaryChats() }
                .tint(Theme.accent)
        }
    }
    private var options: some View {
        Menu {
            Button { reset(temporary: false) } label: { Label("新对话", systemImage: "square.and.pencil") }
            Button { focused = false; showHistory = true } label: { Label("聊天记录", systemImage: "clock") }
            if conversation.temporary {
                Button {
                    focused = false; chat.endTemporary(for: configuration.value.id)
                } label: { Label("返回普通聊天", systemImage: "bubble.left.and.bubble.right") }
            } else {
                Button { reset(temporary: true) } label: { Label("临时聊天", systemImage: "bubble.left.and.exclamationmark.bubble.right") }
                    .accessibilityIdentifier("temporary-chat-button")
            }
            Button { focused = false; showSettings = true } label: { Label("API 设置", systemImage: "gearshape") }
        } label: { Image(systemName: "ellipsis") }.accessibilityLabel("聊天选项")
    }
    private var statusHeader: some View {
        VStack(spacing: 8) {
            HStack(spacing: 8) {
                Text(configuration.value.name).lineLimit(1)
                Spacer()
                Text(configuration.value.conversationModel.isEmpty ? "未选择聊天模型" : configuration.value.conversationModel)
                    .lineLimit(1).truncationMode(.middle)
            }.font(.caption).foregroundStyle(.secondary)
            if conversation.temporary {
                Label("退出后不保存此聊天", systemImage: "clock.badge.xmark").font(.caption).foregroundStyle(.secondary)
                    .accessibilityIdentifier("temporary-chat-notice")
            }
            if conversation.adultMode {
                HStack {
                    Label("成人模式", systemImage: "person.crop.circle.badge.checkmark")
                    Spacer()
                    Button("关闭") { chat.setAdultMode(false, for: configuration.value.id) }
                }.font(.caption)
            }
            if let error = chat.storageError { Text(error).font(.caption).foregroundStyle(.red) }
        }.padding(.horizontal, 16).padding(.vertical, 10)
    }
    private var messages: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 18) {
                    if conversation.messages.isEmpty { emptyState }
                    ForEach(conversation.messages) { message in messageRow(message).id(message.id) }
                    if chat.sendingInstance == configuration.value.id {
                        HStack(spacing: 8) { ProgressView(); Text("正在回复…").foregroundStyle(.secondary) }
                            .font(.subheadline).accessibilityIdentifier("chat-replying")
                    }
                    if let error = conversation.error {
                        Text(error).font(.footnote).foregroundStyle(.red).accessibilityIdentifier("chat-error")
                    }
                    Color.clear.frame(height: 1).id("chat-bottom")
                }.padding(16)
            }.scrollDismissesKeyboard(.interactively)
                .onChange(of: conversation.messages.count) { _ in
                    withAnimation(.easeOut(duration: 0.2)) { proxy.scrollTo("chat-bottom", anchor: .bottom) }
                }
        }
    }
    private func messageRow(_ message: ChatMessage) -> some View {
        HStack(alignment: .top) {
            if message.role == "user" { Spacer(minLength: 44) }
            VStack(alignment: .leading, spacing: 6) {
                Text(message.text).padding(14)
                    .background(message.role == "user" ? Theme.accent.opacity(0.12) : Color(uiColor: .secondarySystemBackground),
                                in: RoundedRectangle(cornerRadius: 20))
                    .contextMenu {
                        Button { copy(message.text) } label: { Label("复制", systemImage: "doc.on.doc") }
                        if message.role == "user" {
                            Button {
                                editingMessage = message.id; draft = message.text; focused = true
                            } label: { Label("编辑", systemImage: "pencil") }.disabled(chat.sendingInstance != nil)
                        }
                        Button { retry(message) } label: { Label("重试", systemImage: "arrow.clockwise") }
                            .disabled(chat.sendingInstance != nil)
                        ShareLink(item: message.text) { Label("分享", systemImage: "square.and.arrow.up") }
                    }
                if message.role == "assistant" { replyActions(message) }
            }
            if message.role != "user" { Spacer(minLength: 24) }
        }
    }
    private func replyActions(_ message: ChatMessage) -> some View {
        HStack(spacing: 8) {
            Button { copy(message.text) } label: { Image(systemName: "doc.on.doc").padding(8) }
                .accessibilityLabel("复制回复")
            ShareLink(item: message.text) { Image(systemName: "square.and.arrow.up").padding(8) }
                .accessibilityLabel("分享回复")
            Button { retry(message) } label: { Image(systemName: "arrow.clockwise").padding(8) }
                .accessibilityLabel("重试回复").disabled(chat.sendingInstance != nil)
        }.font(.system(size: 14)).foregroundStyle(.secondary).buttonStyle(.plain)
    }
    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(conversation.temporary ? "开始临时聊天" : "开始聊天").font(.title2.bold())
            Text(ready ? (conversation.temporary ? "此对话不写入聊天记录，退出聊天页面后清除。" : "聊天自动保存到本机，可在侧栏或聊天选项中继续历史对话。") : "先在 API 设置中填写密钥并选择聊天模型。")
                .font(.subheadline).foregroundStyle(.secondary)
            if !ready { Button("配置聊天模型") { showSettings = true } }
            Text("输入“开启成人模式”可查看并确认成熟话题模式。").font(.footnote).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 24)
    }
    private var composer: some View {
        VStack(spacing: 6) {
            if editingMessage != nil {
                HStack {
                    Text("编辑消息 · 重新发送为新分支").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Button("取消") { editingMessage = nil; draft = "" }
                }
            }
            HStack(alignment: .bottom, spacing: 10) {
                TextField("输入消息", text: $draft, axis: .vertical)
                    .lineLimit(1...6).focused($focused).padding(14)
                    .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 24))
                    .accessibilityIdentifier("chat-input")
                if chat.sendingInstance != nil {
                    Button { chat.stop() } label: { Image(systemName: "stop.fill").frame(width: 44, height: 44) }
                        .buttonStyle(RatioGlassStyle(circular: true)).accessibilityLabel("停止等待回复")
                } else {
                    Button(action: send) {
                        Image(systemName: "arrow.up").font(.system(size: 18, weight: .semibold)).frame(width: 44, height: 44)
                    }.buttonStyle(RatioGlassStyle(selected: !draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, circular: true))
                        .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        .accessibilityLabel("发送消息").accessibilityIdentifier("chat-send-button")
                }
            }
        }.padding(.horizontal, 16).padding(.vertical, 12).background(KeyboardTapExclusion())
    }
    private func copy(_ text: String) { UIPasteboard.general.string = text }
    private func retry(_ message: ChatMessage) { focused = false; chat.retry(message.id, configuration: configuration.value, client: client) }
    private func reset(temporary: Bool) {
        focused = false; draft = ""; editingMessage = nil
        chat.newConversation(for: configuration.value.id, temporary: temporary)
    }
    private func send() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        focused = false
        if text == "开启成人模式" { confirmAdultMode = true; return }
        if text == "关闭成人模式" { chat.setAdultMode(false, for: configuration.value.id); draft = ""; return }
        guard ready else { showSettings = true; return }
        if let message = editingMessage { chat.editAndSend(message, text: text, configuration: configuration.value, client: client) }
        else { chat.send(text, configuration: configuration.value, client: client) }
        editingMessage = nil; draft = ""
    }
}

struct ChatHistoryView: View {
    @ObservedObject var chat: ChatViewModel
    let instanceID: UUID
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                ForEach(chat.records(for: instanceID)) { record in
                    Button { chat.open(record.id, for: instanceID); dismiss() } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(record.title).foregroundStyle(.primary).lineLimit(2)
                            HStack {
                                Text(record.updatedAt, style: .date)
                                Spacer()
                                Text(record.model).lineLimit(1)
                            }.font(.caption).foregroundStyle(.secondary)
                        }.padding(.vertical, 4)
                    }
                }
                if chat.records(for: instanceID).isEmpty { Text("暂无聊天记录").foregroundStyle(.secondary) }
            }.navigationTitle("聊天记录").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("完成") { dismiss() } } }
        }
    }
}

