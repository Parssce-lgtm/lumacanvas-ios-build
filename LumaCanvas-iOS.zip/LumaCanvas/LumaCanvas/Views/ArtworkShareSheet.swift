import SwiftUI

struct ArtworkShareItem: Identifiable {
    let id = UUID()
    let url: URL
    init(_ artwork: GeneratedArtwork) throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("ArtworkShares", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        url = folder.appendingPathComponent(artwork.id.uuidString + ".png")
        try artwork.pngData.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
}

struct ArtworkShareSheet: UIViewControllerRepresentable {
    let item: ArtworkShareItem
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: [item.url], applicationActivities: nil)
        if let popover = controller.popoverPresentationController {
            popover.sourceView = controller.view
            popover.sourceRect = CGRect(x: controller.view.bounds.midX, y: controller.view.bounds.maxY, width: 1, height: 1)
            popover.permittedArrowDirections = []
        }
        return controller
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) { }
}

struct SwipeBack: ViewModifier {
    var enabled = true
    let action: () -> Void
    func body(content: Content) -> some View {
        content.simultaneousGesture(DragGesture(minimumDistance: 24).onEnded { value in
            guard enabled, value.translation.width > abs(value.translation.height) * 1.5,
                  value.translation.width > 65 || value.predictedEndTranslation.width > 160 else { return }
            action()
        })
    }
}
