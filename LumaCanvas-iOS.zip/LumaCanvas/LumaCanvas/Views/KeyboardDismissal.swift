import SwiftUI
import UIKit

/// SwiftUI buttons may not have UIControl ancestors. Protect the action bar
/// explicitly so the window's blank-space recognizer cannot move it mid-tap.
struct KeyboardTapExclusion: UIViewRepresentable {
    static let views = NSHashTable<UIView>.weakObjects()
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        view.isOpaque = false
        view.isUserInteractionEnabled = false
        Self.views.add(view)
        return view
    }
    func updateUIView(_ uiView: UIView, context: Context) {}
}

/// Observe background taps without consuming controls or immediately dismissing
/// a text field that the user has just focused. Covers presented settings too.
struct KeyboardDismissal: UIViewRepresentable {
    func makeUIView(context: Context) -> DismissalView { DismissalView() }
    func updateUIView(_ uiView: DismissalView, context: Context) {}

    final class DismissalView: UIView, UIGestureRecognizerDelegate {
        private weak var installedWindow: UIWindow?
        private lazy var tap: UITapGestureRecognizer = {
            let gesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
            gesture.cancelsTouchesInView = false
            gesture.delaysTouchesBegan = false
            gesture.delaysTouchesEnded = false
            gesture.delegate = self
            return gesture
        }()
        override func didMoveToWindow() {
            super.didMoveToWindow()
            installedWindow?.removeGestureRecognizer(tap)
            installedWindow = window
            window?.addGestureRecognizer(tap)
        }
        @objc private func dismissKeyboard() {
            // Let the button's touch-up action finish before keyboard dismissal
            // moves the safe-area controls. A synchronous layout change here
            // could cancel SwiftUI's button activation even without cancelling touches.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { [weak self] in self?.installedWindow?.endEditing(true) }
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            if let window = installedWindow,
               KeyboardTapExclusion.views.allObjects.contains(where: {
                   $0.window === window && $0.convert($0.bounds, to: window).contains(touch.location(in: window))
               }) { return false }
            var view = touch.view
            while let current = view {
                if current is UITextField || current is UITextView || current is UIControl { return false }
                view = current.superview
            }
            return true
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
    }
}
