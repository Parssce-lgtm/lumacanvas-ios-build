import SwiftUI

struct ArtworkFramePreference: PreferenceKey {
    static var defaultValue: CGRect = .zero
    static func reduce(value: inout CGRect, nextValue: () -> CGRect) { value = nextValue() }
}

struct ArtworkFrameReader: ViewModifier {
    func body(content: Content) -> some View {
        content.background(GeometryReader { geometry in
            Color.clear.preference(key: ArtworkFramePreference.self, value: geometry.frame(in: .global))
        })
    }
}

struct ArtworkZoomPresentation: ViewModifier {
    @Binding var isPresented: Bool
    let image: UIImage?
    let sourceFrame: CGRect

    func body(content: Content) -> some View {
        content
            .allowsHitTesting(!isPresented)
            .overlay {
                if isPresented, let image {
                    FullScreenArtworkView(image: image, sourceFrame: sourceFrame) { isPresented = false }
                        .ignoresSafeArea().zIndex(100)
                }
            }
    }
}

/// Image geometry is unchanged during a dismissal drag. Only the surrounding
/// chrome fades; release animates the image back into its source rectangle.
struct FullScreenArtworkView: View {
    let image: UIImage
    let sourceFrame: CGRect
    let onClose: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var expanded = false
    @State private var closing = false
    @State private var scale: CGFloat = 1
    @GestureState private var gestureScale: CGFloat = 1
    @State private var pan: CGSize = .zero
    @GestureState private var drag: CGSize = .zero

    private var chromeOpacity: Double {
        guard expanded else { return 0 }
        return scale > 1 ? 1 : max(0, 1 - Double(abs(drag.height)) / 180)
    }

    var body: some View {
        GeometryReader { geometry in
            let local = sourceFrame.offsetBy(dx: -geometry.frame(in: .global).minX,
                                             dy: -geometry.frame(in: .global).minY)
            let source = fitted(in: local.isEmpty ? CGRect(origin: .zero, size: geometry.size) : local)
            let destination = fitted(in: CGRect(origin: .zero, size: geometry.size))
            let rect = expanded ? destination : source
            ZStack(alignment: .topLeading) {
                Color.black.opacity(chromeOpacity).contentShape(Rectangle())
                Image(uiImage: image).resizable().scaledToFit()
                    .frame(width: rect.width, height: rect.height)
                    .scaleEffect(min(5, max(1, scale * gestureScale)))
                    .position(x: rect.midX + (scale > 1 ? pan.width + drag.width : 0),
                              y: rect.midY + (scale > 1 ? pan.height + drag.height : 0))
                    .accessibilityIdentifier("zoom-artwork")
                    .gesture(MagnificationGesture()
                        .updating($gestureScale) { value, state, _ in state = value }
                        .onEnded { value in
                            scale = min(5, max(1, scale * value))
                            if scale == 1 { pan = .zero }
                        })
                    .onTapGesture(count: 2) { withAnimation { scale = scale == 1 ? 2 : 1; pan = .zero } }
                VStack {
                    HStack {
                        Button { withAnimation { scale = 1; pan = .zero } } label: {
                            Label("重置", systemImage: "arrow.counterclockwise")
                                .font(.system(size: 13)).padding(12)
                                .background(.white.opacity(0.15), in: Capsule())
                        }
                        Spacer()
                        Button { close() } label: {
                            Image(systemName: "xmark").font(.system(size: 16, weight: .semibold))
                                .frame(width: 42, height: 42).background(.white.opacity(0.15), in: Circle())
                        }.accessibilityLabel("关闭全屏预览")
                    }.padding(.horizontal, 20).padding(.top, max(20, geometry.safeAreaInsets.top + 8))
                    Spacer()
                    Text("双指缩放 · 双击放大 · 上下滑动返回")
                        .font(.system(size: 12)).padding(.bottom, max(20, geometry.safeAreaInsets.bottom + 8))
                }.foregroundStyle(.white).opacity(chromeOpacity)
            }
            .contentShape(Rectangle())
            .simultaneousGesture(DragGesture()
                .updating($drag) { value, state, _ in state = value.translation }
                .onEnded { value in
                    if scale > 1 {
                        pan.width += value.translation.width; pan.height += value.translation.height
                    } else if abs(value.translation.height) > abs(value.translation.width),
                              abs(value.translation.height) > 65 || abs(value.predictedEndTranslation.height) > 150 {
                        close()
                    }
                })
            .onAppear { withAnimation(.easeInOut(duration: reduceMotion ? 0.15 : 0.28)) { expanded = true } }
            .accessibilityAction(.escape) { close() }
        }.accessibilityIdentifier("artwork-zoom-overlay")
    }

    private func fitted(in rect: CGRect) -> CGRect {
        let ratio = image.size.width / max(1, image.size.height)
        let width = min(rect.width, rect.height * ratio)
        let height = width / ratio
        return CGRect(x: rect.midX - width / 2, y: rect.midY - height / 2, width: width, height: height)
    }

    private func close() {
        guard !closing else { return }
        closing = true
        let duration = reduceMotion ? 0.15 : 0.28
        withAnimation(.easeInOut(duration: duration)) {
            scale = 1; pan = .zero; expanded = false
        }
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: UInt64(duration * 1_000_000_000))
            onClose()
        }
    }
}
