import SwiftUI

struct ArtworkFramePreference: PreferenceKey {
    static var defaultValue: CGRect = .zero
    static func reduce(value: inout CGRect, nextValue: () -> CGRect) { value = nextValue() }
}

struct ArtworkFrameReader: ViewModifier {
    func body(content: Content) -> some View {
        content.background(GeometryReader { geometry in
            Color.clear.preference(key: ArtworkFramePreference.self, value: geometry.frame(in: .global))
        })
    }
}

struct ArtworkZoomPresentation: ViewModifier {
    @Binding var isPresented: Bool
    let image: UIImage?
    let sourceFrame: CGRect
    var artwork: GeneratedArtwork? = nil

    func body(content: Content) -> some View {
        content
            .allowsHitTesting(!isPresented)
            .overlay {
                if isPresented, let image {
                    FullScreenArtworkView(image: image, sourceFrame: sourceFrame, artwork: artwork) {
                        var transaction = Transaction(); transaction.disablesAnimations = true
                        withTransaction(transaction) { isPresented = false }
                    }
                        .environment(\.colorScheme, .dark).ignoresSafeArea().zIndex(100)
                }
            }
    }
}

/// Capture the source rectangle once. Keep the overlay alive until the return
/// animation finishes, and fade chrome without moving the image during a drag.
struct FullScreenArtworkView: View {
    let image: UIImage
    let artwork: GeneratedArtwork?
    let onClose: () -> Void
    @State private var originFrame: CGRect
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var progress: CGFloat = 0
    @State private var closing = false
    @State private var scale: CGFloat = 1
    @GestureState private var gestureScale: CGFloat = 1
    @State private var pan: CGSize = .zero
    @GestureState private var drag: CGSize = .zero
    @State private var shareItem: ArtworkShareItem?
    @State private var saving = false
    @State private var message: String?

    init(image: UIImage, sourceFrame: CGRect, artwork: GeneratedArtwork? = nil,
         onClose: @escaping () -> Void) {
        self.image = image; self.artwork = artwork; self.onClose = onClose
        _originFrame = State(initialValue: sourceFrame)
    }

    private var chromeOpacity: Double {
        Double(progress) * (closing || scale > 1 ? 1 : max(0, 1 - Double(abs(drag.height)) / 180))
    }

    var body: some View {
        GeometryReader { geometry in
            let local = originFrame.offsetBy(dx: -geometry.frame(in: .global).minX,
                                              dy: -geometry.frame(in: .global).minY)
            let source = fitted(in: local.isEmpty ? CGRect(origin: .zero, size: geometry.size) : local)
            let destination = fitted(in: CGRect(origin: .zero, size: geometry.size))
            let windowTop = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
                .flatMap { $0.windows }.first(where: \.isKeyWindow)?.safeAreaInsets.top ?? 0
            ZStack(alignment: .topLeading) {
                Color.black.opacity(chromeOpacity).contentShape(Rectangle())
                Image(uiImage: image).resizable().scaledToFit()
                    .modifier(ZoomImageGeometry(source: source, destination: destination, progress: progress))
                    .scaleEffect(min(5, max(1, scale * gestureScale)))
                    .offset(scale > 1 ? CGSize(width: pan.width + drag.width, height: pan.height + drag.height) : .zero)
                    .accessibilityIdentifier("zoom-artwork")
                    .gesture(MagnificationGesture()
                        .updating($gestureScale) { value, state, _ in state = value }
                        .onEnded { value in
                            scale = min(5, max(1, scale * value))
                            if scale == 1 { pan = .zero }
                        })
                    .onTapGesture(count: 2) { withAnimation { scale = scale == 1 ? 2 : 1; pan = .zero } }
                VStack {
                    HStack(spacing: 10) {
                        Button { close() } label: {
                            Image(systemName: "xmark").font(.system(size: 18, weight: .medium))
                                .frame(width: 46, height: 46)
                        }.buttonStyle(RatioGlassStyle(circular: true))
                            .accessibilityElement(children: .ignore)
                            .accessibilityLabel("关闭全屏预览")
                        Spacer()
                        Button { savePhoto() } label: {
                            Image(systemName: "square.and.arrow.down").font(.system(size: 19, weight: .medium))
                                .frame(width: 46, height: 46)
                        }.buttonStyle(RatioGlassStyle(circular: true))
                            .accessibilityElement(children: .ignore)
                            .accessibilityLabel("下载图片").accessibilityIdentifier("zoom-download-button")
                        Button { share() } label: {
                            Text("分享").font(.system(size: 16, weight: .semibold)).foregroundStyle(.black)
                                .frame(width: 62, height: 28)
                        }.modifier(GlassButton(primary: true))
                            .accessibilityElement(children: .ignore).accessibilityLabel("分享")
                            .accessibilityIdentifier("zoom-share-button")
                    }.padding(.horizontal, 20)
                        .padding(.top, max(windowTop, geometry.safeAreaInsets.top) + 12)
                    Spacer()
                    Text("双指缩放 · 双击放大 · 上下滑动返回")
                        .font(.system(size: 12)).padding(.bottom, max(20, geometry.safeAreaInsets.bottom + 8))
                }.foregroundStyle(.white).tint(.white).opacity(chromeOpacity)
            }
            .contentShape(Rectangle()).allowsHitTesting(!closing)
            .simultaneousGesture(DragGesture()
                .updating($drag) { value, state, _ in state = value.translation }
                .onEnded { value in
                    if scale > 1 { pan.width += value.translation.width; pan.height += value.translation.height }
                    else if abs(value.translation.height) > abs(value.translation.width),
                            abs(value.translation.height) > 65 || abs(value.predictedEndTranslation.height) > 150 { close() }
                })
            .onAppear { withAnimation(.timingCurve(0.2, 0.8, 0.2, 1, duration: reduceMotion ? 0.15 : 0.34)) { progress = 1 } }
            .accessibilityAction(.escape) { close() }
        }.accessibilityIdentifier("artwork-zoom-overlay")
            .sheet(item: $shareItem) { ArtworkShareSheet(item: $0) }
            .alert("提示", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("知道了", role: .cancel) { message = nil }
            } message: { Text(message ?? "") }
    }

    private func fitted(in rect: CGRect) -> CGRect {
        let ratio = image.size.width / max(1, image.size.height)
        let width = min(rect.width, rect.height * ratio)
        let height = width / ratio
        return CGRect(x: rect.midX - width / 2, y: rect.midY - height / 2, width: width, height: height)
    }

    private func savePhoto() {
        guard !saving, let data = artwork?.pngData ?? image.pngData() else { return }
        saving = true
        Task { @MainActor in
            defer { saving = false }
            do { try await PhotoLibraryService.save(pngData: data); message = "已保存到相册" }
            catch { message = error.localizedDescription }
        }
    }
    private func share() {
        guard let artwork else { message = "无法读取作品信息"; return }
        do { shareItem = try ArtworkShareItem(artwork) }
        catch { message = error.localizedDescription }
    }

    private func close() {
        guard !closing else { return }
        closing = true
        let duration = reduceMotion ? 0.15 : 0.36
        let animation = Animation.timingCurve(0.4, 0, 0.2, 1, duration: duration)
        if #available(iOS 17.0, *) {
            withAnimation(animation, completionCriteria: .removed) {
                scale = 1; pan = .zero; progress = 0
            } completion: { onClose() }
        } else {
            withAnimation(animation) { scale = 1; pan = .zero; progress = 0 }
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: UInt64((duration + 0.08) * 1_000_000_000))
                onClose()
            }
        }
    }
}

/// Geometry is interpolated by SwiftUI's animation presentation value, not a
/// boolean branch that can replace the image halfway through dismissal.
private struct ZoomImageGeometry: AnimatableModifier {
    let source: CGRect
    let destination: CGRect
    var progress: CGFloat
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }
    func body(content: Content) -> some View {
        let width = source.width + (destination.width - source.width) * progress
        let height = source.height + (destination.height - source.height) * progress
        let x = source.midX + (destination.midX - source.midX) * progress
        let y = source.midY + (destination.midY - source.midY) * progress
        content.frame(width: width, height: height).position(x: x, y: y)
            .transaction { $0.animation = nil }
    }
}
