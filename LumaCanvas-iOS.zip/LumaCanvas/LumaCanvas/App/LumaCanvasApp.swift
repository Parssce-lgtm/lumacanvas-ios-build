import SwiftUI

@main
struct LumaCanvasApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var configuration = ConfigurationStore()

    var body: some Scene {
        WindowGroup {
            ContentView(configuration: configuration)
                .background(KeyboardDismissal().frame(width: 0, height: 0))
        }
    }
}
