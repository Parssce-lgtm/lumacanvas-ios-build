import SwiftUI

@main
struct LumaCanvasApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var configuration = ConfigurationStore()
    @StateObject private var drawer = DrawerPresentation()

    var body: some Scene {
        WindowGroup {
            LaunchCanvas(configuration: configuration, drawer: drawer)
                .background(KeyboardDismissal().frame(width: 0, height: 0))
        }
    }
}

private struct LaunchCanvas: View {
    @ObservedObject var configuration: ConfigurationStore
    @ObservedObject var drawer: DrawerPresentation
    @State private var showing = true
    @State private var appeared = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    private var testing: Bool {
        #if DEBUG
        return ProcessInfo.processInfo.arguments.contains("ui-test-fixture")
        #else
        return false
        #endif
    }
    var body: some View {
        ZStack {
            ContentView(configuration: configuration, drawer: drawer)
            if showing && !testing {
                VStack(spacing: 16) {
                    Image(systemName: "sparkles").font(.system(size: 42, weight: .medium)).foregroundStyle(.white)
                        .frame(width: 90, height: 90).background(Theme.accent.gradient, in: RoundedRectangle(cornerRadius: 26))
                    Text("映想").font(.title.bold())
                }.scaleEffect(appeared || reduceMotion ? 1 : 0.92).opacity(appeared ? 1 : 0)
                    .frame(maxWidth: .infinity, maxHeight: .infinity).background(Theme.background).ignoresSafeArea()
                    .transition(.opacity).accessibilityIdentifier("launch-animation")
            }
        }.task {
            guard showing else { return }
            withAnimation(.easeOut(duration: 0.2)) { appeared = true }
            do { try await Task.sleep(nanoseconds: 800_000_000) } catch { return }
            withAnimation(.easeOut(duration: 0.2)) { showing = false }
        }
    }
}
