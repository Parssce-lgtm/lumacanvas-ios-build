import SwiftUI

@main
struct LumaCanvasApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var configuration = ConfigurationStore()
    @StateObject private var drawer = DrawerPresentation()

    var body: some Scene {
        WindowGroup {
            ContentView(configuration: configuration, drawer: drawer)
                .background(KeyboardDismissal().frame(width: 0, height: 0))
        }
    }
}
