#if DEBUG
import Foundation
import UIKit

/// Compiled only into Debug. UI tests never contact a provider or persist credentials/artwork.
enum UITestFixtures {
    static let galleryStore = ArtworkStore(root: FileManager.default.temporaryDirectory.appendingPathComponent("LumaCanvas-UI-Gallery-" + UUID().uuidString))
    @MainActor static func prepareGallery(_ store: ArtworkStore) async throws {
        for index in 1...2 {
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 320, height: 480))
            let data = renderer.pngData { context in
                UIColor(red: 0.93, green: 0.97, blue: 1, alpha: 1).setFill()
                context.fill(CGRect(x: 0, y: 0, width: 320, height: 480))
                let color: UIColor = index == 1 ? .systemBlue : .systemTeal
                context.cgContext.setFillColor(color.withAlphaComponent(0.18).cgColor)
                context.cgContext.fillEllipse(in: CGRect(x: -80, y: 170, width: 430, height: 430))
                context.cgContext.setFillColor(color.withAlphaComponent(0.8).cgColor)
                context.cgContext.fillEllipse(in: CGRect(x: 55, y: 90, width: 210, height: 210))
                context.cgContext.setStrokeColor(UIColor.white.withAlphaComponent(0.8).cgColor)
                context.cgContext.setLineWidth(2)
                context.cgContext.strokeEllipse(in: CGRect(x: 32, y: 68, width: 255, height: 255))
            }
            let artwork = GeneratedArtwork(id: UUID(), pngData: data, prompt: index == 1 ? "柔和光线下的蓝色圆形" : "清透的蓝色几何构图",
                revisedPrompt: nil, model: "fixture", provider: "界面测试", createdAt: Date().addingTimeInterval(Double(index)),
                pixelWidth: 320, pixelHeight: 480)
            try await store.save(artwork)
        }
    }
    static var enabled: Bool { ProcessInfo.processInfo.arguments.contains("ui-test-fixture") }
    static var configuration: APIConfiguration {
        var config = APIConfiguration.preset(.custom)
        config.name = "界面测试"
        config.endpoint = "https://ui-test.invalid/v1/images/generations"
        config.modelsEndpoint = "https://ui-test.invalid/v1/models"
        config.apiKey = "ui-test-only"
        config.model = "gpt-image-fixture"
        config.conversationModel = "gpt-chat-fixture"
        if ProcessInfo.processInfo.arguments.contains("ui-test-chat") || ProcessInfo.processInfo.arguments.contains("ui-test-background-network") || ProcessInfo.processInfo.arguments.contains("ui-test-standard-network") {
            config.mode = .chatCompletions
            config.endpoint = "https://ui-test.invalid/v1/chat/completions"
            config.model = "nai-diffusion-5-full"
        }
        return config
    }
    static func client() -> ImageAPIClient {
        if ProcessInfo.processInfo.arguments.contains("ui-test-background-network") || ProcessInfo.processInfo.arguments.contains("ui-test-standard-network") {
            let transport = NetworkFixtureTransport(job: UUID(), standard: ProcessInfo.processInfo.arguments.contains("ui-test-standard-network"))
            return ImageAPIClient(apiTransport: transport, downloadTransport: transport)
        }
        let transport = FixtureTransport()
        return ImageAPIClient(apiTransport: transport, downloadTransport: transport)
    }
    static func conversationClient() -> ChatAPIClient { ChatAPIClient(transport: ConversationFixtureTransport()) }
    private struct ConversationFixtureTransport: ImageTransport {
        func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
            let data = try JSONSerialization.data(withJSONObject: ["choices": [["message": ["role": "assistant", "content": "聊天测试回复成功"]]]])
            return (data, HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
        }
    }
    private struct NetworkFixtureTransport: ImageTransport {
        let job: UUID
        let standard: Bool
        func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
            var local = request
            local.url = URL(string: "http://localhost:8765/\(standard ? "rinko-replay" : "slow")?id=\(job.uuidString)")!
            if standard { return try await ForegroundImageTransport(job: job).receive(local, byteLimit: byteLimit) }
            return try await BackgroundImageTransport(job: job).receive(local, byteLimit: byteLimit)
        }
    }
    private struct FixtureTransport: ImageTransport {
        func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
            let body: [String: Any]
            if request.httpMethod == "GET" {
                body = ["data": [
                    ["id": "gpt-chat-fixture", "supports_image_generation": false],
                    ["id": "gpt-image-fixture", "supports_image_generation": true]
                ]]
            } else {
                try await Task.sleep(nanoseconds: 5_000_000_000)
                if ProcessInfo.processInfo.arguments.contains("ui-test-chat") {
                    let content = "![result](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg==)"
                    let fragments = [String(content.prefix(40)), String(content.dropFirst(40))]
                    var stream = ": keepalive\n\n"
                    for fragment in fragments {
                        let event = try JSONSerialization.data(withJSONObject: ["choices": [["index": 0, "delta": ["content": fragment]]]])
                        stream += "data: " + String(decoding: event, as: UTF8.self) + "\n\n"
                    }
                    stream += "data: [DONE]\n\n"
                    return (Data(stream.utf8), HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil,
                        headerFields: ["Content-Type": "text/event-stream"])!)
                }
                body = ["data": [["b64_json": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg=="]]]
            }
            return (try JSONSerialization.data(withJSONObject: body),
                HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
        }
    }
}
#endif
