import SwiftUI
import UIKit

@MainActor
final class CanvasViewModel: ObservableObject {
    @Published var prompt = ""
    @Published var selectedSize = "auto"
    @Published var sensitivity: Sensitivity = .off
    @Published private(set) var references: [ReferenceImage] = []
    @Published private(set) var referencePreviews: [UUID: UIImage] = [:]
    var reference: ReferenceImage? { references.first }
    var referencePreview: UIImage? { reference.flatMap { referencePreviews[$0.id] } }
    @Published private(set) var cooldownUntil = Date.distantPast
    @Published private(set) var confirmationArmed = false
    @Published private(set) var artwork: GeneratedArtwork?
    @Published private(set) var image: UIImage?
    @Published private(set) var isGenerating = false
    @Published private(set) var isSavingPhoto = false
    @Published private(set) var startedAt: Date?
    @Published var alertMessage: String?
    @Published var toast: String?

    @Published private(set) var jobs: [CanvasGenerationJob] = []
    @Published private(set) var galleryUnread = false
    private var backgroundTokens: [UUID: UIBackgroundTaskIdentifier] = [:]
    private var runningReferences: [UUID: [ReferenceImage]] = [:]
    private let clientOverride: ImageAPIClient?
    var sidebarJobs: [CanvasGenerationJob] { jobs.filter { $0.detached && !$0.archived }.sorted { $0.startedAt > $1.startedAt } }
    private var confirmation: PendingGeneration?
    let storage: ArtworkStore
    private let defaults: UserDefaults
    private let persistState: Bool
    private var draftID: UUID

    init(store: ArtworkStore? = nil, defaults: UserDefaults = .standard, persistState: Bool = true, client: ImageAPIClient? = nil) {
        self.clientOverride = client
        self.defaults = defaults
        var persist = persistState
        var selectedStore = store ?? .shared
        #if DEBUG
        if UITestFixtures.enabled { selectedStore = UITestFixtures.galleryStore; persist = false }
        #endif
        self.storage = selectedStore
        self.persistState = persist
        self.draftID = persist ? defaults.string(forKey: "canvas-draft-id").flatMap(UUID.init(uuidString:)) ?? UUID() : UUID()
        if persist {
            defaults.set(draftID.uuidString, forKey: "canvas-draft-id")
            if let data = defaults.data(forKey: "canvas-jobs-v1"), let saved = try? JSONDecoder().decode([CanvasGenerationJob].self, from: data) { jobs = saved }
            galleryUnread = defaults.bool(forKey: "canvas-gallery-unread")
        }
    }
    private var generationTasks: [UUID: Task<Void, Never>] = [:]
    private var toastTask: Task<Void, Never>?
    private var didRestore = false

    func setReference(data: Data, name: String) {
        addReferences([(data, name)])
    }

    /// Commit the whole selection, or roll back newly created files. Existing
    /// selections survive an unreadable file, cancelled picker, or invalid batch.
    func addReferences(_ selections: [(Data, String)]) {
        guard !isGenerating else { return }
        var added: [ReferenceImage] = []
        do {
            guard references.count + selections.count <= ReferenceImageStore.maximumCount else {
                throw AppError.configuration("最多选择 8 张参考图，请先移除部分图片。")
            }
            var previews = referencePreviews
            for (data, name) in selections {
                let (selected, preview) = try ReferenceImageStore.save(data, name: name)
                added.append(selected); previews[selected.id] = preview
            }
            let next = references + added
            try ReferenceImageStore.validatePayload(ReferenceImageStore.read(next))
            try persistReferences(next)
            references = next; referencePreviews = previews
            resetConfirmation()
        } catch {
            added.forEach { ReferenceImageStore.remove($0) }
            alertMessage = NetworkAccess.message(error)
        }
    }

    func removeReference(_ selected: ReferenceImage? = nil) {
        guard !isGenerating else { return }
        let removed = selected.map { [$0] } ?? references
        let next = references.filter { image in !removed.contains(image) }
        do {
            try persistReferences(next)
            references = next
            removed.forEach { ReferenceImageStore.remove($0); referencePreviews.removeValue(forKey: $0.id) }
            resetConfirmation()
        } catch { alertMessage = NetworkAccess.message(error) }
    }

    private func persistReferences(_ images: [ReferenceImage]) throws {
        guard shouldPersist else { return }
        defaults.set(try JSONEncoder().encode(images), forKey: "reference-images-v2")
        defaults.removeObject(forKey: "reference-image-v1")
    }

    private func loadReferences(_ images: [ReferenceImage]) throws {
        let data = try ReferenceImageStore.read(images)
        try ReferenceImageStore.validatePayload(data)
        var previews: [UUID: UIImage] = [:]
        for (image, png) in zip(images, data) {
            guard let preview = UIImage(data: png) else { throw AppError.storage("参考图缓存损坏，请重新选择。") }
            previews[image.id] = preview
        }
        references = images; referencePreviews = previews
    }

    func restore() async {
        guard !didRestore else { return }
        didRestore = true
        #if DEBUG
        if UITestFixtures.enabled {
            if ProcessInfo.processInfo.arguments.contains("ui-test-gallery") {
                try? await UITestFixtures.prepareGallery(storage)
            }
            if ProcessInfo.processInfo.arguments.contains("ui-test-references") {
                let png = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg==")!
                addReferences([(png, "第一张"), (png, "第二张")])
            }
            return
        }
        #endif
        if let data = defaults.data(forKey: "reference-images-v2"),
           let images = try? JSONDecoder().decode([ReferenceImage].self, from: data) {
            do { try loadReferences(images) }
            catch { alertMessage = NetworkAccess.message(error) }
        } else if let data = defaults.data(forKey: "reference-image-v1"),
                  let selected = try? JSONDecoder().decode(ReferenceImage.self, from: data) {
            do { try loadReferences([selected]); try persistReferences([selected]) }
            catch { alertMessage = NetworkAccess.message(error) }
        }
        do {
            if !defaults.bool(forKey: "canvas-skip-latest-restore"),
               let saved = try await storage.load(), !isGenerating, artwork == nil,
               let image = UIImage(data: saved.pngData) {
                artwork = saved
                self.image = image
                if prompt.isEmpty { prompt = saved.prompt }
            }
        } catch {
            alertMessage = "上一次作品未能恢复：\(error.localizedDescription)"
        }
        do {
            for pending in try PendingGeneration.loadAll() {
                if pending.draftID == nil || pending.draftID == draftID {
                    prompt = pending.prompt; selectedSize = pending.size; sensitivity = pending.sensitivity
                    try loadReferences(pending.allReferences)
                }
                run(pending)
            }
        }
        catch { alertMessage = "后台任务未能恢复：\(error.localizedDescription)" }
    }

    func generate(configuration: APIConfiguration) {
        guard !isGenerating, Date() >= cooldownUntil else { return }
        let pending = PendingGeneration(id: UUID(), prompt: prompt, size: selectedSize,
            sensitivity: sensitivity, configuration: configuration, startedAt: Date(), references: references,
            transfer: configuration.transfer, draftID: draftID)
        if artwork != nil {
            guard let previous = confirmation, confirmationArmed,
                  Date().timeIntervalSince(previous.startedAt) < 15,
                  previous.prompt == pending.prompt, previous.size == pending.size,
                  previous.sensitivity == pending.sensitivity, previous.configuration == configuration,
                  previous.allReferences == pending.allReferences else {
                confirmation = pending
                confirmationArmed = true
                showToast("再次点击“生成”确认提交")
                return
            }
        }
        confirmation = nil
        confirmationArmed = false
        do {
            _ = try ImageAPIClient.makeRequest(prompt: pending.prompt, configuration: configuration, size: pending.size, sensitivity: pending.sensitivity,
                referenceImages: ReferenceImageStore.read(pending.allReferences))
            if shouldPersist { try pending.save() }
            run(pending)
        } catch { alertMessage = NetworkAccess.message(error) }
    }

    func resetConfirmation() { confirmation = nil; confirmationArmed = false }

    private var shouldPersist: Bool { persistState }

    private func startDraft() {
        draftID = UUID()
        if shouldPersist {
            defaults.set(draftID.uuidString, forKey: "canvas-draft-id")
            defaults.set(true, forKey: "canvas-skip-latest-restore")
        }
        resetConfirmation(); cooldownUntil = .distantPast
        isGenerating = false; startedAt = nil
    }

    private func discardReferences(_ old: [ReferenceImage]) {
        old.filter { !runningReferences.values.flatMap { $0 }.contains($0) && !references.contains($0) }
            .forEach { ReferenceImageStore.remove($0) }
    }

    func newConversation() {
        detachCurrentTask()
        do { try persistReferences([]) }
        catch { alertMessage = NetworkAccess.message(error); return }
        let old = references
        startDraft()
        prompt = ""; references = []; referencePreviews = [:]; artwork = nil; image = nil
        discardReferences(old)

    }

    @discardableResult func resumeEditing(_ selected: GeneratedArtwork) -> Bool {
        var added: ReferenceImage?
        do {
            let (reference, preview) = try ReferenceImageStore.save(selected.pngData, name: "图库图片")
            added = reference
            try persistReferences([reference])
            let old = references
            detachCurrentTask()
            startDraft()
            references = [reference]; referencePreviews = [reference.id: preview]
            prompt = selected.prompt; artwork = selected; image = UIImage(data: selected.pngData)
            discardReferences(old)
            return true
        } catch {
            if let added { ReferenceImageStore.remove(added) }
            alertMessage = NetworkAccess.message(error)
            return false
        }
    }

    private func persistJobs() {
        guard shouldPersist else { return }
        if let data = try? JSONEncoder().encode(jobs) { defaults.set(data, forKey: "canvas-jobs-v1") }
        defaults.set(galleryUnread, forKey: "canvas-gallery-unread")
    }
    func detachCurrentTask() {
        for index in jobs.indices where jobs[index].draftID == draftID && !jobs[index].archived { jobs[index].detached = true }
        persistJobs()
    }
    func markGalleryRead() { galleryUnread = false; persistJobs() }
    func openTask(_ job: CanvasGenerationJob) async throws -> GeneratedArtwork? {
        if let error = job.error { throw AppError.invalidResponse(error) }
        guard let id = job.artworkID else { showToast("任务仍在生成，完成后蓝点会亮起"); return nil }
        return try await storage.taskArtwork(id)
    }
    func archiveTask(_ jobID: UUID) async {
        guard let index = jobs.firstIndex(where: { $0.id == jobID }), let artworkID = jobs[index].artworkID else { return }
        do {
            try await storage.archiveTask(artworkID)
            guard let next = jobs.firstIndex(where: { $0.id == jobID }) else { return }
            jobs[next].archived = true; galleryUnread = true; persistJobs()
        } catch { alertMessage = "图片未能归入图库：\(error.localizedDescription)" }
    }
    private func finishError(_ pending: PendingGeneration, message: String) {
        if let index = jobs.firstIndex(where: { $0.id == pending.id }) { jobs[index].state = .failed; jobs[index].error = message }
        persistJobs()
        if pending.draftID == draftID || pending.draftID == nil { alertMessage = message }
    }
    private func endBackgroundTime(job: UUID) {
        if let token = backgroundTokens.removeValue(forKey: job), token != .invalid { UIApplication.shared.endBackgroundTask(token) }
    }

    private func run(_ pending: PendingGeneration) {
        guard generationTasks[pending.id] == nil else { return }
        let promptSnapshot = pending.prompt
        let sizeSnapshot = pending.size
        let configuration = pending.configuration
        let responseDraft = pending.draftID ?? draftID
        runningReferences[pending.id] = pending.allReferences
        if !jobs.contains(where: { $0.id == pending.id }) {
            jobs.append(CanvasGenerationJob(id: pending.id, draftID: responseDraft, prompt: pending.prompt, model: pending.configuration.model, startedAt: pending.startedAt, detached: responseDraft != draftID))
        }
        persistJobs()
        let client: ImageAPIClient
        if let clientOverride { client = clientOverride }
        else {
        #if DEBUG
        if UITestFixtures.enabled { client = UITestFixtures.client() }
        else {
            let transport: any ImageTransport = pending.resolvedTransfer == .standard ? ForegroundImageTransport(job: pending.id) : BackgroundImageTransport(job: pending.id)
            client = ImageAPIClient(apiTransport: transport, downloadTransport: transport)
        }
        #else
        let transport: any ImageTransport = pending.resolvedTransfer == .standard ? ForegroundImageTransport(job: pending.id) : BackgroundImageTransport(job: pending.id)
        client = ImageAPIClient(apiTransport: transport, downloadTransport: transport)
        #endif
        }
        if responseDraft == draftID { isGenerating = true; startedAt = pending.startedAt }
        var useGracePeriod = true
        #if DEBUG
        // Exercise the daemon with the UI suspended, without beginBackgroundTask
        // keeping the fixture app alive throughout its delayed HTTP response.
        if ProcessInfo.processInfo.arguments.contains("ui-test-background-network") { useGracePeriod = false }
        #endif
        if useGracePeriod {
            backgroundTokens[pending.id] = UIApplication.shared.beginBackgroundTask(withName: "保存生成结果") { [weak self] in
                Task { @MainActor in self?.endBackgroundTime(job: pending.id) }
            }
        }
        generationTasks[pending.id] = Task { [weak self] in
            guard let self else { return }
            defer {
                if responseDraft == self.draftID { self.isGenerating = false; self.startedAt = nil }
                self.generationTasks.removeValue(forKey: pending.id)
                let finishedReferences = self.runningReferences.removeValue(forKey: pending.id) ?? []
                self.discardReferences(finishedReferences)
                self.endBackgroundTime(job: pending.id)
                if self.shouldPersist {
                    try? PendingGeneration.clear(id: pending.id)
                    BackgroundTransfers.shared.cleanup(job: pending.id)
                    BackgroundTransfers.foreground.cleanup(job: pending.id)
                }
            }
            do {
                let response = try await client.generate(prompt: promptSnapshot,
                    configuration: configuration, size: sizeSnapshot, sensitivity: pending.sensitivity,
                    referenceImages: ReferenceImageStore.read(pending.allReferences))
                try Task.checkCancellation()
                guard let decoded = UIImage(data: response.data),
                      let cgImage = decoded.cgImage,
                      let png = decoded.pngData() else {
                    throw AppError.invalidResponse("返回数据无法解码为图片，请检查服务端输出格式。")
                }
                let result = GeneratedArtwork(id: UUID(), pngData: png,
                    prompt: promptSnapshot.trimmingCharacters(in: .whitespacesAndNewlines),
                    revisedPrompt: response.revisedPrompt, model: configuration.model,
                    provider: configuration.name, createdAt: Date(),
                    pixelWidth: cgImage.width, pixelHeight: cgImage.height)
                if responseDraft == self.draftID {
                    self.artwork = result
                    self.image = decoded
                    self.cooldownUntil = Date().addingTimeInterval(5)
                    if self.shouldPersist { self.defaults.set(false, forKey: "canvas-skip-latest-restore") }
                }
                if UIApplication.shared.applicationState == .active {
                    AppHaptics.saved()
                }
                do {
                    let detached = self.jobs.first(where: { $0.id == pending.id })?.detached == true
                    if detached { try await self.storage.stage(result) }
                    else { try await self.storage.save(result) }
                    if let index = self.jobs.firstIndex(where: { $0.id == pending.id }) {
                        self.jobs[index].state = .completed; self.jobs[index].artworkID = result.id
                    }
                    self.persistJobs()
                } catch { self.finishError(pending, message: "图片已生成，但缓存未保存。请及时保存相册或导出。") }
            } catch is CancellationError {
                self.finishError(pending, message: "已停止等待，服务端任务可能继续计费")
            } catch let error as URLError where error.code == .cancelled {
                self.finishError(pending, message: "已停止等待，服务端任务可能继续计费")
            } catch let error as URLError where error.code == .timedOut {
                self.finishError(pending, message: "等待超时，服务端可能仍在生成。重新生成会提交新请求。")
            } catch let error as URLError where error.code == .notConnectedToInternet {
                self.finishError(pending, message: "当前没有网络连接，请联网后重试。")
            } catch { self.finishError(pending, message: NetworkAccess.message(error)) }
        }
    }

    func cancel() {
        for job in jobs where job.draftID == draftID && job.state == .running { generationTasks[job.id]?.cancel() }
    }

    func savePhoto() async {
        guard let artwork, !isSavingPhoto else { return }
        isSavingPhoto = true
        defer { isSavingPhoto = false }
        do {
            try await PhotoLibraryService.save(pngData: artwork.pngData)
            showToast("已保存到相册")
            AppHaptics.saved()
        } catch { alertMessage = NetworkAccess.message(error) }
    }

    func showToast(_ message: String) {
        toastTask?.cancel()
        toast = message
        toastTask = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 3_500_000_000) }
            catch { return }
            self?.toast = nil
        }
    }
}
