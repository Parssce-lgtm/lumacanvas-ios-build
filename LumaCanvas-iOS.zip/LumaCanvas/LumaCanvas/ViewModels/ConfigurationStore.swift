import SwiftUI

struct ConfigurationLibrary: Codable {
    var instances: [APIConfiguration]
    var selectedID: UUID
}

@MainActor
final class ConfigurationStore: ObservableObject {
    @Published private(set) var value = APIConfiguration()
    @Published private(set) var instances: [APIConfiguration] = []
    @Published var loadError: String?

    init() {
        #if DEBUG
        if UITestFixtures.enabled { value = UITestFixtures.configuration; instances = [value]; return }
        #endif
        do {
            if let data = try KeychainStore.readData(account: "api-instances-v2") {
                let library = try JSONDecoder().decode(ConfigurationLibrary.self, from: data)
                instances = library.instances
                value = instances.first(where: { $0.id == library.selectedID }) ?? instances.first ?? APIConfiguration()
            } else {
                if var legacy = try KeychainStore.load() {
                    legacy.provider = legacy.provider == .rinko ? .custom : legacy.provider
                    instances.append(legacy)
                    value = legacy
                }
                if !instances.contains(where: { $0.provider == .custom }) { instances.append(.preset(.custom)) }
                if !instances.contains(where: { $0.provider == .openAI }) { instances.append(.preset(.openAI)) }
                if !instances.contains(where: { $0.id == value.id }) { value = instances[0] }
                try persist(instances, selected: value.id)
            }
        }
        catch { loadError = error.localizedDescription }
    }

    func save(_ configuration: APIConfiguration) throws {
        var items = instances
        if let index = items.firstIndex(where: { $0.id == configuration.id }) { items[index] = configuration }
        else { items.append(configuration) }
        try persist(items, selected: configuration.id)
        instances = items
        value = configuration
        loadError = nil
    }

    private func persist(_ items: [APIConfiguration], selected: UUID) throws {
        #if DEBUG
        if UITestFixtures.enabled { return }
        #endif
        try KeychainStore.writeData(JSONEncoder().encode(ConfigurationLibrary(instances: items, selectedID: selected)), account: "api-instances-v2")
    }

    func select(_ id: UUID, saving draft: APIConfiguration) throws -> APIConfiguration {
        try save(draft)
        guard let selected = instances.first(where: { $0.id == id }) else { return draft }
        try persist(instances, selected: id)
        value = selected
        return selected
    }

    func saveAsNew(_ draft: APIConfiguration) throws -> APIConfiguration {
        var new = draft
        new.id = UUID()
        new.provider = .custom
        if new.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { new.name = URL(string: new.site)?.host ?? "自定义" }
        else { new.name += " 副本" }
        try save(new)
        return new
    }

    func clear() throws {
        var cleared = value
        cleared.apiKey = ""
        cleared.extraHeaders = "{}"
        try save(cleared)
    }
}
