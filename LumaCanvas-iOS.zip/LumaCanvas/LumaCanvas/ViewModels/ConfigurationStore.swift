import SwiftUI

struct ConfigurationLibrary: Codable {
    var instances: [APIConfiguration]
    var selectedID: UUID

    static func blank() -> APIConfiguration {
        var configuration = APIConfiguration()
        configuration.name = "配置新 API"
        return configuration
    }

    mutating func removeUnusedPreset() {
        instances.removeAll { item in
            var preset = APIConfiguration.preset(.openAI)
            preset.id = item.id
            return item == preset
        }
        ensureSelection()
    }

    mutating func delete(_ id: UUID) {
        instances.removeAll { $0.id == id }
        ensureSelection()
    }

    private mutating func ensureSelection() {
        if instances.isEmpty { instances = [Self.blank()] }
        if !instances.contains(where: { $0.id == selectedID }) { selectedID = instances[0].id }
    }
}

@MainActor
final class ConfigurationStore: ObservableObject {
    let modelTests = ModelTestStore()
    @Published private(set) var value = APIConfiguration()
    @Published private(set) var instances: [APIConfiguration] = []
    @Published var loadError: String?

    init() {
        #if DEBUG
        if UITestFixtures.enabled { value = UITestFixtures.configuration; instances = [value]; return }
        #endif
        do {
            if let data = try KeychainStore.readData(account: "api-instances-v2") {
                var library = try JSONDecoder().decode(ConfigurationLibrary.self, from: data)
                library.removeUnusedPreset()
                instances = library.instances
                value = instances.first(where: { $0.id == library.selectedID }) ?? instances.first ?? APIConfiguration()
                try persist(instances, selected: value.id)
            } else {
                if var legacy = try KeychainStore.load() {
                    legacy.provider = legacy.provider == .rinko ? .custom : legacy.provider
                    instances.append(legacy)
                    value = legacy
                }
                if instances.isEmpty { instances = [ConfigurationLibrary.blank()] }
                if !instances.contains(where: { $0.id == value.id }) { value = instances[0] }
                try persist(instances, selected: value.id)
            }
        }
        catch { loadError = error.localizedDescription }
    }

    func save(_ configuration: APIConfiguration) throws {
        var items = instances
        if let index = items.firstIndex(where: { $0.id == configuration.id }) { items[index] = configuration }
        else { items.append(configuration) }
        try persist(items, selected: configuration.id)
        instances = items
        value = configuration
        loadError = nil
    }

    private func persist(_ items: [APIConfiguration], selected: UUID) throws {
        #if DEBUG
        if UITestFixtures.enabled { return }
        #endif
        try KeychainStore.writeData(JSONEncoder().encode(ConfigurationLibrary(instances: items, selectedID: selected)), account: "api-instances-v2")
    }

    func select(_ id: UUID, saving draft: APIConfiguration) throws -> APIConfiguration {
        try save(draft)
        guard let selected = instances.first(where: { $0.id == id }) else { return draft }
        try persist(instances, selected: id)
        value = selected
        return selected
    }

    func saveAsNew(_ draft: APIConfiguration) throws -> APIConfiguration {
        var new = draft
        new.id = UUID()
        new.provider = .custom
        if new.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { new.name = URL(string: new.site)?.host ?? "自定义" }
        else { new.name += " 副本" }
        try save(new)
        return new
    }

    func delete(_ id: UUID) throws -> APIConfiguration {
        var library = ConfigurationLibrary(instances: instances, selectedID: value.id)
        library.delete(id)
        try persist(library.instances, selected: library.selectedID)
        instances = library.instances
        value = instances.first(where: { $0.id == library.selectedID })!
        loadError = nil
        return value
    }
}
