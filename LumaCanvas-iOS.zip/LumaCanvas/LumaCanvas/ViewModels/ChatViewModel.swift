import SwiftUI

struct ChatConversation {
    var messages: [ChatMessage] = []
    var adultMode = false
    var error: String?
}

@MainActor
final class ChatViewModel: ObservableObject {
    @Published private(set) var conversations: [UUID: ChatConversation] = [:]
    @Published private(set) var sendingInstance: UUID?
    private var task: Task<Void, Never>?
    private var requestID: UUID?

    func conversation(for id: UUID) -> ChatConversation { conversations[id] ?? ChatConversation() }
    func setAdultMode(_ enabled: Bool, for id: UUID) {
        var conversation = conversation(for: id)
        conversation.adultMode = enabled
        conversations[id] = conversation
    }
    func newConversation(for id: UUID) {
        if sendingInstance == id { stop() }
        conversations[id] = ChatConversation()
    }
    func stop() {
        task?.cancel(); task = nil; requestID = nil; sendingInstance = nil
    }
    func send(_ text: String, configuration: APIConfiguration, client: ChatAPIClient = ChatAPIClient()) {
        guard sendingInstance == nil else { return }
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        let instance = configuration.id
        var conversation = conversation(for: instance)
        do {
            try configuration.validateConversation()
            guard text.utf8.count <= 64 * 1024 else { throw AppError.configuration("单条消息过长，请缩短后发送。") }
        } catch {
            conversation.error = error.localizedDescription; conversations[instance] = conversation; return
        }
        conversation.messages.append(ChatMessage(role: "user", text: text))
        conversation.error = nil
        conversations[instance] = conversation
        let context = conversation.messages
        let adult = conversation.adultMode
        let id = UUID(); requestID = id; sendingInstance = instance
        task = Task { @MainActor [weak self] in
            guard let self else { return }
            defer { if self.requestID == id { self.sendingInstance = nil; self.task = nil; self.requestID = nil } }
            do {
                let reply = try await client.reply(configuration: configuration, messages: context, adultMode: adult)
                try Task.checkCancellation()
                guard self.requestID == id else { return }
                var current = self.conversation(for: instance)
                current.messages.append(ChatMessage(role: "assistant", text: reply))
                self.conversations[instance] = current
            } catch is CancellationError { }
            catch let error as URLError where error.code == .cancelled { }
            catch {
                guard self.requestID == id else { return }
                var current = self.conversation(for: instance)
                // Failed user messages are kept for reading, but not resent automatically.
                current.error = (error as? URLError)?.code == .timedOut ? "聊天请求超时，请稍后手动重试。" : error.localizedDescription
                self.conversations[instance] = current
            }
        }
    }
}
