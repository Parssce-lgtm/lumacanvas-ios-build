import SwiftUI

struct ChatConversation: Identifiable, Codable {
    var id = UUID()
    var instanceID: UUID
    var messages: [ChatMessage] = []
    var createdAt = Date()
    var updatedAt = Date()
    var model = ""
    var adultMode = false
    var temporary = false
    var error: String?
    var title: String { String((messages.first { $0.role == "user" }?.text ?? "新对话").prefix(32)) }
    // Consent, transient errors and temporary status are never restored from disk.
    enum CodingKeys: String, CodingKey { case id, instanceID, messages, createdAt, updatedAt, model }
}

@MainActor
final class ChatViewModel: ObservableObject {
    @Published private(set) var conversations: [UUID: ChatConversation] = [:]
    @Published private(set) var history: [ChatConversation] = []
    @Published private(set) var storageError: String?
    @Published private(set) var sendingInstance: UUID?
    private let directory: URL
    private var task: Task<Void, Never>?
    private var requestID: UUID?

    init(directory: URL? = nil) {
        let defaultDirectory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("LumaCanvas/Chats", isDirectory: true)
        #if DEBUG
        let fixtureDirectory = ProcessInfo.processInfo.arguments.contains("ui-test-fixture")
            ? FileManager.default.temporaryDirectory.appendingPathComponent("Chat-UI-\(UUID().uuidString)") : defaultDirectory
        self.directory = directory ?? fixtureDirectory
        #else
        self.directory = directory ?? defaultDirectory
        #endif
        let archive = self.directory.appendingPathComponent("history.json")
        guard FileManager.default.fileExists(atPath: archive.path) else { return }
        do {
            history = try JSONDecoder().decode([ChatConversation].self, from: Data(contentsOf: archive))
                .sorted { $0.updatedAt > $1.updatedAt }
            for item in history where conversations[item.instanceID] == nil { conversations[item.instanceID] = item }
        } catch { storageError = "聊天记录读取失败，原文件已保留。" }
    }

    func conversation(for id: UUID) -> ChatConversation { conversations[id] ?? ChatConversation(id: id, instanceID: id) }
    func records(for id: UUID) -> [ChatConversation] { history.filter { $0.instanceID == id } }
    private func remember(_ conversation: ChatConversation) {
        guard !conversation.temporary, !conversation.messages.isEmpty else { return }
        history.removeAll { $0.id == conversation.id }
        history.insert(conversation, at: 0)
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true,
                attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
            let archive = directory.appendingPathComponent("history.json")
            // Preserve an unreadable previous archive before replacing it.
            if storageError != nil, FileManager.default.fileExists(atPath: archive.path) {
                try FileManager.default.copyItem(at: archive, to: directory.appendingPathComponent("recovery-\(UUID().uuidString).json"))
            }
            try JSONEncoder().encode(history).write(to: archive, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            storageError = nil
        } catch { storageError = "聊天记录保存失败，当前内容仍保留在应用中。" }
    }
    func setAdultMode(_ enabled: Bool, for id: UUID) {
        var current = conversation(for: id); current.adultMode = enabled; conversations[id] = current
    }
    func newConversation(for id: UUID, temporary: Bool = false) {
        if sendingInstance == id { stop() }
        conversations[id] = ChatConversation(instanceID: id, temporary: temporary)
    }
    func open(_ record: UUID, for instance: UUID) {
        guard let item = history.first(where: { $0.id == record && $0.instanceID == instance }) else { return }
        if sendingInstance == instance { stop() }
        var restored = item; restored.adultMode = false; restored.error = nil
        conversations[instance] = restored
    }
    func endTemporary(for instance: UUID) {
        guard conversations[instance]?.temporary == true else { return }
        if sendingInstance == instance { stop() }
        if var latest = records(for: instance).first {
            latest.adultMode = false; latest.error = nil; conversations[instance] = latest
        } else { conversations[instance] = ChatConversation(instanceID: instance) }
    }
    func endTemporaryChats() {
        for instance in Array(conversations.keys) { endTemporary(for: instance) }
    }
    func stop() {
        task?.cancel(); task = nil; requestID = nil; sendingInstance = nil
    }
    func send(_ text: String, configuration: APIConfiguration, client: ChatAPIClient = ChatAPIClient()) {
        guard sendingInstance == nil else { return }
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        var current = conversation(for: configuration.id)
        do {
            try configuration.validateConversation()
            guard text.utf8.count <= 64 * 1024 else { throw AppError.configuration("单条消息过长，请缩短后发送。") }
        } catch { current.error = error.localizedDescription; conversations[configuration.id] = current; return }
        current.messages.append(ChatMessage(role: "user", text: text))
        start(current, configuration: configuration, client: client)
    }
    func editAndSend(_ message: UUID, text: String, configuration: APIConfiguration, client: ChatAPIClient = ChatAPIClient()) {
        guard sendingInstance == nil, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        let current = conversation(for: configuration.id)
        guard let index = current.messages.firstIndex(where: { $0.id == message && $0.role == "user" }) else { return }
        var branch = current; branch.id = UUID(); branch.createdAt = Date()
        branch.messages = Array(current.messages.prefix(index)); branch.error = nil
        conversations[configuration.id] = branch
        send(text, configuration: configuration, client: client)
    }
    func retry(_ message: UUID, configuration: APIConfiguration, client: ChatAPIClient = ChatAPIClient()) {
        guard sendingInstance == nil else { return }
        var current = conversation(for: configuration.id)
        guard let index = current.messages.firstIndex(where: { $0.id == message }),
              let userIndex = current.messages.prefix(index + 1).lastIndex(where: { $0.role == "user" }) else { return }
        do { try configuration.validateConversation() }
        catch { current.error = error.localizedDescription; conversations[configuration.id] = current; return }
        // A failed final user message retries in place. Regeneration preserves the original as a branch.
        if userIndex != current.messages.count - 1 { current.id = UUID(); current.createdAt = Date() }
        current.messages = Array(current.messages.prefix(userIndex + 1))
        start(current, configuration: configuration, client: client)
    }
    private func start(_ conversation: ChatConversation, configuration: APIConfiguration, client: ChatAPIClient) {
        let instance = configuration.id
        var current = conversation; current.error = nil; current.updatedAt = Date(); current.model = configuration.conversationModel
        conversations[instance] = current; remember(current)
        let context = current.messages, adult = current.adultMode, conversationID = current.id
        let id = UUID(); requestID = id; sendingInstance = instance
        task = Task { @MainActor [weak self] in
            guard let self else { return }
            defer { if self.requestID == id { self.sendingInstance = nil; self.task = nil; self.requestID = nil } }
            do {
                let reply = try await client.reply(configuration: configuration, messages: context, adultMode: adult)
                try Task.checkCancellation()
                guard self.requestID == id, self.conversations[instance]?.id == conversationID else { return }
                var result = self.conversation(for: instance)
                result.messages.append(ChatMessage(role: "assistant", text: reply)); result.updatedAt = Date()
                self.conversations[instance] = result; self.remember(result)
            } catch is CancellationError { }
            catch let error as URLError where error.code == .cancelled { }
            catch {
                guard self.requestID == id, self.conversations[instance]?.id == conversationID else { return }
                var result = self.conversation(for: instance)
                result.error = (error as? URLError)?.code == .timedOut ? "聊天请求超时，请稍后手动重试。" : error.localizedDescription
                self.conversations[instance] = result
            }
        }
    }
}
