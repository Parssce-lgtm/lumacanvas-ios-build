import SwiftUI

struct ChatConversation: Identifiable, Codable {
    var id = UUID()
    var instanceID: UUID
    var messages: [ChatMessage] = []
    var createdAt = Date()
    var updatedAt = Date()
    var model = ""
    var adultMode = false
    var temporary = false
    var error: String?
    var customTitle: String?
    var pinned = false
    var title: String {
        if let customTitle, !customTitle.isEmpty { return customTitle }
        guard let first = messages.first(where: { $0.role == "user" }) else { return "新对话" }
        return String((first.text.isEmpty ? (first.attachments.first?.name ?? "新对话") : first.text).prefix(32))
    }
    // Consent, transient errors and temporary status are never restored from disk.
    enum CodingKeys: String, CodingKey { case id, instanceID, messages, createdAt, updatedAt, model, customTitle, pinned }
}

@MainActor
final class ChatViewModel: ObservableObject {
    @Published private(set) var conversations: [UUID: ChatConversation] = [:]
    @Published private(set) var history: [ChatConversation] = []
    @Published private(set) var storageError: String?
    @Published private(set) var sendingInstance: UUID?
    private let directory: URL
    private var task: Task<Void, Never>?
    private var requestID: UUID?

    init(directory: URL? = nil) {
        let defaultDirectory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("LumaCanvas/Chats", isDirectory: true)
        #if DEBUG
        let fixtureDirectory = ProcessInfo.processInfo.arguments.contains("ui-test-fixture")
            ? FileManager.default.temporaryDirectory.appendingPathComponent("Chat-UI-\(UUID().uuidString)") : defaultDirectory
        self.directory = directory ?? fixtureDirectory
        #else
        self.directory = directory ?? defaultDirectory
        #endif
        let archive = self.directory.appendingPathComponent("history.json")
        guard FileManager.default.fileExists(atPath: archive.path) else { return }
        do {
            history = try JSONDecoder().decode([ChatConversation].self, from: Data(contentsOf: archive))
                .sorted { $0.updatedAt > $1.updatedAt }
            for item in history where conversations[item.instanceID] == nil { conversations[item.instanceID] = item }
        } catch { storageError = "聊天记录读取失败，原文件已保留。" }
    }

    func conversation(for id: UUID) -> ChatConversation { conversations[id] ?? ChatConversation(id: id, instanceID: id) }
    func records(for id: UUID) -> [ChatConversation] { history.filter { $0.instanceID == id }.sorted { $0.pinned != $1.pinned ? $0.pinned : $0.updatedAt > $1.updatedAt } }
    private func remember(_ conversation: ChatConversation) {
        guard !conversation.temporary, !conversation.messages.isEmpty else { return }
        history.removeAll { $0.id == conversation.id }
        history.insert(conversation, at: 0)
        persistHistory()
    }
    private func persistHistory() {
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true,
                attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
            let archive = directory.appendingPathComponent("history.json")
            // Preserve an unreadable previous archive before replacing it.
            if storageError != nil, FileManager.default.fileExists(atPath: archive.path) {
                try FileManager.default.copyItem(at: archive, to: directory.appendingPathComponent("recovery-\(UUID().uuidString).json"))
            }
            try JSONEncoder().encode(history).write(to: archive, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            storageError = nil
        } catch { storageError = "聊天记录保存失败，当前内容仍保留在应用中。" }
    }
    func rename(_ record: UUID, title: String) {
        guard let index = history.firstIndex(where: { $0.id == record }) else { return }
        history[index].customTitle = String(title.trimmingCharacters(in: .whitespacesAndNewlines).prefix(80))
        synchronizeRecord(history[index]); persistHistory()
    }
    func togglePin(_ record: UUID) {
        guard let index = history.firstIndex(where: { $0.id == record }) else { return }
        history[index].pinned.toggle(); synchronizeRecord(history[index]); persistHistory()
    }
    func delete(_ record: UUID) {
        guard let item = history.first(where: { $0.id == record }) else { return }
        history.removeAll { $0.id == record }
        if conversations[item.instanceID]?.id == record { newConversation(for: item.instanceID) }
        persistHistory()
    }
    private func synchronizeRecord(_ record: ChatConversation) {
        if conversations[record.instanceID]?.id == record.id { conversations[record.instanceID] = record }
    }
    func setAdultMode(_ enabled: Bool, for id: UUID) {
        var current = conversation(for: id); current.adultMode = enabled; conversations[id] = current
    }
    func newConversation(for id: UUID, temporary: Bool = false) {
        if sendingInstance == id { stop() }
        conversations[id] = ChatConversation(instanceID: id, temporary: temporary)
    }
    func open(_ record: UUID, for instance: UUID) {
        guard let item = history.first(where: { $0.id == record && $0.instanceID == instance }) else { return }
        if sendingInstance == instance { stop() }
        var restored = item; restored.adultMode = false; restored.error = nil
        conversations[instance] = restored
    }
    func endTemporary(for instance: UUID) {
        guard conversations[instance]?.temporary == true else { return }
        if sendingInstance == instance { stop() }
        if var latest = records(for: instance).first {
            latest.adultMode = false; latest.error = nil; conversations[instance] = latest
        } else { conversations[instance] = ChatConversation(instanceID: instance) }
    }
    func endTemporaryChats() {
        for instance in Array(conversations.keys) { endTemporary(for: instance) }
    }
    func stop() {
        task?.cancel(); task = nil; requestID = nil; sendingInstance = nil
    }
    @discardableResult
    func send(_ text: String, attachments: [ChatAttachment] = [], configuration: APIConfiguration, client: ChatAPIClient = ChatAPIClient()) -> Bool {
        guard sendingInstance == nil else { return false }
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty || !attachments.isEmpty else { return false }
        var current = conversation(for: configuration.id)
        do {
            try configuration.validateConversation()
            try ChatAttachment.validate(attachments)
            guard text.utf8.count <= 64 * 1024 else { throw AppError.configuration("单条消息过长，请缩短后发送。") }
        } catch { current.error = error.localizedDescription; conversations[configuration.id] = current; return false }
        current.messages.append(ChatMessage(role: "user", text: text, attachments: attachments))
        start(current, configuration: configuration, client: client)
        return true
    }
    @discardableResult
    func editAndSend(_ message: UUID, text: String, attachments: [ChatAttachment]? = nil, configuration: APIConfiguration, client: ChatAPIClient = ChatAPIClient()) -> Bool {
        guard sendingInstance == nil else { return false }
        let current = conversation(for: configuration.id)
        guard let index = current.messages.firstIndex(where: { $0.id == message && $0.role == "user" }) else { return false }
        let files = attachments ?? current.messages[index].attachments
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !files.isEmpty else { return false }
        do { try configuration.validateConversation(); try ChatAttachment.validate(files) }
        catch { return false }
        var branch = current; branch.id = UUID(); branch.createdAt = Date()
        branch.messages = Array(current.messages.prefix(index)); branch.error = nil
        conversations[configuration.id] = branch
        return send(text, attachments: files, configuration: configuration, client: client)
    }
    func retry(_ message: UUID, configuration: APIConfiguration, client: ChatAPIClient = ChatAPIClient()) {
        guard sendingInstance == nil else { return }
        var current = conversation(for: configuration.id)
        guard let index = current.messages.firstIndex(where: { $0.id == message }),
              let userIndex = current.messages.prefix(index + 1).lastIndex(where: { $0.role == "user" }) else { return }
        do { try configuration.validateConversation() }
        catch { current.error = error.localizedDescription; conversations[configuration.id] = current; return }
        // A failed final user message retries in place. Regeneration preserves the original as a branch.
        if userIndex != current.messages.count - 1 { current.id = UUID(); current.createdAt = Date() }
        current.messages = Array(current.messages.prefix(userIndex + 1))
        start(current, configuration: configuration, client: client)
    }
    private func start(_ conversation: ChatConversation, configuration: APIConfiguration, client: ChatAPIClient) {
        let instance = configuration.id
        var current = conversation; current.error = nil; current.updatedAt = Date(); current.model = configuration.conversationModel
        conversations[instance] = current; remember(current)
        let context = current.messages, adult = current.adultMode, conversationID = current.id
        let id = UUID(); requestID = id; sendingInstance = instance
        task = Task { @MainActor [weak self] in
            guard let self else { return }
            defer { if self.requestID == id { self.sendingInstance = nil; self.task = nil; self.requestID = nil } }
            do {
                let reply = try await client.reply(configuration: configuration, messages: context, adultMode: adult)
                try Task.checkCancellation()
                guard self.requestID == id, self.conversations[instance]?.id == conversationID else { return }
                var result = self.conversation(for: instance)
                let (text, files) = ChatDocuments.extract(reply)
                result.messages.append(ChatMessage(role: "assistant", text: text, attachments: files, sourceText: files.isEmpty ? nil : reply)); result.updatedAt = Date()
                self.conversations[instance] = result; self.remember(result)
            } catch is CancellationError { }
            catch let error as URLError where error.code == .cancelled { }
            catch {
                guard self.requestID == id, self.conversations[instance]?.id == conversationID else { return }
                var result = self.conversation(for: instance)
                result.error = (error as? URLError)?.code == .timedOut ? "聊天请求超时，请稍后手动重试。" : NetworkAccess.message(error)
                self.conversations[instance] = result
            }
        }
    }
}

extension ChatConversation {
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(UUID.self, forKey: .id)
        instanceID = try values.decode(UUID.self, forKey: .instanceID)
        messages = try values.decode([ChatMessage].self, forKey: .messages)
        createdAt = try values.decode(Date.self, forKey: .createdAt)
        updatedAt = try values.decode(Date.self, forKey: .updatedAt)
        model = try values.decode(String.self, forKey: .model)
        customTitle = try values.decodeIfPresent(String.self, forKey: .customTitle)
        pinned = try values.decodeIfPresent(Bool.self, forKey: .pinned) ?? false
    }
}
