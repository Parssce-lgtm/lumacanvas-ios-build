import Foundation

struct ModelOption: Identifiable, Equatable {
    var id: String
    var imageGeneration: Bool? = nil
    var tested = false

    var isImageCandidate: Bool {
        if let imageGeneration { return imageGeneration }
        let name = id.lowercased()
        if ["vision", "embedding", "caption", "ocr", "understanding"].contains(where: name.contains) { return false }
        return ["gpt-image", "chatgpt-image", "dall-e", "flux", "imagen", "ideogram", "recraft", "seedream",
            "hunyuan-image", "kolors", "stable-diffusion", "sdxl", "nai-diffusion", "qwen-image", "nano-banana",
            "text-to-image"].contains(where: name.contains)
            || name.hasPrefix("image-") || name.hasSuffix("-image") || name.contains("-image-")
    }

    var evidence: String {
        tested ? "已测试" : imageGeneration == true ? "接口标记" : isImageCandidate ? "名称识别" : ""
    }

    static func parse(_ data: Data) throws -> [Self] {
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let rows = root["data"] as? [[String: Any]] else {
            throw AppError.invalidResponse("模型列表格式不兼容，可手动填写模型名。")
        }
        var unique: [String: Self] = [:]
        for row in rows {
            guard let id = row["id"] as? String else { throw AppError.invalidResponse("模型列表缺少模型名称。") }
            guard !id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { continue }
            let capabilities = row["capabilities"] as? [String: Any]
            var flag = capabilities?["image_generation"] as? Bool ?? row["supports_image_generation"] as? Bool
            if flag == nil {
                let outputs = (row["output_modalities"] as? [String] ?? []).map { $0.lowercased() }
                let endpoints = (row["supported_endpoints"] as? [String] ?? []) + (row["supported_endpoint_types"] as? [String] ?? [])
                let tools = row["capabilities"] as? [String] ?? []
                if outputs.contains("image") || outputs.contains("images") || tools.contains("image_generation")
                    || endpoints.contains(where: { $0.contains("images/generations") || $0.contains("images/edits") || ["image-generation", "image_generation"].contains($0) }) { flag = true }
            }
            let option = Self(id: id, imageGeneration: flag)
            if unique[id] == nil || unique[id]?.imageGeneration == nil { unique[id] = option }
        }
        return ordered(Array(unique.values))
    }

    static func ordered(_ values: [Self]) -> [Self] {
        values.sorted {
            if $0.isImageCandidate != $1.isImageCandidate { return $0.isImageCandidate }
            return $0.id.localizedStandardCompare($1.id) == .orderedAscending
        }
    }
}
