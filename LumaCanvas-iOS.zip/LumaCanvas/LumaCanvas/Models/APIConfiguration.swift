import Foundation

enum Provider: String, Codable, CaseIterable, Identifiable {
    case rinko, openAI, custom
    var id: String { rawValue }
    var title: String {
        switch self {
        case .rinko: return "Rinko"
        case .openAI: return "OpenAI"
        case .custom: return "自定义"
        }
    }
}

enum GenerationMode: String, Codable, CaseIterable, Identifiable {
    case images, chatCompletions
    var id: String { rawValue }
    var title: String { self == .images ? "标准 Images" : "对话式生图" }
}

enum GenerationTransfer: String, Codable, CaseIterable, Identifiable {
    case standard, background
    var id: String { rawValue }
    var title: String { self == .standard ? "常规请求（默认）" : "系统后台传输" }
}

enum NAIChatFormat: String, Codable, CaseIterable, Identifiable {
    case automatic, text, parameters
    var id: String { rawValue }
    var title: String {
        switch self { case .automatic: return "自动"; case .text: return "普通文字"; case .parameters: return "NAI 参数 JSON" }
    }
}

struct APIConfiguration: Codable, Equatable {
    var id = UUID()
    var name = "自定义"
    var site = ""
    var provider: Provider = .custom
    var mode: GenerationMode = .images
    var endpoint = ""
    var editsEndpoint = ""
    var modelsEndpoint = ""
    var apiKey = ""
    var model = ""
    var size = "auto"
    var quality = ""
    var responseFormat = ""
    var extraBody = "{}"
    var extraHeaders = "{}"
    var timeout: Double = 180
    var chatStreaming = false
    var transfer: GenerationTransfer = .standard
    var naiChatFormat: NAIChatFormat = .automatic

    init() {}

    enum CodingKeys: String, CodingKey {
        case id, name, site, provider, mode, endpoint, editsEndpoint, modelsEndpoint, apiKey, model, size, quality, responseFormat, extraBody, extraHeaders, timeout, chatStreaming, transfer, naiChatFormat
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        provider = try c.decodeIfPresent(Provider.self, forKey: .provider) ?? .custom
        name = try c.decodeIfPresent(String.self, forKey: .name) ?? provider.title
        mode = try c.decodeIfPresent(GenerationMode.self, forKey: .mode) ?? .images
        endpoint = try c.decodeIfPresent(String.self, forKey: .endpoint) ?? ""
        editsEndpoint = try c.decodeIfPresent(String.self, forKey: .editsEndpoint) ?? ""
        modelsEndpoint = try c.decodeIfPresent(String.self, forKey: .modelsEndpoint) ?? ""
        site = try c.decodeIfPresent(String.self, forKey: .site) ?? URL(string: endpoint).map { "https://" + ($0.host ?? "") } ?? ""
        apiKey = try c.decodeIfPresent(String.self, forKey: .apiKey) ?? ""
        model = try c.decodeIfPresent(String.self, forKey: .model) ?? ""
        size = try c.decodeIfPresent(String.self, forKey: .size) ?? "auto"
        quality = try c.decodeIfPresent(String.self, forKey: .quality) ?? ""
        responseFormat = try c.decodeIfPresent(String.self, forKey: .responseFormat) ?? ""
        extraBody = try c.decodeIfPresent(String.self, forKey: .extraBody) ?? "{}"
        extraHeaders = try c.decodeIfPresent(String.self, forKey: .extraHeaders) ?? "{}"
        timeout = try c.decodeIfPresent(Double.self, forKey: .timeout) ?? 180
        chatStreaming = try c.decodeIfPresent(Bool.self, forKey: .chatStreaming) ?? false
        transfer = try c.decodeIfPresent(GenerationTransfer.self, forKey: .transfer) ?? .standard
        naiChatFormat = try c.decodeIfPresent(NAIChatFormat.self, forKey: .naiChatFormat) ?? .automatic
    }

    static func preset(_ provider: Provider) -> Self {
        var value = Self()
        value.provider = provider
        value.name = provider.title
        switch provider {
        case .rinko:
            value.provider = .custom
            value.site = "https://api.rinko.ai"
            value.mode = .chatCompletions
            value.endpoint = "https://api.rinko.ai/v1/chat/completions"
            value.modelsEndpoint = "https://api.rinko.ai/v1/models"
        case .openAI:
            value.site = "https://api.openai.com"
            value.mode = .images
            value.endpoint = "https://api.openai.com/v1/images/generations"
            value.modelsEndpoint = "https://api.openai.com/v1/models"
            value.model = "gpt-image-1"
        case .custom:
            value.mode = .images
            value.endpoint = ""
            value.modelsEndpoint = ""
        }
        // A provider switch creates an empty credential field to prevent accidental key reuse.
        return value
    }

    var isReady: Bool {
        (try? validate()) != nil
    }

    var isNAIModel: Bool { model.trimmingCharacters(in: .whitespacesAndNewlines).lowercased().hasPrefix("nai-diffusion-") }
    var usesNAIParameters: Bool {
        guard isNAIModel, mode == .chatCompletions else { return false }
        switch naiChatFormat {
        case .text: return false
        case .parameters: return true
        case .automatic:
            return ["api.rinko.ai", "nai.rinko.ai"].contains(URL(string: endpoint)?.host?.lowercased() ?? "")
        }
    }

    func validate(requireModel: Bool = true) throws {
        _ = try Self.httpsURL(endpoint)
        guard !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw AppError.configuration("请填写 API Key。")
        }
        guard !apiKey.contains("\r"), !apiKey.contains("\n") else {
            throw AppError.configuration("API Key 不能包含换行，请重新粘贴。")
        }
        if requireModel && model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            throw AppError.configuration("请填写生图模型，或从模型列表中选择。")
        }
        guard timeout.isFinite, (30...600).contains(timeout) else {
            throw AppError.configuration("超时应在 30～600 秒之间。")
        }
        guard ["", "url", "b64_json"].contains(responseFormat) else {
            throw AppError.configuration("返回格式应为自动、url 或 b64_json。")
        }
        let body = try Self.jsonObject(extraBody, label: "额外请求参数")
        let reserved: Set<String> = ["model", "prompt", "messages", "image", "images", "n", "size", "quality", "response_format", "stream", "moderation"]
        if let key = body.keys.sorted().first(where: { reserved.contains($0) }) {
            throw AppError.configuration("额外参数中的 \(key) 与内置字段冲突，请使用对应设置。暂不支持流式或异步任务协议。")
        }
        _ = try headers()
    }

    func headers() throws -> [String: String] {
        let object = try Self.jsonObject(extraHeaders, label: "额外请求头")
        var result: [String: String] = [:]
        var names = Set<String>()
        let tokens = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&'*+-.^_`|~")
        for (name, rawValue) in object {
            guard !name.isEmpty, name.unicodeScalars.allSatisfy({ tokens.contains($0) }),
                  let value = rawValue as? String,
                  !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
                throw AppError.configuration("额外请求头必须是合法名称和字符串值，不能包含换行。")
            }
            let lower = name.lowercased()
            guard !["authorization", "content-type", "host", "content-length", "cookie"].contains(lower), names.insert(lower).inserted else {
                throw AppError.configuration("不能覆盖或重复内置请求头：\(name)。")
            }
            result[name] = value
        }
        return result
    }

    func referenceEndpoint() throws -> URL {
        let generation = try Self.httpsURL(endpoint)
        let edited: URL
        if !editsEndpoint.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            edited = try Self.httpsURL(editsEndpoint)
        } else if generation.path.hasSuffix("/images/generations") {
            edited = generation.deletingLastPathComponent().appendingPathComponent("edits")
        } else if generation.path.hasSuffix("/images/edits") {
            edited = generation
        } else {
            throw AppError.configuration("这个自定义接口不能自动确定参考图地址，请在 API 设置中填写参考图生图地址。")
        }
        guard edited.host?.lowercased() == generation.host?.lowercased(),
              (edited.port ?? 443) == (generation.port ?? 443) else {
            throw AppError.configuration("参考图接口须与生图接口使用相同域名和端口。")
        }
        return edited
    }

    static func jsonObject(_ text: String, label: String) throws -> [String: Any] {
        let source = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if source.isEmpty { return [:] }
        guard let data = source.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data),
              let dictionary = object as? [String: Any] else {
            throw AppError.configuration("\(label)须为 JSON 对象，例如 {\"quality\":\"high\"}，不能是数组。")
        }
        return dictionary
    }

    static func httpsURL(_ string: String) throws -> URL {
        let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed), url.scheme?.lowercased() == "https",
              let host = url.host, !host.isEmpty, url.user == nil, url.password == nil,
              url.fragment == nil else {
            throw AppError.configuration("请填写完整的 HTTPS 地址，不要在地址中放入账号、密钥或片段。")
        }
        return url
    }
}

enum Sensitivity: String, Codable, CaseIterable, Identifiable {
    case high, low, off
    var id: String { rawValue }
    var title: String { switch self { case .high: return "高"; case .low: return "低"; case .off: return "关" } }
    var parameter: String? { switch self { case .high: return "auto"; case .low: return "low"; case .off: return nil } }
}

enum ArtworkRatio: String, CaseIterable, Identifiable {
    case auto, square = "1:1", wide = "16:9", classic = "5:4", portrait = "3:4"
    var id: String { rawValue }
    var title: String { self == .auto ? "自动" : rawValue }
    func size(landscape: Bool, nai: Bool = false) -> String {
        switch self {
        case .auto: return "auto"
        case .square: return "1024x1024"
        case .wide:
            if nai { return landscape ? "1024x576" : "576x1024" }
            return landscape ? "1536x864" : "864x1536"
        case .classic: return landscape ? "1280x1024" : "1024x1280"
        case .portrait: return landscape ? "1024x768" : "768x1024"
        }
    }
}

enum AppError: LocalizedError {
    case configuration(String)
    case server(Int, String)
    case invalidResponse(String)
    case photoPermission
    case storage(String)

    var errorDescription: String? {
        switch self {
        case .configuration(let text), .invalidResponse(let text), .storage(let text): return text
        case .server(let code, let text): return "请求失败（HTTP \(code)）\n\(text)"
        case .photoPermission: return "无法写入相册。请在系统设置中允许映想添加照片，或使用“导出到文件”。"
        }
    }
}
