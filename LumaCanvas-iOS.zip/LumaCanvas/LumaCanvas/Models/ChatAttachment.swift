import Foundation
import UIKit
import UniformTypeIdentifiers

struct ChatAttachment: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var mimeType: String
    var data: Data
    var isImage: Bool { mimeType.hasPrefix("image/") }
    static let maximumCount = 8
    static let maximumBytes = 12 * 1024 * 1024

    static func validate(_ items: [Self]) throws {
        guard items.count <= maximumCount else { throw AppError.configuration("每条消息最多添加 8 个附件。") }
        guard items.allSatisfy({ !$0.data.isEmpty && $0.data.count <= 4 * 1024 * 1024 }),
              items.reduce(0, { $0 + $1.data.count }) <= maximumBytes else {
            throw AppError.configuration("单个附件不能超过 4 MB，附件合计不能超过 12 MB。")
        }
    }
    static func image(_ data: Data, name: String) throws -> Self {
        let png = try ReferenceImageStore.normalizedData(data)
        guard let image = UIImage(data: png), let jpeg = image.jpegData(compressionQuality: 0.85) else {
            throw AppError.configuration("无法读取图片。")
        }
        let result = Self(name: name, mimeType: "image/jpeg", data: jpeg)
        try validate([result]); return result
    }
    static func file(_ url: URL) throws -> Self {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let values = try url.resourceValues(forKeys: [.fileSizeKey, .isDirectoryKey, .contentTypeKey])
        guard values.isDirectory != true, let size = values.fileSize, size > 0,
              size <= ReferenceImageStore.maximumInputBytes else { throw AppError.configuration("文件为空或超过 50 MB。") }
        let data = try Data(contentsOf: url)
        if values.contentType?.conforms(to: .image) == true || UIImage(data: data) != nil {
            return try image(data, name: url.lastPathComponent)
        }
        let result: Self
        if data.starts(with: Data("%PDF-".utf8)) {
            result = Self(name: url.lastPathComponent, mimeType: "application/pdf", data: data)
        } else if String(data: data, encoding: .utf8) != nil && !data.contains(0) {
            result = Self(name: url.lastPathComponent, mimeType: "text/plain", data: data)
        } else {
            throw AppError.configuration("当前聊天接口支持图片、PDF 和文字文件。请将其他文档导出为 PDF 后选择。")
        }
        try validate([result]); return result
    }
    func contentPart() -> [String: Any] {
        if isImage { return ["type": "image_url", "image_url": ["url": "data:\(mimeType);base64,\(data.base64EncodedString())"]] }
        if mimeType == "application/pdf" {
            return ["type": "file", "file": ["filename": name, "file_data": "data:application/pdf;base64,\(data.base64EncodedString())"]]
        }
        return ["type": "text", "text": "文件：\(name)\n\(String(decoding: data, as: UTF8.self))"]
    }
}
