import Foundation

struct GeneratedArtwork: Codable, Identifiable {
    let id: UUID
    let pngData: Data
    let prompt: String
    let revisedPrompt: String?
    let model: String
    let provider: String
    let createdAt: Date
    let pixelWidth: Int
    let pixelHeight: Int

    var fileName: String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        return "Luma-\(formatter.string(from: createdAt))-\(id.uuidString.prefix(6))"
    }
}

struct ArtworkSummary: Codable, Identifiable, Equatable {
    let id: UUID
    let prompt: String
    let revisedPrompt: String?
    let model: String
    let provider: String
    let createdAt: Date
    let pixelWidth: Int
    let pixelHeight: Int

    init(_ artwork: GeneratedArtwork) {
        id = artwork.id; prompt = artwork.prompt; revisedPrompt = artwork.revisedPrompt
        model = artwork.model; provider = artwork.provider; createdAt = artwork.createdAt
        pixelWidth = artwork.pixelWidth; pixelHeight = artwork.pixelHeight
    }
    func artwork(png: Data) -> GeneratedArtwork {
        GeneratedArtwork(id: id, pngData: png, prompt: prompt, revisedPrompt: revisedPrompt,
            model: model, provider: provider, createdAt: createdAt, pixelWidth: pixelWidth, pixelHeight: pixelHeight)
    }
}
