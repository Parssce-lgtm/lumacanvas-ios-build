import Foundation

struct CanvasGenerationJob: Codable, Identifiable {
    enum State: String, Codable { case running, completed, failed }
    let id: UUID
    let draftID: UUID
    let prompt: String
    let model: String
    let startedAt: Date
    var state: State = .running
    var detached = false
    var archived = false
    var artworkID: UUID?
    var error: String?
    var title: String { prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "生图任务" : prompt }
}
