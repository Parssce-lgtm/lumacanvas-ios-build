import XCTest
import UIKit
@testable import LumaCanvas

private actor RecordingTransport: ImageTransport {
    enum Reply {
        case response(Data, Int)
        case failure(URLError)
    }
    private var replies: [Reply]
    private(set) var requests: [URLRequest] = []

    init(_ replies: [Reply]) { self.replies = replies }

    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        requests.append(request)
        guard !replies.isEmpty else { throw URLError(.badServerResponse) }
        switch replies.removeFirst() {
        case .response(let data, let status):
            guard data.count <= byteLimit else { throw URLError(.dataLengthExceedsMaximum) }
            return (data, HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil, headerFields: nil)!)
        case .failure(let error): throw error
        }
    }
}

final class ImageAPIClientTests: XCTestCase {
    private let tinyPNG = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg==")!

    private func configuration() -> APIConfiguration {
        var value = APIConfiguration()
        value.mode = .images
        value.endpoint = "https://api.rinko.ai/v1/images/generations"
        value.modelsEndpoint = "https://api.rinko.ai/v1/models"
        value.apiKey = "test-secret"
        value.model = "provider-image-model"
        return value
    }

    private func json(_ object: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: object)
    }

    func testRinkoBase64ResultAndProviderParameters() async throws {
        var settings = configuration()
        settings.extraBody = "{\"background\":\"transparent\",\"output_format\":\"png\"}"
        let api = RecordingTransport([.response(try json([
            "data": [["b64_json": tinyPNG.base64EncodedString(), "revised_prompt": "revised"]]
        ]), 200)])
        let downloads = RecordingTransport([])
        let client = ImageAPIClient(apiTransport: api, downloadTransport: downloads)
        let result = try await client.generate(prompt: "  一只猫  ", configuration: settings, size: "1024x1536")
        XCTAssertEqual(result.data, tinyPNG)
        XCTAssertNotNil(UIImage(data: result.data))
        XCTAssertEqual(result.revisedPrompt, "revised")
        let requests = await api.requests
        XCTAssertEqual(requests.count, 1)
        let request = try XCTUnwrap(requests.first)
        XCTAssertEqual(request.url?.absoluteString, "https://api.rinko.ai/v1/images/generations")
        XCTAssertEqual(request.httpMethod, "POST")
        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-secret")
        let body = try XCTUnwrap(try JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
        XCTAssertEqual(body["prompt"] as? String, "一只猫")
        XCTAssertEqual(body["size"] as? String, "1024x1536")
        XCTAssertEqual(body["background"] as? String, "transparent")
        XCTAssertNil(body["response_format"], "GPT Image must omit the legacy response_format parameter by default")
        let downloadRequests = await downloads.requests
        XCTAssertTrue(downloadRequests.isEmpty)
    }

    func testImageURLDownloadsWithoutCredentialsOrCustomHeaders() async throws {
        var settings = configuration()
        settings.extraHeaders = "{\"X-Provider-Token\":\"another-secret\"}"
        let api = RecordingTransport([.response(try json([
            "data": [["url": "https://cdn.example.com/image.png?signature=abc"]]
        ]), 200)])
        let downloads = RecordingTransport([.response(tinyPNG, 200)])
        let result = try await ImageAPIClient(apiTransport: api, downloadTransport: downloads)
            .generate(prompt: "cat", configuration: settings, size: settings.size)
        XCTAssertEqual(result.data, tinyPNG)
        let requests = await downloads.requests
        let request = try XCTUnwrap(requests.first)
        XCTAssertEqual(request.url?.host, "cdn.example.com")
        XCTAssertNil(request.value(forHTTPHeaderField: "Authorization"))
        XCTAssertNil(request.value(forHTTPHeaderField: "X-Provider-Token"))
        XCTAssertNil(request.httpBody)
    }

    func testRinkoChatModeParsesMarkdownDataURLWithoutImagesOnlyParameters() async throws {
        var settings = APIConfiguration.preset(.rinko)
        settings.apiKey = "test-secret"
        settings.model = "provider-image-model"
        let content = "已生成：\n![结果](data:image/png;base64,\(tinyPNG.base64EncodedString()))"
        let api = RecordingTransport([.response(try json([
            "choices": [["message": ["role": "assistant", "content": content]]]
        ]), 200)])
        let result = try await ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
            .generate(prompt: "一只猫", configuration: settings, size: "1024x1536")
        XCTAssertEqual(result.data, tinyPNG)
        let requests = await api.requests
        let request = try XCTUnwrap(requests.first)
        XCTAssertEqual(request.url?.path, "/v1/chat/completions")
        let body = try XCTUnwrap(try JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
        XCTAssertNil(body["prompt"])
        XCTAssertNil(body["size"])
        XCTAssertNil(body["quality"])
        XCTAssertNil(body["response_format"])
        XCTAssertEqual(body["stream"] as? Bool, false)
        let messages = try XCTUnwrap(body["messages"] as? [[String: String]])
        XCTAssertTrue(messages[0]["content"]?.contains("1024x1536") == true)
    }

    func testChatModeParsesStructuredImageResults() async throws {
        var settings = APIConfiguration.preset(.rinko)
        settings.apiKey = "test-secret"
        settings.model = "provider-image-model"
        let dataURL = "data:image/png;base64,\(tinyPNG.base64EncodedString())"
        for message in [
            ["images": [["type": "image_url", "image_url": ["url": dataURL]]], "content": "done"],
            ["content": [["type": "image_url", "image_url": ["url": dataURL]]]],
            ["content": [["type": "text", "text": "![result](\(dataURL))"]]]
        ] as [[String: Any]] {
            let api = RecordingTransport([.response(try json(["choices": [["message": message]]]), 200)])
            let result = try await ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
                .generate(prompt: "cat", configuration: settings, size: "")
            XCTAssertEqual(result.data, tinyPNG)
        }
    }

    func testChatModeDoesNotTreatProseLinksAsGeneratedImages() async throws {
        var settings = APIConfiguration.preset(.rinko)
        settings.apiKey = "test-secret"
        settings.model = "provider-text-model"
        let api = RecordingTransport([.response(try json([
            "choices": [["message": ["content": "请查看文档 https://example.com/docs"]]]
        ]), 200)])
        let downloads = RecordingTransport([])
        do {
            _ = try await ImageAPIClient(apiTransport: api, downloadTransport: downloads)
                .generate(prompt: "cat", configuration: settings, size: "")
            XCTFail("Text-only output must not trigger an unrelated URL download")
        } catch { XCTAssertTrue(error.localizedDescription.contains("只返回了文字")) }
        let requests = await downloads.requests
        XCTAssertTrue(requests.isEmpty)
    }

    func testServerErrorIsNotRetriedAndRedactsAPIKey() async throws {
        let api = RecordingTransport([.response(try json([
            "error": ["message": "invalid test-secret"]
        ]), 401)])
        let client = ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
        do {
            _ = try await client.generate(prompt: "cat", configuration: configuration(), size: "")
            XCTFail("Expected an authentication error")
        } catch {
            XCTAssertFalse(error.localizedDescription.contains("test-secret"))
            XCTAssertTrue(error.localizedDescription.contains("401"))
        }
        let requests = await api.requests
        XCTAssertEqual(requests.count, 1, "Never retry a billable generation automatically")
    }

    func testCancelledGenerationPropagatesAndDoesNotDownload() async throws {
        let api = RecordingTransport([.failure(URLError(.cancelled))])
        let downloads = RecordingTransport([])
        do {
            _ = try await ImageAPIClient(apiTransport: api, downloadTransport: downloads)
                .generate(prompt: "cat", configuration: configuration(), size: "")
            XCTFail("Expected cancellation")
        } catch let error as URLError { XCTAssertEqual(error.code, .cancelled) }
        let requests = await downloads.requests
        XCTAssertTrue(requests.isEmpty)
    }

    func testModelsCanBeReadBeforeChoosingModelAndAreDeduplicated() async throws {
        var settings = configuration()
        settings.model = ""
        let api = RecordingTransport([.response(try json([
            "data": [["id": "image-b"], ["id": "image-a"], ["id": "image-b"]]
        ]), 200)])
        let models = try await ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
            .fetchModels(configuration: settings)
        XCTAssertEqual(models, ["image-a", "image-b"])
        let requests = await api.requests
        XCTAssertEqual(requests.first?.url?.absoluteString, "https://api.rinko.ai/v1/models")
        XCTAssertEqual(requests.first?.httpMethod, "GET")
    }

    func testRejectsUnsafeConfigurationBeforeAnyNetworkRequest() async throws {
        let api = RecordingTransport([])
        let client = ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
        var settings = configuration()
        settings.endpoint = "http://example.com/v1/images/generations"
        do {
            _ = try await client.generate(prompt: "cat", configuration: settings, size: "")
            XCTFail("Expected HTTPS validation")
        } catch { XCTAssertTrue(error.localizedDescription.contains("HTTPS")) }
        settings = configuration()
        settings.extraBody = "{\"n\":10}"
        do {
            _ = try await client.generate(prompt: "cat", configuration: settings, size: "")
            XCTFail("Expected reserved parameter validation")
        } catch { XCTAssertTrue(error.localizedDescription.contains("冲突")) }
        settings = configuration()
        settings.modelsEndpoint = "https://unrelated.example.com/v1/models"
        do {
            _ = try await client.fetchModels(configuration: settings)
            XCTFail("Expected same-origin validation")
        } catch { XCTAssertTrue(error.localizedDescription.contains("相同域名")) }
        let requests = await api.requests
        XCTAssertTrue(requests.isEmpty)
    }

    func testRejectsAsyncTaskAndEmptyImageResponse() async throws {
        for response in [["task_id": "123"], ["data": []]] as [[String: Any]] {
            let api = RecordingTransport([.response(try json(response), 200)])
            do {
                _ = try await ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
                    .generate(prompt: "cat", configuration: configuration(), size: "")
                XCTFail("Expected an incompatible-response error")
            } catch {
                XCTAssertTrue(error is AppError)
            }
        }
    }

    func testRejectsUntrustedDownloadURLAndInvalidBase64() async throws {
        for response in [
            ["data": [["url": "http://cdn.example.com/image.png"]]],
            ["data": [["b64_json": "not-valid-base64!"]]]
        ] as [[String: Any]] {
            let api = RecordingTransport([.response(try json(response), 200)])
            let downloads = RecordingTransport([])
            do {
                _ = try await ImageAPIClient(apiTransport: api, downloadTransport: downloads)
                    .generate(prompt: "cat", configuration: configuration(), size: "")
                XCTFail("Expected invalid image source")
            } catch { XCTAssertTrue(error is AppError) }
            let requests = await downloads.requests
            XCTAssertTrue(requests.isEmpty)
        }
    }

    func testPNGExportContainsActualPNGBytes() throws {
        let image = try XCTUnwrap(UIImage(data: tinyPNG))
        let png = try XCTUnwrap(image.pngData())
        let document = PNGDocument(data: png)
        XCTAssertEqual(document.data.prefix(8), Data([137, 80, 78, 71, 13, 10, 26, 10]))
        XCTAssertNotNil(UIImage(data: document.data))
    }

    func testChatStreamReassemblesSplitImageAndDoesNotRetryWhenSensitivityOff() async throws {
        var settings = APIConfiguration.preset(.rinko)
        settings.apiKey = "test-secret"; settings.model = "nai-diffusion-5-full"
        let text = "![result](data:image/png;base64," + tinyPNG.base64EncodedString() + ")"
        let fragments = [String(text.prefix(29)), String(text.dropFirst(29).prefix(30)), String(text.dropFirst(59))]
        var stream = ": keepalive\r\n\r\n"
        for fragment in fragments {
            let event = try json(["choices": [["index": 0, "delta": ["content": fragment]]]])
            stream += "data: " + String(decoding: event, as: UTF8.self) + "\r\n\r\n"
        }
        stream += "data: [DONE]\r\n\r\n"
        let api = RecordingTransport([.response(Data(stream.utf8), 200)])
        let result = try await ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
            .generate(prompt: "cat", configuration: settings, size: "auto", sensitivity: .off)
        XCTAssertEqual(result.data, tinyPNG)
        let requests = await api.requests
        XCTAssertEqual(requests.count, 1)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(requests.first?.httpBody)) as? [String: Any])
        XCTAssertNil(body["moderation"])
        XCTAssertEqual(body["stream"] as? Bool, false)
    }

    func testHeartbeatAndBOMPrefixedJSONAndDirectImage() async throws {
        let jsonData = try json(["data": [["b64_json": tinyPNG.base64EncodedString()]]])
        for data in [Data("\u{feff}: keepalive\n\n".utf8) + jsonData, tinyPNG] {
            let api = RecordingTransport([.response(data, 200)])
            let result = try await ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
                .generate(prompt: "cat", configuration: configuration(), size: "auto")
            XCTAssertEqual(result.data, tinyPNG)
        }
    }

    func testStreamFinalMessageAndStructuredDeltaImage() async throws {
        var settings = APIConfiguration.preset(.rinko); settings.apiKey = "test-secret"
        settings.model = "nai-diffusion-5-full"
        let image = ["image_url": ["url": "data:image/png;base64," + tinyPNG.base64EncodedString()]]
        for event in [
            ["choices": [["message": ["images": [image]]]]],
            ["choices": [["delta": ["images": [image]]]]]
        ] as [[String: Any]] {
            let stream = "data: " + String(decoding: try json(event), as: UTF8.self) + "\n\ndata: [DONE]\n\n"
            let api = RecordingTransport([.response(Data(stream.utf8), 200)])
            let result = try await ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
                .generate(prompt: "cat", configuration: settings, size: "auto")
            XCTAssertEqual(result.data, tinyPNG)
        }
    }

    func testHTMLAndIncompleteStreamExplainFailureWithoutLeakingResponseOrRetrying() async throws {
        for text in ["<html>test-secret private body</html>", "data: {bad\n\n", "data: [DONE]\n\n"] {
            let api = RecordingTransport([.response(Data(text.utf8), 200)])
            do {
                _ = try await ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
                    .generate(prompt: "cat", configuration: configuration(), size: "auto")
                XCTFail("Expected invalid response")
            } catch {
                XCTAssertFalse(error.localizedDescription.contains("test-secret"))
                XCTAssertTrue(error.localizedDescription.contains("请求已提交"))
                if text.hasPrefix("<") { XCTAssertTrue(error.localizedDescription.contains("HTTP 200")) }
            }
            let requests = await api.requests; XCTAssertEqual(requests.count, 1)
        }
    }

    func testStreamProviderErrorIsRedacted() async throws {
        let event = try json(["error": ["message": "invalid model test-secret"]])
        let api = RecordingTransport([.response(Data("data: ".utf8) + event + Data("\n\n".utf8), 200)])
        do {
            _ = try await ImageAPIClient(apiTransport: api, downloadTransport: RecordingTransport([]))
                .generate(prompt: "cat", configuration: configuration(), size: "auto")
            XCTFail("Expected provider error")
        } catch {
            XCTAssertTrue(error.localizedDescription.contains("invalid model"))
            XCTAssertFalse(error.localizedDescription.contains("test-secret"))
        }
    }
}
