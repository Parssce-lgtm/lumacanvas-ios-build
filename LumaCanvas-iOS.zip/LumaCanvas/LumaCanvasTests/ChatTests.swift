import XCTest
@testable import LumaCanvas

private struct ChatMockTransport: ImageTransport {
    var status = 200
    var text = "你好"
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        let data = try JSONSerialization.data(withJSONObject: ["choices": [["message": ["content": text]]]])
        return (data, HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil, headerFields: nil)!)
    }
}

final class ChatTests: XCTestCase {
    private var configuration: APIConfiguration {
        var value = APIConfiguration()
        value.site = "https://example.com/gateway/v1"
        value.endpoint = "https://example.com/gateway/v1/images/generations"
        value.apiKey = "fixture-not-a-key"
        value.model = "image-only"
        value.conversationModel = "chat-only"
        return value
    }
    func testChatConfigurationMigratesAndRoundTripsSeparatelyFromImageModel() throws {
        let legacy = try JSONDecoder().decode(APIConfiguration.self, from: Data("{\"model\":\"legacy-image\"}".utf8))
        XCTAssertEqual(legacy.conversationModel, "")
        var value = configuration
        value.conversationEndpoint = "https://chat.example.com/v1/chat/completions"
        let decoded = try JSONDecoder().decode(APIConfiguration.self, from: JSONEncoder().encode(value))
        XCTAssertEqual(decoded.conversationModel, "chat-only")
        XCTAssertEqual(decoded.model, "image-only")
        XCTAssertEqual(try decoded.conversationURL().host, "chat.example.com")
    }
    func testEndpointPreservesGatewayPrefixAndAvoidsDuplicateV1() throws {
        XCTAssertEqual(try configuration.conversationURL().absoluteString, "https://example.com/gateway/v1/chat/completions")
        var value = configuration
        value.site = ""; value.endpoint = "https://example.com/proxy/v1/chat/completions"
        XCTAssertEqual(try value.conversationURL().absoluteString, value.endpoint)
    }
    func testRequestHasChatModelAndContextWithoutImageParameters() throws {
        let request = try ChatAPIClient.request(configuration: configuration,
            messages: [ChatMessage(role: "user", text: "你好"), ChatMessage(role: "assistant", text: "你好！"), ChatMessage(role: "user", text: "继续")], adultMode: false)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: try XCTUnwrap(request.httpBody)) as? [String: Any])
        XCTAssertEqual(body["model"] as? String, "chat-only")
        XCTAssertEqual(body["stream"] as? Bool, false)
        XCTAssertNil(body["size"]); XCTAssertNil(body["moderation"]); XCTAssertNil(body["prompt"])
        let messages = try XCTUnwrap(body["messages"] as? [[String: String]])
        XCTAssertEqual(messages.map { $0["role"]! }, ["system", "user", "assistant", "user"])
        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer fixture-not-a-key")
    }
    func testAdultModeDefaultsOffAndDoesNotAskProviderToBypassRules() throws {
        let ordinary = try ChatAPIClient.request(configuration: configuration, messages: [ChatMessage(role: "user", text: "关系")], adultMode: false)
        let mature = try ChatAPIClient.request(configuration: configuration, messages: [ChatMessage(role: "user", text: "关系")], adultMode: true)
        XCTAssertTrue(String(decoding: ordinary.httpBody!, as: UTF8.self).contains("一般读者"))
        XCTAssertTrue(String(decoding: mature.httpBody!, as: UTF8.self).contains("用户已确认成年"))
        XCTAssertTrue(String(decoding: mature.httpBody!, as: UTF8.self).contains("不把用户确认视为绕过安全规则的授权"))
    }
    func testReadsTextPartsRefusalAndRejectsEmptyReply() throws {
        for (content, expected) in [(["content": "你好"], "你好"), (["content": [["type": "text", "text": "第一段"], ["type": "text", "text": "第二段"]]], "第一段\n第二段"), (["refusal": "无法回复此内容"], "无法回复此内容")] as [([String: Any], String)] {
            let data = try JSONSerialization.data(withJSONObject: ["choices": [["message": content]]])
            XCTAssertEqual(try ChatAPIClient.responseText(data), expected)
        }
        XCTAssertThrowsError(try ChatAPIClient.responseText(Data()))
        XCTAssertThrowsError(try ChatAPIClient.responseText(Data("<html></html>".utf8)))
        XCTAssertThrowsError(try ChatAPIClient.responseText(Data("{\"choices\":[]}".utf8)))
    }
    func testServerErrorsAreNotSuccessfulChatReplies() async throws {
        let client = ChatAPIClient(transport: ChatMockTransport(status: 404))
        do {
            _ = try await client.reply(configuration: configuration, messages: [ChatMessage(role: "user", text: "你好")], adultMode: false)
            XCTFail("404 must fail")
        } catch { XCTAssertTrue(error.localizedDescription.contains("404")) }
    }
    @MainActor private func finish(_ store: ChatViewModel) async throws {
        for _ in 0..<100 {
            if store.sendingInstance == nil { return }
            try await Task.sleep(nanoseconds: 20_000_000)
        }
        XCTFail("Mock chat did not finish")
    }
    @MainActor func testSavedHistoryRestoresMessagesAndResetsConsent() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = ChatViewModel(directory: directory), value = configuration
        store.setAdultMode(true, for: value.id)
        store.send("需要保存的对话", configuration: value, client: ChatAPIClient(transport: ChatMockTransport()))
        try await finish(store)
        let restored = ChatViewModel(directory: directory)
        XCTAssertEqual(restored.records(for: value.id).count, 1)
        XCTAssertEqual(restored.conversation(for: value.id).messages, store.conversation(for: value.id).messages)
        XCTAssertFalse(restored.conversation(for: value.id).adultMode)
        XCTAssertNil(restored.storageError)
    }
    @MainActor func testTemporaryMessagesDoNotChangeArchiveAndExitRestoresNormalChat() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = ChatViewModel(directory: directory), value = configuration
        let client = ChatAPIClient(transport: ChatMockTransport())
        store.send("普通对话", configuration: value, client: client); try await finish(store)
        let archive = directory.appendingPathComponent("history.json")
        let saved = try Data(contentsOf: archive)
        store.newConversation(for: value.id, temporary: true)
        store.send("临时秘密", configuration: value, client: client); try await finish(store)
        XCTAssertEqual(try Data(contentsOf: archive), saved)
        XCTAssertFalse(ChatViewModel(directory: directory).records(for: value.id).flatMap(\.messages).contains { $0.text == "临时秘密" })
        store.endTemporary(for: value.id)
        XCTAssertFalse(store.conversation(for: value.id).temporary)
        XCTAssertEqual(store.conversation(for: value.id).messages.first?.text, "普通对话")
    }
    @MainActor func testFailedMessageRetryDoesNotDuplicateUserMessage() async throws {
        let store = ChatViewModel(directory: FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString))
        let value = configuration
        store.send("重试消息", configuration: value, client: ChatAPIClient(transport: ChatMockTransport(status: 404)))
        try await finish(store)
        let message = try XCTUnwrap(store.conversation(for: value.id).messages.last)
        XCTAssertNotNil(store.conversation(for: value.id).error)
        store.retry(message.id, configuration: value, client: ChatAPIClient(transport: ChatMockTransport()))
        try await finish(store)
        XCTAssertEqual(store.conversation(for: value.id).messages.map(\.role), ["user", "assistant"])
        XCTAssertEqual(store.conversation(for: value.id).messages.first?.id, message.id)
        XCTAssertEqual(store.records(for: value.id).count, 1)
    }
    @MainActor func testRegenerationPreservesOriginalReplyAsHistoryBranch() async throws {
        let store = ChatViewModel(directory: FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString))
        let value = configuration
        store.send("同一个问题", configuration: value, client: ChatAPIClient(transport: ChatMockTransport(text: "原回复")))
        try await finish(store)
        let original = store.conversation(for: value.id)
        store.retry(try XCTUnwrap(original.messages.last).id, configuration: value, client: ChatAPIClient(transport: ChatMockTransport(text: "新回复")))
        try await finish(store)
        XCTAssertEqual(store.records(for: value.id).count, 2)
        XCTAssertEqual(store.records(for: value.id).first { $0.id == original.id }?.messages.last?.text, "原回复")
        XCTAssertEqual(store.conversation(for: value.id).messages.map(\.role), ["user", "assistant"])
        XCTAssertEqual(store.conversation(for: value.id).messages.last?.text, "新回复")
    }
    @MainActor func testEditingEarlierMessageCreatesBranchWithoutChangingOriginal() async throws {
        let store = ChatViewModel(directory: FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString))
        let value = configuration, client = ChatAPIClient(transport: ChatMockTransport())
        store.send("原问题", configuration: value, client: client); try await finish(store)
        store.send("后续问题", configuration: value, client: client); try await finish(store)
        let original = store.conversation(for: value.id)
        store.editAndSend(try XCTUnwrap(original.messages.first).id, text: "编辑后的问题", configuration: value, client: client)
        try await finish(store)
        XCTAssertEqual(store.records(for: value.id).first { $0.id == original.id }?.messages.count, 4)
        XCTAssertEqual(store.conversation(for: value.id).messages.count, 2)
        XCTAssertEqual(store.conversation(for: value.id).messages.first?.text, "编辑后的问题")
    }
    @MainActor func testConversationConsentIsPerInstanceAndResetByNewChat() {
        let store = ChatViewModel(directory: FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString))
        let first = UUID(), second = UUID()
        XCTAssertFalse(store.conversation(for: first).adultMode)
        store.setAdultMode(true, for: first)
        XCTAssertTrue(store.conversation(for: first).adultMode)
        XCTAssertFalse(store.conversation(for: second).adultMode)
        store.newConversation(for: first)
        XCTAssertFalse(store.conversation(for: first).adultMode)
    }
    @MainActor func testReplyAppendsAndDoesNotMixInstances() async throws {
        let store = ChatViewModel(directory: FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)), configuration = self.configuration
        store.send("你好", configuration: configuration, client: ChatAPIClient(transport: ChatMockTransport()))
        for _ in 0..<30 {
            if store.sendingInstance == nil { break }
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTAssertNil(store.sendingInstance)
        XCTAssertEqual(store.conversation(for: configuration.id).messages.map(\.role), ["user", "assistant"])
        XCTAssertEqual(store.conversation(for: configuration.id).messages.last?.text, "你好")
        XCTAssertTrue(store.conversation(for: UUID()).messages.isEmpty)
    }
}

