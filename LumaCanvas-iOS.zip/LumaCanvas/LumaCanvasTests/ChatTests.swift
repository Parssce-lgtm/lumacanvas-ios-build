import XCTest
@testable import LumaCanvas

private struct ChatMockTransport: ImageTransport {
    var status = 200
    var text = "你好"
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        let data = try JSONSerialization.data(withJSONObject: ["choices": [["message": ["content": text]]]])
        return (data, HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil, headerFields: nil)!)
    }
}

final class ChatTests: XCTestCase {
    private var configuration: APIConfiguration {
        var value = APIConfiguration()
        value.site = "https://example.com/gateway/v1"
        value.endpoint = "https://example.com/gateway/v1/images/generations"
        value.apiKey = "fixture-not-a-key"
        value.model = "image-only"
        value.conversationModel = "chat-only"
        return value
    }
    func testChatConfigurationMigratesAndRoundTripsSeparatelyFromImageModel() throws {
        let legacy = try JSONDecoder().decode(APIConfiguration.self, from: Data("{\"model\":\"legacy-image\"}".utf8))
        XCTAssertEqual(legacy.conversationModel, "")
        var value = configuration
        value.conversationEndpoint = "https://chat.example.com/v1/chat/completions"
        let decoded = try JSONDecoder().decode(APIConfiguration.self, from: JSONEncoder().encode(value))
        XCTAssertEqual(decoded.conversationModel, "chat-only")
        XCTAssertEqual(decoded.model, "image-only")
        XCTAssertEqual(try decoded.conversationURL().host, "chat.example.com")
    }
    func testEndpointPreservesGatewayPrefixAndAvoidsDuplicateV1() throws {
        XCTAssertEqual(try configuration.conversationURL().absoluteString, "https://example.com/gateway/v1/chat/completions")
        var value = configuration
        value.site = ""; value.endpoint = "https://example.com/proxy/v1/chat/completions"
        XCTAssertEqual(try value.conversationURL().absoluteString, value.endpoint)
    }
    func testRequestHasChatModelAndContextWithoutImageParameters() throws {
        let request = try ChatAPIClient.request(configuration: configuration,
            messages: [ChatMessage(role: "user", text: "你好"), ChatMessage(role: "assistant", text: "你好！"), ChatMessage(role: "user", text: "继续")], adultMode: false)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: try XCTUnwrap(request.httpBody)) as? [String: Any])
        XCTAssertEqual(body["model"] as? String, "chat-only")
        XCTAssertEqual(body["stream"] as? Bool, false)
        XCTAssertNil(body["size"]); XCTAssertNil(body["moderation"]); XCTAssertNil(body["prompt"])
        let messages = try XCTUnwrap(body["messages"] as? [[String: String]])
        XCTAssertEqual(messages.map { $0["role"]! }, ["system", "user", "assistant", "user"])
        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer fixture-not-a-key")
    }
    func testAdultModeDefaultsOffAndDoesNotAskProviderToBypassRules() throws {
        let ordinary = try ChatAPIClient.request(configuration: configuration, messages: [ChatMessage(role: "user", text: "关系")], adultMode: false)
        let mature = try ChatAPIClient.request(configuration: configuration, messages: [ChatMessage(role: "user", text: "关系")], adultMode: true)
        XCTAssertTrue(String(decoding: ordinary.httpBody!, as: UTF8.self).contains("一般读者"))
        XCTAssertTrue(String(decoding: mature.httpBody!, as: UTF8.self).contains("用户已确认成年"))
        XCTAssertTrue(String(decoding: mature.httpBody!, as: UTF8.self).contains("不把用户确认视为绕过安全规则的授权"))
    }
    func testReadsTextPartsRefusalAndRejectsEmptyReply() throws {
        for (content, expected) in [(["content": "你好"], "你好"), (["content": [["type": "text", "text": "第一段"], ["type": "text", "text": "第二段"]]], "第一段\n第二段"), (["refusal": "无法回复此内容"], "无法回复此内容")] as [([String: Any], String)] {
            let data = try JSONSerialization.data(withJSONObject: ["choices": [["message": content]]])
            XCTAssertEqual(try ChatAPIClient.responseText(data), expected)
        }
        XCTAssertThrowsError(try ChatAPIClient.responseText(Data()))
        XCTAssertThrowsError(try ChatAPIClient.responseText(Data("<html></html>".utf8)))
        XCTAssertThrowsError(try ChatAPIClient.responseText(Data("{\"choices\":[]}".utf8)))
    }
    func testServerErrorsAreNotSuccessfulChatReplies() async throws {
        let client = ChatAPIClient(transport: ChatMockTransport(status: 404))
        do {
            _ = try await client.reply(configuration: configuration, messages: [ChatMessage(role: "user", text: "你好")], adultMode: false)
            XCTFail("404 must fail")
        } catch { XCTAssertTrue(error.localizedDescription.contains("404")) }
    }
    @MainActor private func finish(_ store: ChatViewModel) async throws {
        for _ in 0..<100 {
            if store.sendingInstance == nil { return }
            try await Task.sleep(nanoseconds: 20_000_000)
        }
        XCTFail("Mock chat did not finish")
    }
    @MainActor func testSavedHistoryRestoresMessagesAndResetsConsent() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = ChatViewModel(directory: directory), value = configuration
        store.setAdultMode(true, for: value.id)
        store.send("需要保存的对话", configuration: value, client: ChatAPIClient(transport: ChatMockTransport()))
        try await finish(store)
        let restored = ChatViewModel(directory: directory)
        XCTAssertEqual(restored.records(for: value.id).count, 1)
        XCTAssertEqual(restored.conversation(for: value.id).messages, store.conversation(for: value.id).messages)
        XCTAssertFalse(restored.conversation(for: value.id).adultMode)
        XCTAssertNil(restored.storageError)
    }
    @MainActor func testTemporaryMessagesDoNotChangeArchiveAndExitRestoresNormalChat() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = ChatViewModel(directory: directory), value = configuration
        let client = ChatAPIClient(transport: ChatMockTransport())
        store.send("普通对话", configuration: value, client: client); try await finish(store)
        let archive = directory.appendingPathComponent("history.json")
        let saved = try Data(contentsOf: archive)
        store.newConversation(for: value.id, temporary: true)
        store.send("临时秘密", configuration: value, client: client); try await finish(store)
        XCTAssertEqual(try Data(contentsOf: archive), saved)
        XCTAssertFalse(ChatViewModel(directory: directory).records(for: value.id).flatMap(\.messages).contains { $0.text == "临时秘密" })
        store.endTemporary(for: value.id)
        XCTAssertFalse(store.conversation(for: value.id).temporary)
        XCTAssertEqual(store.conversation(for: value.id).messages.first?.text, "普通对话")
    }
    @MainActor func testFailedMessageRetryDoesNotDuplicateUserMessage() async throws {
        let store = ChatViewModel(directory: FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString))
        let value = configuration
        store.send("重试消息", configuration: value, client: ChatAPIClient(transport: ChatMockTransport(status: 404)))
        try await finish(store)
        let message = try XCTUnwrap(store.conversation(for: value.id).messages.last)
        XCTAssertNotNil(store.conversation(for: value.id).error)
        store.retry(message.id, configuration: value, client: ChatAPIClient(transport: ChatMockTransport()))
        try await finish(store)
        XCTAssertEqual(store.conversation(for: value.id).messages.map(\.role), ["user", "assistant"])
        XCTAssertEqual(store.conversation(for: value.id).messages.first?.id, message.id)
        XCTAssertEqual(store.records(for: value.id).count, 1)
    }
    @MainActor func testRegenerationPreservesOriginalReplyAsHistoryBranch() async throws {
        let store = ChatViewModel(directory: FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString))
        let value = configuration
        store.send("同一个问题", configuration: value, client: ChatAPIClient(transport: ChatMockTransport(text: "原回复")))
        try await finish(store)
        let original = store.conversation(for: value.id)
        store.retry(try XCTUnwrap(original.messages.last).id, configuration: value, client: ChatAPIClient(transport: ChatMockTransport(text: "新回复")))
        try await finish(store)
        XCTAssertEqual(store.records(for: value.id).count, 2)
        XCTAssertEqual(store.records(for: value.id).first { $0.id == original.id }?.messages.last?.text, "原回复")
        XCTAssertEqual(store.conversation(for: value.id).messages.map(\.role), ["user", "assistant"])
        XCTAssertEqual(store.conversation(for: value.id).messages.last?.text, "新回复")
    }
    @MainActor func testEditingEarlierMessageCreatesBranchWithoutChangingOriginal() async throws {
        let store = ChatViewModel(directory: FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString))
        let value = configuration, client = ChatAPIClient(transport: ChatMockTransport())
        store.send("原问题", configuration: value, client: client); try await finish(store)
        store.send("后续问题", configuration: value, client: client); try await finish(store)
        let original = store.conversation(for: value.id)
        store.editAndSend(try XCTUnwrap(original.messages.first).id, text: "编辑后的问题", configuration: value, client: client)
        try await finish(store)
        XCTAssertEqual(store.records(for: value.id).first { $0.id == original.id }?.messages.count, 4)
        XCTAssertEqual(store.conversation(for: value.id).messages.count, 2)
        XCTAssertEqual(store.conversation(for: value.id).messages.first?.text, "编辑后的问题")
    }
    @MainActor func testConversationConsentIsPerInstanceAndResetByNewChat() {
        let store = ChatViewModel(directory: FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString))
        let first = UUID(), second = UUID()
        XCTAssertFalse(store.conversation(for: first).adultMode)
        store.setAdultMode(true, for: first)
        XCTAssertTrue(store.conversation(for: first).adultMode)
        XCTAssertFalse(store.conversation(for: second).adultMode)
        store.newConversation(for: first)
        XCTAssertFalse(store.conversation(for: first).adultMode)
    }
    @MainActor func testReplyAppendsAndDoesNotMixInstances() async throws {
        let store = ChatViewModel(directory: FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)), configuration = self.configuration
        store.send("你好", configuration: configuration, client: ChatAPIClient(transport: ChatMockTransport()))
        for _ in 0..<30 {
            if store.sendingInstance == nil { break }
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTAssertNil(store.sendingInstance)
        XCTAssertEqual(store.conversation(for: configuration.id).messages.map(\.role), ["user", "assistant"])
        XCTAssertEqual(store.conversation(for: configuration.id).messages.last?.text, "你好")
        XCTAssertTrue(store.conversation(for: UUID()).messages.isEmpty)
    }
    func testMarkdownAndGeneratedDocumentsAreReadableAndBounded() throws {
        let formatted = ChatFormatting.attributed("# 标题\n**加粗**\n- 条目")
        XCTAssertEqual(formatted.string, "标题\n加粗\n• 条目")
        let result = ChatDocuments.extract("下载文件\n```file:说明.txt\n正文\n```\n```file:说明.pdf\n# 标题\n正文\n```")
        XCTAssertEqual(result.1.count, 2)
        XCTAssertEqual(String(data: result.1[0].data, encoding: .utf8), "正文")
        XCTAssertTrue(result.1[1].data.starts(with: Data("%PDF-".utf8)))
        XCTAssertFalse(result.0.contains("```file:"))
        XCTAssertTrue(ChatDocuments.extract("```file:未完成.txt\n未完成").1.isEmpty)
        XCTAssertTrue(ChatDocuments.extract("```file:程序.exe\ncode\n```").1.isEmpty)
        XCTAssertFalse(ChatDocuments.make(text: "text", name: "../../safe.txt").name.contains("/"))
    }
    @MainActor func testHistoryRenamePinDeletePersistsAndLegacyRecordsMigrate() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let store = ChatViewModel(directory: directory), value = configuration
        XCTAssertTrue(store.send("第一条", configuration: value, client: ChatAPIClient(transport: ChatMockTransport())))
        store.stop()
        let first = store.conversation(for: value.id).id
        store.newConversation(for: value.id)
        XCTAssertTrue(store.send("第二条", configuration: value, client: ChatAPIClient(transport: ChatMockTransport())))
        store.stop()
        store.rename(first, title: "重命名"); store.togglePin(first)
        let restored = ChatViewModel(directory: directory)
        XCTAssertEqual(restored.records(for: value.id).first?.id, first)
        XCTAssertEqual(restored.records(for: value.id).first?.title, "重命名")
        restored.delete(first)
        XCTAssertEqual(ChatViewModel(directory: directory).records(for: value.id).count, 1)
        var legacy = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(store.records(for: value.id)[0])) as? [String: Any])
        legacy.removeValue(forKey: "pinned"); legacy.removeValue(forKey: "customTitle")
        XCTAssertFalse(try JSONDecoder().decode(ChatConversation.self, from: JSONSerialization.data(withJSONObject: legacy)).pinned)
    }
    func testRatiosAndNetworkPolicyAllowDirectCellularConnections() {
        XCTAssertEqual(ArtworkRatio.wide.title(landscape: false), "9:16")
        XCTAssertEqual(ArtworkRatio.book.title(landscape: true), "7:5")
        XCTAssertEqual(ArtworkRatio.photo.size(landscape: true), "1536x1024")
        XCTAssertEqual(ArtworkRatio.allCases[1], .wallpaper)
        let session = URLSessionConfiguration.ephemeral
        NetworkAccess.configure(session)
        XCTAssertTrue(session.allowsCellularAccess)
        XCTAssertTrue(session.allowsConstrainedNetworkAccess)
        XCTAssertTrue(session.allowsExpensiveNetworkAccess)
    }
    func testLegacyMessagesDecodeWithoutAttachmentsAndMixedPartsUseCorrectFormat() throws {
        let old = "{\"id\":\"\(UUID().uuidString)\",\"role\":\"user\",\"text\":\"旧消息\"}"
        XCTAssertTrue(try JSONDecoder().decode(ChatMessage.self, from: Data(old.utf8)).attachments.isEmpty)
        let files = [ChatAttachment(name: "photo.jpg", mimeType: "image/jpeg", data: Data([1,2,3])),
                     ChatAttachment(name: "document.pdf", mimeType: "application/pdf", data: Data("%PDF-1.7".utf8)),
                     ChatAttachment(name: "notes.txt", mimeType: "text/plain", data: Data("附件内容".utf8))]
        let request = try ChatAPIClient.request(configuration: configuration,
            messages: [ChatMessage(role: "user", text: "查看附件", attachments: files)], adultMode: false)
        let root = try XCTUnwrap(JSONSerialization.jsonObject(with: request.httpBody!) as? [String: Any])
        let context = try XCTUnwrap(root["messages"] as? [[String: Any]])
        let parts = try XCTUnwrap(context.last?["content"] as? [[String: Any]])
        XCTAssertEqual(parts.compactMap { $0["type"] as? String }, ["text", "image_url", "file", "text"])
        XCTAssertEqual((parts[2]["file"] as? [String: String])?["filename"], "document.pdf")
        XCTAssertTrue((parts.last?["text"] as? String)?.contains("附件内容") == true)
    }
    @MainActor func testAttachmentOnlySendAndRestoreRetainsPayload() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = ChatViewModel(directory: directory), value = configuration
        let file = ChatAttachment(name: "test.txt", mimeType: "text/plain", data: Data("hello".utf8))
        XCTAssertTrue(store.send("", attachments: [file], configuration: value, client: ChatAPIClient(transport: ChatMockTransport())))
        try await finish(store)
        let restored = ChatViewModel(directory: directory)
        XCTAssertEqual(restored.conversation(for: value.id).messages.first?.attachments, [file])
        XCTAssertEqual(restored.conversation(for: value.id).title, "test.txt")
        XCTAssertFalse(store.send("", attachments: [ChatAttachment(name: "empty", mimeType: "text/plain", data: Data())], configuration: value))
    }
    @MainActor func testModelTestSnapshotAndIndependentJobsAreNotCancelledByConfigurationChanges() async throws {
        let store = ModelTestStore()
        var first = configuration, second = configuration
        second.id = UUID(); second.model = "second-model"
        let transport = SlowProbeTransport()
        let client = ImageAPIClient(apiTransport: transport, downloadTransport: transport)
        store.start(first, client: client); store.start(second, client: client)
        first.model = "changed-after-start"
        store.start(first, client: client) // A second tap never replaces an active request.
        XCTAssertEqual(store.records[first.id]?.configuration.model, "image-only")
        store.cancel(second.id)
        for _ in 0..<100 {
            if store.records[first.id]?.running == false { break }
            try await Task.sleep(nanoseconds: 20_000_000)
        }
        XCTAssertEqual(store.records[first.id]?.result?.status, .available)
        XCTAssertEqual(store.records[second.id]?.result?.status, .unavailable)
        XCTAssertFalse(store.records[first.id]?.running ?? true)
    }

}


private struct SlowProbeTransport: ImageTransport {
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        try await Task.sleep(nanoseconds: 200_000_000)
        let data = Data("{\"data\":[{\"b64_json\":\"iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg==\"}]}".utf8)
        return (data, HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!)
    }
}
