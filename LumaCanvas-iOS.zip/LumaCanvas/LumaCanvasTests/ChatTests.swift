import XCTest
@testable import LumaCanvas

private struct ChatMockTransport: ImageTransport {
    var status = 200
    var text = "你好"
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        let data = try JSONSerialization.data(withJSONObject: ["choices": [["message": ["content": text]]]])
        return (data, HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil, headerFields: nil)!)
    }
}

final class ChatTests: XCTestCase {
    private var configuration: APIConfiguration {
        var value = APIConfiguration()
        value.site = "https://example.com/gateway/v1"
        value.endpoint = "https://example.com/gateway/v1/images/generations"
        value.apiKey = "fixture-not-a-key"
        value.model = "image-only"
        value.conversationModel = "chat-only"
        return value
    }
    func testChatConfigurationMigratesAndRoundTripsSeparatelyFromImageModel() throws {
        let legacy = try JSONDecoder().decode(APIConfiguration.self, from: Data("{\"model\":\"legacy-image\"}".utf8))
        XCTAssertEqual(legacy.conversationModel, "")
        var value = configuration
        value.conversationEndpoint = "https://chat.example.com/v1/chat/completions"
        let decoded = try JSONDecoder().decode(APIConfiguration.self, from: JSONEncoder().encode(value))
        XCTAssertEqual(decoded.conversationModel, "chat-only")
        XCTAssertEqual(decoded.model, "image-only")
        XCTAssertEqual(try decoded.conversationURL().host, "chat.example.com")
    }
    func testEndpointPreservesGatewayPrefixAndAvoidsDuplicateV1() throws {
        XCTAssertEqual(try configuration.conversationURL().absoluteString, "https://example.com/gateway/v1/chat/completions")
        var value = configuration
        value.site = ""; value.endpoint = "https://example.com/proxy/v1/chat/completions"
        XCTAssertEqual(try value.conversationURL().absoluteString, value.endpoint)
    }
    func testRequestHasChatModelAndContextWithoutImageParameters() throws {
        let request = try ChatAPIClient.request(configuration: configuration,
            messages: [ChatMessage(role: "user", text: "你好"), ChatMessage(role: "assistant", text: "你好！"), ChatMessage(role: "user", text: "继续")], adultMode: false)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: try XCTUnwrap(request.httpBody)) as? [String: Any])
        XCTAssertEqual(body["model"] as? String, "chat-only")
        XCTAssertEqual(body["stream"] as? Bool, false)
        XCTAssertNil(body["size"]); XCTAssertNil(body["moderation"]); XCTAssertNil(body["prompt"])
        let messages = try XCTUnwrap(body["messages"] as? [[String: String]])
        XCTAssertEqual(messages.map { $0["role"]! }, ["system", "user", "assistant", "user"])
        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer fixture-not-a-key")
    }
    func testAdultModeDefaultsOffAndDoesNotAskProviderToBypassRules() throws {
        let ordinary = try ChatAPIClient.request(configuration: configuration, messages: [ChatMessage(role: "user", text: "关系")], adultMode: false)
        let mature = try ChatAPIClient.request(configuration: configuration, messages: [ChatMessage(role: "user", text: "关系")], adultMode: true)
        XCTAssertTrue(String(decoding: ordinary.httpBody!, as: UTF8.self).contains("一般读者"))
        XCTAssertTrue(String(decoding: mature.httpBody!, as: UTF8.self).contains("用户已确认成年"))
        XCTAssertTrue(String(decoding: mature.httpBody!, as: UTF8.self).contains("不把用户确认视为绕过安全规则的授权"))
    }
    func testReadsTextPartsRefusalAndRejectsEmptyReply() throws {
        for (content, expected) in [(["content": "你好"], "你好"), (["content": [["type": "text", "text": "第一段"], ["type": "text", "text": "第二段"]]], "第一段\n第二段"), (["refusal": "无法回复此内容"], "无法回复此内容")] as [([String: Any], String)] {
            let data = try JSONSerialization.data(withJSONObject: ["choices": [["message": content]]])
            XCTAssertEqual(try ChatAPIClient.responseText(data), expected)
        }
        XCTAssertThrowsError(try ChatAPIClient.responseText(Data()))
        XCTAssertThrowsError(try ChatAPIClient.responseText(Data("<html></html>".utf8)))
        XCTAssertThrowsError(try ChatAPIClient.responseText(Data("{\"choices\":[]}".utf8)))
    }
    func testServerErrorsAreNotSuccessfulChatReplies() async throws {
        let client = ChatAPIClient(transport: ChatMockTransport(status: 404))
        do {
            _ = try await client.reply(configuration: configuration, messages: [ChatMessage(role: "user", text: "你好")], adultMode: false)
            XCTFail("404 must fail")
        } catch { XCTAssertTrue(error.localizedDescription.contains("404")) }
    }
    @MainActor func testConversationConsentIsPerInstanceAndResetByNewChat() {
        let store = ChatViewModel()
        let first = UUID(), second = UUID()
        XCTAssertFalse(store.conversation(for: first).adultMode)
        store.setAdultMode(true, for: first)
        XCTAssertTrue(store.conversation(for: first).adultMode)
        XCTAssertFalse(store.conversation(for: second).adultMode)
        store.newConversation(for: first)
        XCTAssertFalse(store.conversation(for: first).adultMode)
    }
    @MainActor func testReplyAppendsAndDoesNotMixInstances() async throws {
        let store = ChatViewModel(), configuration = self.configuration
        store.send("你好", configuration: configuration, client: ChatAPIClient(transport: ChatMockTransport()))
        for _ in 0..<30 {
            if store.sendingInstance == nil { break }
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTAssertNil(store.sendingInstance)
        XCTAssertEqual(store.conversation(for: configuration.id).messages.map(\.role), ["user", "assistant"])
        XCTAssertEqual(store.conversation(for: configuration.id).messages.last?.text, "你好")
        XCTAssertTrue(store.conversation(for: UUID()).messages.isEmpty)
    }
}
