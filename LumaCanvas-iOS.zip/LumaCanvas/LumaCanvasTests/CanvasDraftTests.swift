import XCTest
import UIKit
@testable import LumaCanvas

@MainActor final class CanvasDraftTests: XCTestCase {
    private let png = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg==")!

    func testNewConversationClearsPromptReferencesAndDoesNotRestoreOldArtwork() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let suite = "CanvasDraftTests." + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite); try? FileManager.default.removeItem(at: root) }
        let store = ArtworkStore(root: root)
        let artwork = GeneratedArtwork(id: UUID(), pngData: png, prompt: "Old prompt", revisedPrompt: nil,
            model: "fixture", provider: "test", createdAt: Date(), pixelWidth: 1, pixelHeight: 1)
        try await store.save(artwork)
        let model = CanvasViewModel(store: store, defaults: defaults)
        await model.restore()
        XCTAssertEqual(model.prompt, "Old prompt")
        model.addReferences([(png, "Old reference")])
        model.newConversation()
        XCTAssertTrue(model.prompt.isEmpty); XCTAssertTrue(model.references.isEmpty); XCTAssertNil(model.image)
        let restored = CanvasViewModel(store: store, defaults: defaults)
        await restored.restore()
        XCTAssertTrue(restored.prompt.isEmpty); XCTAssertTrue(restored.references.isEmpty); XCTAssertNil(restored.artwork)
        let rows = try await store.list()
        XCTAssertEqual(rows.map(\.id), [artwork.id], "New conversation must preserve generated gallery images")
    }

    func testContinueEditingReplacesReferencesAndKeepsGeneratedPrompt() throws {
        let suite = "CanvasDraftTests." + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let model = CanvasViewModel(defaults: defaults)
        model.addReferences([(png, "Old reference")])
        let old = try XCTUnwrap(model.reference)
        let artwork = GeneratedArtwork(id: UUID(), pngData: png, prompt: "Continue this image", revisedPrompt: nil,
            model: "fixture", provider: "test", createdAt: Date(), pixelWidth: 1, pixelHeight: 1)
        XCTAssertTrue(model.resumeEditing(artwork))
        XCTAssertEqual(model.prompt, artwork.prompt); XCTAssertEqual(model.references.count, 1)
        XCTAssertNotEqual(model.reference?.id, old.id)
        XCTAssertEqual(try ReferenceImageStore.read(model.references), [try ReferenceImageStore.normalizedData(png)])
        model.prompt += " with clouds"
        model.addReferences([(png, "More reference")])
        XCTAssertEqual(model.references.count, 2); XCTAssertTrue(model.prompt.hasSuffix(" with clouds"))
        model.newConversation()
    }

    func testInvalidEditingImageLeavesExistingDraftIntact() {
        let model = CanvasViewModel(persistState: false)
        model.prompt = "Keep this"
        model.addReferences([(png, "Keep reference")])
        let references = model.references
        let invalid = GeneratedArtwork(id: UUID(), pngData: Data("broken".utf8), prompt: "Invalid", revisedPrompt: nil,
            model: "fixture", provider: "test", createdAt: Date(), pixelWidth: 1, pixelHeight: 1)
        XCTAssertFalse(model.resumeEditing(invalid))
        XCTAssertEqual(model.prompt, "Keep this"); XCTAssertEqual(model.references, references)
        model.newConversation()
    }

    func testFasterSwipesProduceStrongerSpring() {
        let slow = DrawerMotion.damping(translation: 80, projected: 95, width: 170)
        let fast = DrawerMotion.damping(translation: 80, projected: 400, width: 170)
        XCTAssertLessThan(fast, slow); XCTAssertGreaterThanOrEqual(fast, 0.5)
    }
}
