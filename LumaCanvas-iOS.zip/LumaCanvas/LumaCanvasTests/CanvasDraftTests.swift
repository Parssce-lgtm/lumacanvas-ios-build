import XCTest
import UIKit
import SwiftUI
@testable import LumaCanvas

@MainActor final class CanvasDraftTests: XCTestCase {
    func testRapidDrawerReversalsKeepFinalPresentation() async throws {
        let state = DrawerPresentation()
        let controller = NativeDrawerContainer.Controller(presentation: state,
            content: AnyView(Text("messages")), sidebar: AnyView(Text("sidebar")),
            dark: false, reduceMotion: false, openAnywhere: true)
        controller.loadViewIfNeeded()
        controller.view.frame = CGRect(x: 0, y: 0, width: 402, height: 874)
        controller.view.layoutIfNeeded()
        // Reverse before any 380 ms transition can complete.
        for index in 0..<40 {
            state.isPresented = index % 2 == 0
            try await Task.sleep(nanoseconds: 8_000_000)
        }
        state.isPresented = false
        try await Task.sleep(nanoseconds: 500_000_000)
        XCTAssertFalse(state.isPresented)
        XCTAssertTrue(controller.sidebar.view.isHidden)
        XCTAssertEqual(controller.main.view.convert(.zero, to: controller.view).x, 0, accuracy: 0.5)
        state.isPresented = true
        try await Task.sleep(nanoseconds: 500_000_000)
        XCTAssertFalse(controller.sidebar.view.isHidden)
        XCTAssertEqual(controller.main.view.convert(.zero, to: controller.view).x, 301.5, accuracy: 0.5)
    }

    private let png = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg==")!

    func testNewConversationClearsPromptReferencesAndDoesNotRestoreOldArtwork() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let suite = "CanvasDraftTests." + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite); try? FileManager.default.removeItem(at: root) }
        let store = ArtworkStore(root: root)
        let artwork = GeneratedArtwork(id: UUID(), pngData: png, prompt: "Old prompt", revisedPrompt: nil,
            model: "fixture", provider: "test", createdAt: Date(), pixelWidth: 1, pixelHeight: 1)
        try await store.save(artwork)
        let model = CanvasViewModel(store: store, defaults: defaults)
        await model.restore()
        XCTAssertEqual(model.prompt, "Old prompt")
        model.addReferences([(png, "Old reference")])
        model.newConversation()
        XCTAssertTrue(model.prompt.isEmpty); XCTAssertTrue(model.references.isEmpty); XCTAssertNil(model.image)
        let restored = CanvasViewModel(store: store, defaults: defaults)
        await restored.restore()
        XCTAssertTrue(restored.prompt.isEmpty); XCTAssertTrue(restored.references.isEmpty); XCTAssertNil(restored.artwork)
        let rows = try await store.list()
        XCTAssertEqual(rows.map(\.id), [artwork.id], "New conversation must preserve generated gallery images")
    }

    func testContinueEditingReplacesReferencesAndKeepsGeneratedPrompt() throws {
        let suite = "CanvasDraftTests." + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let model = CanvasViewModel(defaults: defaults)
        model.addReferences([(png, "Old reference")])
        let old = try XCTUnwrap(model.reference)
        let artwork = GeneratedArtwork(id: UUID(), pngData: png, prompt: "Continue this image", revisedPrompt: nil,
            model: "fixture", provider: "test", createdAt: Date(), pixelWidth: 1, pixelHeight: 1)
        XCTAssertTrue(model.resumeEditing(artwork))
        XCTAssertEqual(model.prompt, artwork.prompt); XCTAssertEqual(model.references.count, 1)
        XCTAssertNotEqual(model.reference?.id, old.id)
        XCTAssertEqual(try ReferenceImageStore.read(model.references), [try ReferenceImageStore.normalizedData(png)])
        model.prompt += " with clouds"
        model.addReferences([(png, "More reference")])
        XCTAssertEqual(model.references.count, 2); XCTAssertTrue(model.prompt.hasSuffix(" with clouds"))
        model.newConversation()
    }

    func testInvalidEditingImageLeavesExistingDraftIntact() {
        let model = CanvasViewModel(persistState: false)
        model.prompt = "Keep this"
        model.addReferences([(png, "Keep reference")])
        let references = model.references
        let invalid = GeneratedArtwork(id: UUID(), pngData: Data("broken".utf8), prompt: "Invalid", revisedPrompt: nil,
            model: "fixture", provider: "test", createdAt: Date(), pixelWidth: 1, pixelHeight: 1)
        XCTAssertFalse(model.resumeEditing(invalid))
        XCTAssertEqual(model.prompt, "Keep this"); XCTAssertEqual(model.references, references)
        model.newConversation()
    }

    func testFasterSwipesProduceStrongerSpring() {
        let slow = DrawerMotion.damping(translation: 80, projected: 95, width: 170)
        let fast = DrawerMotion.damping(translation: 80, projected: 400, width: 170)
        XCTAssertLessThan(fast, slow); XCTAssertGreaterThanOrEqual(fast, 0.5)
    }
}
