import XCTest
@testable import LumaCanvas

final class ConfigurationTests: XCTestCase {
    func testDeleteInstancePreservesOtherAndLastBecomesBlank() {
        var first = APIConfiguration(); first.apiKey = "first-test-key"
        var second = APIConfiguration(); second.apiKey = "second-test-key"
        var library = ConfigurationLibrary(instances: [first, second], selectedID: first.id)
        library.delete(first.id)
        XCTAssertEqual(library.instances, [second])
        XCTAssertEqual(library.selectedID, second.id)
        library.delete(second.id)
        XCTAssertEqual(library.instances.count, 1)
        let blank = library.instances[0]
        XCTAssertEqual(blank.name, "配置新 API")
        XCTAssertEqual(blank.apiKey, "")
        XCTAssertEqual(blank.endpoint, "")
        XCTAssertEqual(blank.model, "")
        XCTAssertNotEqual(blank.id, second.id)
        XCTAssertEqual(library.selectedID, blank.id)
    }

    func testOnlyUnusedOpenAIPresetIsRemovedDuringMigration() {
        let unused = APIConfiguration.preset(.openAI)
        var configured = APIConfiguration.preset(.openAI); configured.apiKey = "user-test-key"
        var customized = APIConfiguration.preset(.openAI); customized.model = "my-model"
        var library = ConfigurationLibrary(instances: [unused, configured, customized], selectedID: unused.id)
        library.removeUnusedPreset()
        XCTAssertEqual(library.instances, [configured, customized])
        XCTAssertEqual(library.selectedID, configured.id)
    }

    func testNAIFormatMigrationAndRatioDimensions() throws {
        let data = Data(#"{"endpoint":"https://api.rinko.ai/v1/chat/completions","model":"nai-diffusion-5-full","mode":"chatCompletions"}"#.utf8)
        var config = try JSONDecoder().decode(APIConfiguration.self, from: data)
        XCTAssertTrue(config.usesNAIParameters)
        config.naiChatFormat = .text
        XCTAssertFalse(config.usesNAIParameters)
        config.naiChatFormat = .automatic; config.endpoint = "https://other.example/v1/chat/completions"
        XCTAssertFalse(config.usesNAIParameters)
        config.naiChatFormat = .parameters
        XCTAssertTrue(config.usesNAIParameters)
        for ratio in ArtworkRatio.allCases where ratio != .auto {
            for orientation in [true, false] {
                let dimensions = ratio.size(landscape: orientation, nai: true).split(separator: "x").compactMap { Int($0) }
                XCTAssertEqual(dimensions.count, 2)
                XCTAssertTrue(dimensions.allSatisfy { $0 % 64 == 0 })
            }
        }
    }

    func testOldConfigurationMigratesWithoutLosingCredentials() throws {
        let old = Data(#"{"provider":"rinko","mode":"chatCompletions","endpoint":"https://api.rinko.ai/v1/chat/completions","modelsEndpoint":"https://api.rinko.ai/v1/models","apiKey":"legacy-test-key","model":"image-test"}"#.utf8)
        let value = try JSONDecoder().decode(APIConfiguration.self, from: old)
        XCTAssertEqual(value.apiKey, "legacy-test-key")
        XCTAssertEqual(value.size, "auto")
        XCTAssertEqual(value.site, "https://api.rinko.ai")
        let roundTrip = try JSONDecoder().decode(APIConfiguration.self, from: JSONEncoder().encode(value))
        XCTAssertEqual(roundTrip, value)
    }

    func testBaseURLDiscoveryPreservesGatewayPrefixAndRejectsCredentials() throws {
        let routes = try SiteDiscovery.defaults(site: "https://example.com/gateway/v1/", mode: .images)
        XCTAssertEqual(routes.0, "https://example.com/gateway/v1/images/generations")
        XCTAssertEqual(routes.1, "https://example.com/gateway/v1/models")
        XCTAssertEqual(try SiteDiscovery.defaults(site: "example.com", mode: .chatCompletions).0, "https://example.com/v1/chat/completions")
        XCTAssertThrowsError(try SiteDiscovery.defaults(site: "https://user:secret@example.com", mode: .images))
        XCTAssertThrowsError(try SiteDiscovery.defaults(site: "http://example.com", mode: .images))
        XCTAssertThrowsError(try SiteDiscovery.defaults(site: "https://example.com?key=secret", mode: .images))
    }

    func testModerationBothModesAndOmitsOff() throws {
        var config = APIConfiguration.preset(.openAI)
        config.apiKey = "test-secret"
        for level in Sensitivity.allCases {
            let request = try ImageAPIClient.makeRequest(prompt: "a cat", configuration: config, size: "auto", sensitivity: level)
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
            XCTAssertEqual(body["moderation"] as? String, level.parameter)
            XCTAssertEqual(body["size"] as? String, "auto")
        }
        config.mode = .chatCompletions
        let request = try ImageAPIClient.makeRequest(prompt: "a cat", configuration: config, size: "auto", sensitivity: .low)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
        XCTAssertEqual(body["moderation"] as? String, "low")
        XCTAssertNil(body["size"])
        config.extraBody = #"{"moderation":"disabled"}"#
        XCTAssertThrowsError(try config.validate())
    }

    @MainActor func testInstancesRetainSeparateIncompleteDraftsAndNewCopies() throws {
        let original = try KeychainStore.readData(account: "api-instances-v2")
        defer { try? KeychainStore.writeData(original, account: "api-instances-v2") }
        let store = ConfigurationStore()
        var first = APIConfiguration()
        first.name = "First"; first.site = "https://one.example"; first.apiKey = "one-test-key"
        try store.save(first)
        var second = APIConfiguration()
        second.name = "Second"; second.apiKey = "two-test-key"
        try store.save(second)
        let loaded = try store.select(first.id, saving: second)
        XCTAssertEqual(loaded, first)
        XCTAssertEqual(store.instances.first(where: { $0.id == second.id })?.apiKey, "two-test-key")
        var changed = first
        changed.apiKey = "copy-test-key"
        let copy = try store.saveAsNew(changed)
        XCTAssertNotEqual(copy.id, first.id)
        XCTAssertEqual(store.instances.first(where: { $0.id == first.id })?.apiKey, "one-test-key")
        XCTAssertEqual(ConfigurationStore().value.apiKey, "copy-test-key")
    }
}
