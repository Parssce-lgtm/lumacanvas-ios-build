import XCTest
@testable import LumaCanvas

final class ConfigurationTests: XCTestCase {
    func testOldConfigurationMigratesWithoutLosingCredentials() throws {
        let old = Data(#"{"provider":"rinko","mode":"chatCompletions","endpoint":"https://api.rinko.ai/v1/chat/completions","modelsEndpoint":"https://api.rinko.ai/v1/models","apiKey":"legacy-test-key","model":"image-test"}"#.utf8)
        let value = try JSONDecoder().decode(APIConfiguration.self, from: old)
        XCTAssertEqual(value.apiKey, "legacy-test-key")
        XCTAssertEqual(value.size, "auto")
        XCTAssertEqual(value.site, "https://api.rinko.ai")
        let roundTrip = try JSONDecoder().decode(APIConfiguration.self, from: JSONEncoder().encode(value))
        XCTAssertEqual(roundTrip, value)
    }

    func testBaseURLDiscoveryPreservesGatewayPrefixAndRejectsCredentials() throws {
        let routes = try SiteDiscovery.defaults(site: "https://example.com/gateway/v1/", mode: .images)
        XCTAssertEqual(routes.0, "https://example.com/gateway/v1/images/generations")
        XCTAssertEqual(routes.1, "https://example.com/gateway/v1/models")
        XCTAssertEqual(try SiteDiscovery.defaults(site: "example.com", mode: .chatCompletions).0, "https://example.com/v1/chat/completions")
        XCTAssertThrowsError(try SiteDiscovery.defaults(site: "https://user:secret@example.com", mode: .images))
        XCTAssertThrowsError(try SiteDiscovery.defaults(site: "http://example.com", mode: .images))
        XCTAssertThrowsError(try SiteDiscovery.defaults(site: "https://example.com?key=secret", mode: .images))
    }

    func testModerationBothModesAndOmitsOff() throws {
        var config = APIConfiguration.preset(.openAI)
        config.apiKey = "test-secret"
        for level in Sensitivity.allCases {
            let request = try ImageAPIClient.makeRequest(prompt: "a cat", configuration: config, size: "auto", sensitivity: level)
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
            XCTAssertEqual(body["moderation"] as? String, level.parameter)
            XCTAssertEqual(body["size"] as? String, "auto")
        }
        config.mode = .chatCompletions
        let request = try ImageAPIClient.makeRequest(prompt: "a cat", configuration: config, size: "auto", sensitivity: .low)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
        XCTAssertEqual(body["moderation"] as? String, "low")
        XCTAssertNil(body["size"])
        config.extraBody = #"{"moderation":"disabled"}"#
        XCTAssertThrowsError(try config.validate())
    }

    @MainActor func testInstancesRetainSeparateIncompleteDraftsAndNewCopies() throws {
        let original = try KeychainStore.readData(account: "api-instances-v2")
        defer { try? KeychainStore.writeData(original, account: "api-instances-v2") }
        let store = ConfigurationStore()
        var first = APIConfiguration()
        first.name = "First"; first.site = "https://one.example"; first.apiKey = "one-test-key"
        try store.save(first)
        var second = APIConfiguration()
        second.name = "Second"; second.apiKey = "two-test-key"
        try store.save(second)
        let loaded = try store.select(first.id, saving: second)
        XCTAssertEqual(loaded, first)
        XCTAssertEqual(store.instances.first(where: { $0.id == second.id })?.apiKey, "two-test-key")
        var changed = first
        changed.apiKey = "copy-test-key"
        let copy = try store.saveAsNew(changed)
        XCTAssertNotEqual(copy.id, first.id)
        XCTAssertEqual(store.instances.first(where: { $0.id == first.id })?.apiKey, "one-test-key")
        XCTAssertEqual(ConfigurationStore().value.apiKey, "copy-test-key")
    }
}
