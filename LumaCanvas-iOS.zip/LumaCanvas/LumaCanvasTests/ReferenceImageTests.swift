import XCTest
import UIKit
@testable import LumaCanvas

final class ReferenceImageTests: XCTestCase {
    private var png: Data {
        Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg==")!
    }
    private var configuration: APIConfiguration {
        var value = APIConfiguration.preset(.openAI)
        value.apiKey = "test-secret"
        return value
    }

    func testMultipartReferenceUsesEditRouteAndStableBytesForBackgroundRecovery() throws {
        let first = try ImageAPIClient.makeRequest(prompt: "cat", configuration: configuration,
            size: "auto", sensitivity: .low, referenceData: png)
        let second = try ImageAPIClient.makeRequest(prompt: "cat", configuration: configuration,
            size: "auto", sensitivity: .low, referenceData: png)
        XCTAssertEqual(first.url?.absoluteString, "https://api.openai.com/v1/images/edits")
        XCTAssertEqual(first.httpBody, second.httpBody)
        XCTAssertEqual(first.value(forHTTPHeaderField: "Authorization"), "Bearer test-secret")
        let body = try XCTUnwrap(first.httpBody)
        XCTAssertNotNil(body.range(of: png))
        let text = String(decoding: body, as: UTF8.self)
        XCTAssertTrue(text.contains("name=\"image[]\"; filename=\"reference.png\""))
        XCTAssertTrue(text.contains("name=\"moderation\"\r\n\r\nlow\r\n"))
        XCTAssertTrue(text.contains("name=\"prompt\"\r\n\r\ncat\r\n"))
        XCTAssertTrue(first.value(forHTTPHeaderField: "Content-Type")?.hasPrefix("multipart/form-data; boundary=") == true)
    }

    func testChatReferenceAndSensitivityAreSentTogether() throws {
        var config = configuration
        config.mode = .chatCompletions
        config.endpoint = "https://api.openai.com/v1/chat/completions"
        for level in Sensitivity.allCases {
            let request = try ImageAPIClient.makeRequest(prompt: "cat", configuration: config,
                size: "auto", sensitivity: level, referenceData: png)
            let body = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
            XCTAssertEqual(body["moderation"] as? String, level.parameter)
            let messages = try XCTUnwrap(body["messages"] as? [[String: Any]])
            let parts = try XCTUnwrap(messages.first?["content"] as? [[String: Any]])
            XCTAssertEqual(parts.first?["type"] as? String, "text")
            XCTAssertEqual((parts.last?["image_url"] as? [String: Any])?["url"] as? String,
                "data:image/png;base64," + png.base64EncodedString())
            XCTAssertNil(body["size"])
        }
    }

    func testCustomEditRouteRejectsCredentialLeakAndUnknownRoutes() throws {
        var config = configuration
        config.endpoint = "https://gateway.example/prefix/v1/images/generations"
        XCTAssertEqual(try config.referenceEndpoint().path, "/prefix/v1/images/edits")
        config.editsEndpoint = "https://other.example/v1/images/edits"
        XCTAssertThrowsError(try ImageAPIClient.makeRequest(prompt: "cat", configuration: config, size: "auto", referenceData: png))
        config.editsEndpoint = ""; config.endpoint = "https://gateway.example/custom"
        XCTAssertThrowsError(try config.referenceEndpoint())
        config.editsEndpoint = "https://gateway.example/custom-edit"
        XCTAssertEqual(try config.referenceEndpoint().path, "/custom-edit")
        XCTAssertThrowsError(try ImageAPIClient.makeRequest(prompt: "cat", configuration: config, size: "auto", referenceData: Data()))
    }

    func testReferenceStorageRejectsNonImagesAndKeepsDurablePNG() throws {
        XCTAssertThrowsError(try ReferenceImageStore.save(Data("not an image".utf8), name: "wrong.png"))
        let (reference, preview) = try ReferenceImageStore.save(png, name: "test.png")
        defer { ReferenceImageStore.remove(reference) }
        XCTAssertEqual(preview.cgImage?.width, 1)
        let stored = try XCTUnwrap(ReferenceImageStore.read(reference))
        XCTAssertNotNil(UIImage(data: stored))
        let job = PendingGeneration(id: UUID(), prompt: "cat", size: "auto", sensitivity: .off,
            configuration: configuration, startedAt: Date(), reference: reference)
        let recovered = try JSONDecoder().decode(PendingGeneration.self, from: JSONEncoder().encode(job))
        XCTAssertEqual(recovered.reference, reference)
        XCTAssertEqual(try ReferenceImageStore.read(recovered.reference), stored)
    }

    func testPendingJobWithoutReferenceMigrates() throws {
        let job = PendingGeneration(id: UUID(), prompt: "cat", size: "auto", sensitivity: .off,
            configuration: configuration, startedAt: Date())
        var old = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(job)) as? [String: Any])
        old.removeValue(forKey: "reference")
        let restored = try JSONDecoder().decode(PendingGeneration.self, from: JSONSerialization.data(withJSONObject: old))
        XCTAssertNil(restored.reference)
        XCTAssertEqual(restored.prompt, "cat")
    }

    private var secondPNG: Data {
        UIGraphicsImageRenderer(size: CGSize(width: 2, height: 3)).image { context in
            UIColor.blue.setFill(); context.fill(CGRect(x: 0, y: 0, width: 2, height: 3))
        }.pngData()!
    }

    func testMultipleReferencesReachBothModesInOrder() throws {
        let images = [png, secondPNG]
        let first = try ImageAPIClient.makeRequest(prompt: "cat", configuration: configuration, size: "auto", referenceImages: images)
        let same = try ImageAPIClient.makeRequest(prompt: "cat", configuration: configuration, size: "auto", referenceImages: images)
        let reversed = try ImageAPIClient.makeRequest(prompt: "cat", configuration: configuration, size: "auto", referenceImages: Array(images.reversed()))
        XCTAssertEqual(first.httpBody, same.httpBody)
        XCTAssertNotEqual(first.httpBody, reversed.httpBody)
        let body = try XCTUnwrap(first.httpBody)
        XCTAssertLessThan(try XCTUnwrap(body.range(of: png)).lowerBound, try XCTUnwrap(body.range(of: secondPNG)).lowerBound)
        let text = String(decoding: body, as: UTF8.self)
        XCTAssertTrue(text.contains("reference-1.png")); XCTAssertTrue(text.contains("reference-2.png"))
        var chat = configuration; chat.mode = .chatCompletions
        chat.endpoint = "https://api.openai.com/v1/chat/completions"
        let request = try ImageAPIClient.makeRequest(prompt: "cat", configuration: chat, size: "auto", referenceImages: images)
        let json = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
        let messages = try XCTUnwrap(json["messages"] as? [[String: Any]])
        let parts = try XCTUnwrap(messages.first?["content"] as? [[String: Any]])
        XCTAssertEqual(parts.count, 3)
        for (index, data) in images.enumerated() {
            XCTAssertEqual((parts[index + 1]["image_url"] as? [String: String])?["url"], "data:image/png;base64," + data.base64EncodedString())
        }
    }

    func testLegacySingleReferenceEncodingMatchesArrayAndPendingMigrates() throws {
        let old = try ImageAPIClient.makeRequest(prompt: "cat", configuration: configuration, size: "auto", referenceData: png)
        let new = try ImageAPIClient.makeRequest(prompt: "cat", configuration: configuration, size: "auto", referenceImages: [png])
        XCTAssertEqual(old.httpBody, new.httpBody)
        let reference = ReferenceImage(id: UUID(), name: "old")
        let job = PendingGeneration(id: UUID(), prompt: "cat", size: "auto", sensitivity: .off,
            configuration: configuration, startedAt: Date(), reference: reference)
        let migrated = try JSONDecoder().decode(PendingGeneration.self, from: JSONEncoder().encode(job))
        XCTAssertEqual(migrated.allReferences, [reference])
        var multi = job
        multi.references = [reference, ReferenceImage(id: UUID(), name: "second")]
        XCTAssertEqual(try JSONDecoder().decode(PendingGeneration.self, from: JSONEncoder().encode(multi)).allReferences, multi.references)
    }

    func testReferenceCountAndByteLimitsAreEnforcedBeforeRequest() throws {
        XCTAssertThrowsError(try ImageAPIClient.makeRequest(prompt: "cat", configuration: configuration, size: "auto", referenceImages: Array(repeating: png, count: 9)))
        XCTAssertThrowsError(try ReferenceImageStore.validatePayload([Data()]))
        XCTAssertThrowsError(try ReferenceImageStore.validatePayload(Array(repeating: Data(repeating: 0, count: 15 * 1024 * 1024), count: 3)))
    }

    func testImageFileWithUnknownExtensionCanBeImported() throws {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".bin")
        try png.write(to: file); defer { try? FileManager.default.removeItem(at: file) }
        let data = try ReferenceImageStore.readFile(file)
        let (reference, preview) = try ReferenceImageStore.save(data, name: file.lastPathComponent)
        defer { ReferenceImageStore.remove(reference) }
        XCTAssertEqual(preview.cgImage?.width, 1)
    }

    @MainActor
    func testSelectionAppendIndividualRemovalAndInvalidBatchRollback() throws {
        let defaults = UserDefaults.standard
        let old = defaults.data(forKey: "reference-images-v2")
        let legacy = defaults.data(forKey: "reference-image-v1")
        let canvas = CanvasViewModel()
        defer {
            canvas.removeReference()
            defaults.set(old, forKey: "reference-images-v2"); defaults.set(legacy, forKey: "reference-image-v1")
        }
        canvas.addReferences([(png, "first"), (secondPNG, "second")])
        XCTAssertEqual(canvas.references.count, 2)
        let selected = canvas.references
        canvas.addReferences([(png, "valid"), (Data("invalid".utf8), "bad")])
        XCTAssertEqual(canvas.references, selected, "A failed batch preserves previous selections")
        canvas.removeReference(selected[0])
        XCTAssertEqual(canvas.references, [selected[1]])
        XCTAssertNotNil(canvas.referencePreview)
    }
}
