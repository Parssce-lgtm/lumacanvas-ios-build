import XCTest
import UIKit
@testable import LumaCanvas

final class ArtworkStoreTests: XCTestCase {
    private let png = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg==")!
    private func item(_ time: TimeInterval, id: UUID = UUID()) -> GeneratedArtwork {
        GeneratedArtwork(id: id, pngData: png, prompt: "Image \(time)", revisedPrompt: nil, model: "fixture",
            provider: "test", createdAt: Date(timeIntervalSince1970: time), pixelWidth: 1, pixelHeight: 1)
    }
    func testKeepsMultipleImagesOrderedAndPersistsAcrossStoreInstances() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = ArtworkStore(root: root), first = item(1), second = item(2)
        try await store.save(first); try await store.save(second); try await store.save(second)
        let restored = ArtworkStore(root: root)
        let rows = try await restored.list()
        XCTAssertEqual(rows.map(\.id), [second.id, first.id])
        let older = try await restored.artwork(first.id); XCTAssertEqual(older.pngData, png)
        let latest = try await restored.load(); XCTAssertEqual(latest?.id, second.id)
        let data = try await restored.thumbnail(second.id)
        let thumbnail = try XCTUnwrap(data)
        XCTAssertNotNil(UIImage(data: thumbnail))
    }
    func testImportsLegacyLatestImageWithoutCreatingDuplicates() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let old = item(10)
        try PropertyListEncoder().encode(old).write(to: root.appendingPathComponent("latest-artwork.plist"))
        let store = ArtworkStore(root: root)
        let first = try await store.list(); let second = try await store.list()
        XCTAssertEqual(first.map(\.id), [old.id]); XCTAssertEqual(first, second)
        let restored = try await store.artwork(old.id); XCTAssertEqual(restored.prompt, old.prompt)
    }
    func testMalformedCacheDoesNotHideGalleryAndInvalidImageDoesNotReplaceLatest() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = ArtworkStore(root: root), valid = item(1)
        try await store.save(valid)
        let invalid = GeneratedArtwork(id: UUID(), pngData: Data("not an image".utf8), prompt: "", revisedPrompt: nil,
            model: "", provider: "", createdAt: Date(), pixelWidth: 1, pixelHeight: 1)
        do { try await store.save(invalid); XCTFail("Expected invalid image rejection") } catch { }
        let latest = try await store.load(); XCTAssertEqual(latest?.id, valid.id)
        try Data("broken".utf8).write(to: root.appendingPathComponent("latest-artwork.plist"))
        try Data("broken".utf8).write(to: root.appendingPathComponent("Gallery/broken.json"))
        let rows = try await store.list(); XCTAssertEqual(rows.map(\.id), [valid.id])
    }

    func testDeletingLatestDoesNotResurrectAndFallsBackToOlderImage() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = ArtworkStore(root: root), older = item(1), newest = item(2)
        try await store.save(older); try await store.save(newest)
        try await store.delete(newest.id)
        let reopened = ArtworkStore(root: root)
        let rows = try await reopened.list(), latest = try await reopened.load()
        XCTAssertEqual(rows.map(\.id), [older.id]); XCTAssertEqual(latest?.id, older.id)
        XCTAssertFalse(FileManager.default.fileExists(atPath: root.appendingPathComponent("Gallery/\(newest.id.uuidString).png").path))
        try await reopened.delete(older.id); try await reopened.delete(older.id)
        let empty = try await reopened.list(), absent = try await reopened.load()
        XCTAssertTrue(empty.isEmpty); XCTAssertNil(absent)
    }

    func testDeletingOlderImageKeepsNewestAndShareExportsOriginalPNG() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = ArtworkStore(root: root), older = item(1), newest = item(2)
        try await store.save(older); try await store.save(newest); try await store.delete(older.id)
        let rows = try await store.list(), latest = try await store.load()
        XCTAssertEqual(rows.map(\.id), [newest.id]); XCTAssertEqual(latest?.id, newest.id)
        let share = try ArtworkShareItem(newest)
        defer { try? FileManager.default.removeItem(at: share.url) }
        XCTAssertEqual(try Data(contentsOf: share.url), newest.pngData)
    }
}
