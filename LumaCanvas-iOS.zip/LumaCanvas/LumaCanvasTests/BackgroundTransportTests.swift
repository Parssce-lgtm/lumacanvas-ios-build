import XCTest
import UIKit
@testable import LumaCanvas

/// Real loopback HTTP through the iOS background URLSession daemon. Mocked
/// ImageTransport tests cannot exercise delegate body delivery or conversion.
final class BackgroundTransportTests: XCTestCase {
    func testNAIParametersRealResponseThroughBothTransportsWithoutRepeat() async throws {
        for standard in [true, false] {
            let token = UUID(), job = UUID()
            defer {
                BackgroundTransfers.foreground.cleanup(job: job)
                BackgroundTransfers.shared.cleanup(job: job)
            }
            var configuration = APIConfiguration.preset(.rinko)
            configuration.apiKey = "test-only"; configuration.model = "nai-diffusion-5-full"
            let transport = RinkoReplayTransport(job: job, token: token, standard: standard, path: "nai-replay")
            let result = try await ImageAPIClient(apiTransport: transport, downloadTransport: transport)
                .generate(prompt: "A small blue circle on a white background.", configuration: configuration, size: "512x512", sensitivity: .high)
            let image = try XCTUnwrap(UIImage(data: result.data)?.cgImage)
            XCTAssertEqual(image.width, 512); XCTAssertEqual(image.height, 512)
            let calls = try await records(token)
            XCTAssertEqual(calls.count, 1)
        }
    }

    private func request(_ path: String, token: UUID) -> URLRequest {
        var request = URLRequest(url: URL(string: "http://localhost:8765/\(path)?id=\(token.uuidString)")!)
        request.httpMethod = "POST"
        request.timeoutInterval = 30
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = Data("{\"prompt\":\"网络回包测试\",\"stream\":false}".utf8)
        return request
    }
    private func records(_ token: UUID) async throws -> [[String: Any]] {
        let (data, _) = try await URLSession.shared.data(from: URL(string: "http://localhost:8765/stats?id=\(token.uuidString)")!)
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [[String: Any]])
    }

    func testActualUploadResponseBodyAndCachedRecoveryWithoutSecondPOST() async throws {
        let token = UUID(), job = UUID()
        defer { BackgroundTransfers.shared.cleanup(job: job) }
        let request = request("generate", token: token)
        let transport = BackgroundImageTransport(job: job)
        let (data, response) = try await transport.receive(request, byteLimit: 80 * 1024 * 1024)
        XCTAssertEqual((response as? HTTPURLResponse)?.statusCode, 200)
        XCTAssertGreaterThan(data.count, 20_000, "Actual response body must not be lost")
        let root = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        let rows = try XCTUnwrap(root["data"] as? [[String: String]])
        XCTAssertNotNil(UIImage(data: try ImageAPIClient.decodeBase64(XCTUnwrap(rows.first?["b64_json"]))))
        let recovered = try await BackgroundImageTransport(job: job).receive(request, byteLimit: 80 * 1024 * 1024)
        XCTAssertEqual(recovered.0, data)
        let calls = try await records(token)
        XCTAssertEqual(calls.count, 1, "Recovery must not resubmit a billable generation")
        XCTAssertEqual(calls.first?["method"] as? String, "POST")
        XCTAssertEqual(calls.first?["body"] as? String, String(decoding: request.httpBody!, as: UTF8.self))
    }

    func testActualChunkedSSEAndGzipResponseBodies() async throws {
        for path in ["chunked", "gzip"] {
            let token = UUID(), job = UUID()
            let (data, response) = try await BackgroundImageTransport(job: job).receive(request(path, token: token), byteLimit: 80 * 1024 * 1024)
            defer { BackgroundTransfers.shared.cleanup(job: job) }
            XCTAssertFalse(data.isEmpty)
            guard case .json(let root) = try GenerationResponse.parse(data, response: response, apiKey: "") else {
                XCTFail("Expected image JSON/SSE"); continue
            }
            XCTAssertTrue(root["data"] != nil || root["choices"] != nil)
            let calls = try await records(token); XCTAssertEqual(calls.count, 1)
        }
    }

    func testActualHTTP504AndGenuinelyEmpty200RemainErrorsWithoutRetry() async throws {
        for path in ["status504", "empty"] {
            let token = UUID(), job = UUID()
            defer { BackgroundTransfers.shared.cleanup(job: job) }
            let (data, response) = try await BackgroundImageTransport(job: job).receive(request(path, token: token), byteLimit: 80 * 1024 * 1024)
            do {
                try ImageAPIClient.check(response, data: data, apiKey: "")
                _ = try GenerationResponse.parse(data, response: response, apiKey: "")
                XCTFail("Expected provider failure")
            } catch {
                XCTAssertTrue(error.localizedDescription.contains(path == "empty" ? "空内容" : "504"))
            }
            let calls = try await records(token); XCTAssertEqual(calls.count, 1)
        }
    }

    func testStreamingPreferencePersistsAndLegacyRemainsStable() throws {
        var config = APIConfiguration.preset(.rinko); config.apiKey = "test-only"; config.model = "nai-diffusion-5-full"
        config.chatStreaming = true
        let request = try ImageAPIClient.makeRequest(prompt: "cat", configuration: config, size: "auto")
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: request.httpBody!) as? [String: Any])
        XCTAssertEqual(body["stream"] as? Bool, true)
        let decoded = try JSONDecoder().decode(APIConfiguration.self, from: JSONEncoder().encode(config))
        XCTAssertTrue(decoded.chatStreaming)
        var legacy = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(config)) as? [String: Any])
        legacy.removeValue(forKey: "chatStreaming")
        XCTAssertFalse(try JSONDecoder().decode(APIConfiguration.self, from: JSONSerialization.data(withJSONObject: legacy)).chatStreaming)
    }

    func testRealRinkoResponseReplayProducesFullImageWithOnePOST() async throws {
        let token = UUID(), job = UUID()
        defer { BackgroundTransfers.shared.cleanup(job: job) }
        var config = APIConfiguration.preset(.rinko)
        config.apiKey = "fixture-only-no-provider-key"; config.model = "nai-diffusion-5-full"
        let client = ImageAPIClient(apiTransport: RinkoReplayTransport(job: job, token: token))
        let result = try await client.generate(prompt: "A blue circle", configuration: config, size: "auto", sensitivity: .off)
        let image = try XCTUnwrap(UIImage(data: result.data))
        XCTAssertEqual(image.size.width, 832); XCTAssertEqual(image.size.height, 1216)
        XCTAssertGreaterThan(result.data.count, 1_000_000)
        let calls = try await records(token)
        XCTAssertEqual(calls.count, 1)
        let body = try XCTUnwrap(calls.first?["body"] as? String)
        let submitted = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(body.utf8)) as? [String: Any])
        XCTAssertEqual(submitted["model"] as? String, "nai-diffusion-5-full")
        XCTAssertEqual(submitted["stream"] as? Bool, false)
        XCTAssertNil(submitted["moderation"])
    }

    func testLegacyUploadAllowComparedToDownloadResponse() async throws {
        let token = UUID(), job = UUID()
        let control = LegacyUploadControl()
        let old = try await control.receive(request("generate", token: token))
        let (new, _) = try await BackgroundImageTransport(job: job).receive(request("generate", token: UUID()), byteLimit: 80 * 1024 * 1024)
        defer { BackgroundTransfers.shared.cleanup(job: job) }
        print("NETWORK_RESPONSE_COMPARISON legacy_allow_bytes=\(old.count) download_bytes=\(new.count)")
        XCTAssertGreaterThan(new.count, 20_000)
        // Record whether this OS reproduces the legacy loss; a legacy implementation
        // working in foreground is not proof that its suspended callbacks are safe.
        if !old.isEmpty { XCTAssertEqual(old, new) }
        let calls = try await records(token); XCTAssertEqual(calls.count, 1)
    }

    func testStandardPOSTUsesRealRinkoResponseAndKeepsBody() async throws {
        let token = UUID(), job = UUID()
        defer { BackgroundTransfers.foreground.cleanup(job: job) }
        var config = APIConfiguration.preset(.rinko); config.model = "nai-diffusion-5-full"; config.apiKey = "fixture-only"
        let client = ImageAPIClient(apiTransport: RinkoReplayTransport(job: job, token: token, standard: true))
        let result = try await client.generate(prompt: "A blue circle", configuration: config, size: "auto", sensitivity: .off)
        let image = try XCTUnwrap(UIImage(data: result.data))
        XCTAssertEqual(image.size.width, 832); XCTAssertEqual(image.size.height, 1216)
        let calls = try await records(token)
        XCTAssertEqual(calls.count, 1)
        let body = try XCTUnwrap(calls.first?["body"] as? String)
        XCTAssertTrue(body.contains("nai-diffusion-5-full"))
        XCTAssertFalse(body.contains("moderation"))
    }

    func testStandardChunkedGzipAndCachedResponseDoNotRepeatPOST() async throws {
        for path in ["generate", "chunked", "gzip"] {
            let token = UUID(), job = UUID()
            defer { BackgroundTransfers.foreground.cleanup(job: job) }
            let transport = ForegroundImageTransport(job: job)
            let request = request(path, token: token)
            let first = try await transport.receive(request, byteLimit: 80 * 1024 * 1024)
            _ = try GenerationResponse.parse(first.0, response: first.1, apiKey: "")
            let cached = try await transport.receive(request, byteLimit: 80 * 1024 * 1024)
            XCTAssertEqual(first.0, cached.0)
            XCTAssertEqual((first.1 as? HTTPURLResponse)?.value(forHTTPHeaderField: "X-Luma-Transport"), "standard")
            let calls = try await records(token)
            XCTAssertEqual(calls.count, 1)
            XCTAssertEqual(calls.first?["body"] as? String, String(decoding: request.httpBody!, as: UTF8.self))
        }
    }

    func testStandardEmptyResponseDiagnosticsAnd504DoNotRetry() async throws {
        for path in ["empty", "status504"] {
            let token = UUID(), job = UUID()
            defer { BackgroundTransfers.foreground.cleanup(job: job) }
            var config = APIConfiguration.preset(.rinko); config.model = "nai-diffusion-5-full"; config.apiKey = "fixture-only-secret"
            let client = ImageAPIClient(apiTransport: LocalStandardTestTransport(job: job, path: path, token: token))
            do {
                _ = try await client.generate(prompt: "cat", configuration: config, size: "auto")
                XCTFail("Expected explicit failure")
            } catch {
                let text = error.localizedDescription
                XCTAssertFalse(text.contains(config.apiKey))
                XCTAssertTrue(text.contains(path == "empty" ? "常规 POST" : "504"))
                if path == "empty" { XCTAssertTrue(text.contains("字节")); XCTAssertTrue(text.contains("未自动重发")) }
            }
            let calls = try await records(token); XCTAssertEqual(calls.count, 1)
        }
    }

    func testOldInstancesUseStandardButSubmittedLegacyJobsRejoinBackground() throws {
        var config = APIConfiguration.preset(.rinko); config.model = "nai-diffusion-5-full"; config.apiKey = "fixture-only"
        var old = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(config)) as? [String: Any])
        old.removeValue(forKey: "transfer")
        let migrated = try JSONDecoder().decode(APIConfiguration.self, from: JSONSerialization.data(withJSONObject: old))
        XCTAssertEqual(migrated.transfer, .standard)
        let legacy = PendingGeneration(id: UUID(), prompt: "cat", size: "auto", sensitivity: .off, configuration: migrated, startedAt: Date())
        let restored = try JSONDecoder().decode(PendingGeneration.self, from: JSONEncoder().encode(legacy))
        XCTAssertEqual(restored.resolvedTransfer, .background)
        let new = PendingGeneration(id: UUID(), prompt: "cat", size: "auto", sensitivity: .off, configuration: migrated, startedAt: Date(), transfer: .standard)
        XCTAssertEqual(try JSONDecoder().decode(PendingGeneration.self, from: JSONEncoder().encode(new)).resolvedTransfer, .standard)
        let request = try ImageAPIClient.makeRequest(prompt: "cat", configuration: migrated, size: "auto")
        XCTAssertEqual(request.value(forHTTPHeaderField: "Content-Length"), String(request.httpBody!.count))
    }
}

/// Offline replay of the sanitized real provider response; never contacts Rinko.
private struct RinkoReplayTransport: ImageTransport {
    let job: UUID
    let token: UUID
    var standard = false
    var path = "rinko-replay"
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        var local = request
        local.url = URL(string: "http://localhost:8765/\(path)?id=\(token.uuidString)")!
        local.setValue(nil, forHTTPHeaderField: "Authorization")
        if standard { return try await ForegroundImageTransport(job: job).receive(local, byteLimit: byteLimit) }
        return try await BackgroundImageTransport(job: job).receive(local, byteLimit: byteLimit)
    }
}

private struct LocalStandardTestTransport: ImageTransport {
    let job: UUID
    let path: String
    let token: UUID
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        var local = request; local.url = URL(string: "http://localhost:8765/\(path)?id=\(token.uuidString)")!
        local.setValue(nil, forHTTPHeaderField: "Authorization")
        return try await ForegroundImageTransport(job: job).receive(local, byteLimit: byteLimit)
    }
}

/// Test-only control matching the old upload/allow/data-callback mechanism.
private final class LegacyUploadControl: NSObject, URLSessionDataDelegate {
    private var data = Data()
    private var continuation: CheckedContinuation<Data, Error>?
    private var session: URLSession?
    func receive(_ request: URLRequest) async throws -> Data {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try request.httpBody!.write(to: file)
        defer { try? FileManager.default.removeItem(at: file); session?.invalidateAndCancel() }
        let config = URLSessionConfiguration.background(withIdentifier: "app.lumacanvas.test-control." + UUID().uuidString)
        config.isDiscretionary = false
        let queue = OperationQueue(); queue.maxConcurrentOperationCount = 1
        session = URLSession(configuration: config, delegate: self, delegateQueue: queue)
        return try await withCheckedThrowingContinuation { waiter in
            continuation = waiter
            var upload = request; upload.httpBody = nil
            session!.uploadTask(with: upload, fromFile: file).resume()
        }
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) { completionHandler(.allow) }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive part: Data) { data.append(part) }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error { continuation?.resume(throwing: error) }
        else { continuation?.resume(returning: data) }
        continuation = nil
    }
}
