import XCTest
@testable import LumaCanvas

private actor ProbeTransport: ImageTransport {
    var requests: [URLRequest] = []
    var cancelled = false
    let body: Data
    let status: Int
    let delay: UInt64
    init(body: Data, status: Int = 200, delay: UInt64 = 0) {
        self.body = body; self.status = status; self.delay = delay
    }
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        requests.append(request)
        do { if delay > 0 { try await Task.sleep(nanoseconds: delay) } }
        catch { cancelled = true; throw error }
        return (body, HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil, headerFields: nil)!)
    }
}

final class ModelTests: XCTestCase {
    private var configuration: APIConfiguration {
        var config = APIConfiguration.preset(.openAI)
        config.apiKey = "test-only"
        config.model = "current-image-model"
        config.size = "1024x1024"
        return config
    }
    private func data(_ object: [String: Any]) throws -> Data { try JSONSerialization.data(withJSONObject: object) }
    private var pngResponse: Data {
        try! data(["data": [["b64_json": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg=="]]])
    }

    func testCatalogUsesOutputCapabilitiesAndSeparatesOrdinaryModels() throws {
        let catalog = try ModelOption.parse(data(["data": [
            ["id": "gpt-4o", "input_modalities": ["image", "text"]],
            ["id": "custom-canvas", "output_modalities": ["image"]],
            ["id": "flux-1", "supports_image_generation": false],
            ["id": "gpt-image-1"],
            ["id": "qwen-vision"],
            ["id": "edit-custom", "supported_endpoints": ["/v1/images/edits"]],
            ["id": "custom-canvas"],
            ["id": ""]
        ]]))
        XCTAssertEqual(catalog.count, 6)
        XCTAssertEqual(Set(catalog.prefix(3).map(\.id)), ["custom-canvas", "edit-custom", "gpt-image-1"])
        XCTAssertTrue(catalog.suffix(3).allSatisfy { !$0.isImageCandidate })
        XCTAssertEqual(catalog.first { $0.id == "custom-canvas" }?.evidence, "接口标记")
        XCTAssertEqual(catalog.first { $0.id == "gpt-image-1" }?.evidence, "名称识别")
    }

    func testCatalogRejectsMalformedRows() {
        XCTAssertThrowsError(try ModelOption.parse(Data("{}".utf8)))
        XCTAssertThrowsError(try ModelOption.parse(data(["data": [["name": "missing-id"]]])))
    }

    func testProbeUsesSelectedModelAndParametersAndOnlyOneRequest() async throws {
        let transport = ProbeTransport(body: pngResponse)
        let result = try await ModelProbe(client: ImageAPIClient(apiTransport: transport, downloadTransport: transport)).test(configuration: configuration)
        XCTAssertEqual(result.status, .available)
        let requests = await transport.requests
        XCTAssertEqual(requests.count, 1)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(requests.first?.httpBody)) as? [String: Any])
        XCTAssertEqual(body["model"] as? String, configuration.model)
        XCTAssertEqual(body["size"] as? String, configuration.size)
        XCTAssertEqual(body["n"] as? Int, 1)
        XCTAssertNil(body["moderation"])
    }

    func testProbeClassifiesProviderErrorsWithoutRetries() async throws {
        for (status, message, expected) in [
            (404, "model missing", ModelProbeResult.Status.invalidModel),
            (400, "invalid_model", .invalidModel),
            (403, "model access denied", .unavailable),
            (429, "quota exceeded", .unavailable),
            (503, "service unavailable", .unavailable),
            (408, "timeout", .timeout),
            (504, "gateway timeout", .timeout)
        ] {
            let transport = ProbeTransport(body: try data(["error": ["message": message]]), status: status)
            let result = try await ModelProbe(client: ImageAPIClient(apiTransport: transport, downloadTransport: transport)).test(configuration: configuration)
            XCTAssertEqual(result.status, expected, "HTTP \(status)")
            let requests = await transport.requests
            XCTAssertEqual(requests.count, 1)
        }
    }

    func testProbeRejectsNonImageSuccessAndTextOnlyChatResponse() async throws {
        for body in [try data(["data": [["b64_json": Data("text".utf8).base64EncodedString()]]]),
                     try data(["choices": [["message": ["content": "Sorry, cannot generate an image"]]]])] {
            let transport = ProbeTransport(body: body)
            var config = configuration
            if String(decoding: body, as: UTF8.self).contains("choices") {
                config.mode = .chatCompletions; config.endpoint = "https://api.openai.com/v1/chat/completions"
            }
            let result = try await ModelProbe(client: ImageAPIClient(apiTransport: transport, downloadTransport: transport)).test(configuration: config)
            XCTAssertEqual(result.status, .unavailable)
        }
    }

    func testProbeDeadlineCancelsRequestAndDoesNotRetry() async throws {
        let transport = ProbeTransport(body: pngResponse, delay: 30_000_000_000)
        let result = try await ModelProbe(client: ImageAPIClient(apiTransport: transport, downloadTransport: transport), timeoutOverride: 0.02).test(configuration: configuration)
        XCTAssertEqual(result.status, .timeout)
        let requests = await transport.requests
        let cancelled = await transport.cancelled
        XCTAssertEqual(requests.count, 1)
        XCTAssertTrue(cancelled)
    }

    func testProbeInvalidConfigurationNeverSubmits() async throws {
        let transport = ProbeTransport(body: pngResponse)
        let probe = ModelProbe(client: ImageAPIClient(apiTransport: transport, downloadTransport: transport))
        var config = configuration
        config.model = " "
        let missingModel = try await probe.test(configuration: config)
        XCTAssertEqual(missingModel.title, "请检查模型是否正确")
        config = configuration; config.apiKey = ""
        let missingKey = try await probe.test(configuration: config)
        XCTAssertEqual(missingKey.status, .invalidConfiguration)
        let requests = await transport.requests
        XCTAssertTrue(requests.isEmpty)
    }
}
