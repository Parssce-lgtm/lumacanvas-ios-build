import XCTest
import UIKit
@testable import LumaCanvas

private actor ControlledImageTransport: ImageTransport {
    var waits: [String: CheckedContinuation<(Data, URLResponse), Error>] = [:]
    func receive(_ request: URLRequest, byteLimit: Int) async throws -> (Data, URLResponse) {
        let body = try JSONSerialization.jsonObject(with: request.httpBody!) as! [String: Any]
        let prompt = body["prompt"] as! String
        return try await withCheckedThrowingContinuation { waits[prompt] = $0 }
    }
    func ready(_ count: Int) -> Bool { waits.count == count }
    func complete(_ prompt: String) throws {
        let png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGPICbv9HwAFbAKdcwZIEgAAAABJRU5ErkJggg=="
        let data = try JSONSerialization.data(withJSONObject: ["data": [["b64_json": png]]])
        waits.removeValue(forKey: prompt)?.resume(returning: (data, HTTPURLResponse(url: URL(string: "https://fixture.invalid")!, statusCode: 200, httpVersion: nil, headerFields: nil)!))
    }
}

@MainActor final class CanvasTaskTests: XCTestCase {
    func testDeletingUnfinishedTaskDoesNotReturnOrStopAnotherTask() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = ArtworkStore(root: root)
        let transport = ControlledImageTransport()
        let model = CanvasViewModel(store: store, persistState: false, client: ImageAPIClient(apiTransport: transport))
        var config = APIConfiguration.preset(.custom)
        config.endpoint = "https://fixture.invalid/v1/images/generations"; config.apiKey = "fixture"; config.model = "image-fixture"
        model.prompt = "deleted"; model.generate(configuration: config)
        model.newConversation()
        let removed = try XCTUnwrap(model.sidebarJobs.first)
        model.prompt = "retained"; model.generate(configuration: config)
        for _ in 0..<100 { if await transport.ready(2) { break }; try await Task.sleep(nanoseconds: 10_000_000) }
        model.deleteUnfinishedTask(removed.id)
        XCTAssertTrue(model.sidebarJobs.isEmpty)
        XCTAssertTrue(model.isGenerating)
        try await transport.complete("deleted")
        try await Task.sleep(nanoseconds: 30_000_000)
        XCTAssertFalse(model.jobs.contains { $0.id == removed.id })
        XCTAssertNil(model.alertMessage)
        XCTAssertTrue(model.isGenerating)
        try await transport.complete("retained")
        for _ in 0..<100 { if !model.isGenerating { break }; try await Task.sleep(nanoseconds: 10_000_000) }
        XCTAssertEqual(model.artwork?.prompt, "retained")
        let gallery = try await store.list()
        XCTAssertEqual(gallery.map(\.prompt), ["retained"])
    }
    func testConcurrentDraftsCompleteSeparatelyAndArchiveOnlyAfterReview() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = ArtworkStore(root: root)
        let transport = ControlledImageTransport()
        let client = ImageAPIClient(apiTransport: transport)
        let model = CanvasViewModel(store: store, persistState: false, client: client)
        var config = APIConfiguration.preset(.custom)
        config.endpoint = "https://fixture.invalid/v1/images/generations"; config.apiKey = "fixture"; config.model = "image-fixture"
        model.prompt = "first"; model.generate(configuration: config)
        XCTAssertTrue(model.isGenerating); XCTAssertTrue(model.sidebarJobs.isEmpty)
        model.newConversation()
        XCTAssertFalse(model.isGenerating); XCTAssertEqual(model.sidebarJobs.count, 1)
        model.prompt = "second"; model.generate(configuration: config)
        for _ in 0..<100 { if await transport.ready(2) { break }; try await Task.sleep(nanoseconds: 10_000_000) }
        let ready = await transport.ready(2); XCTAssertTrue(ready)
        try await transport.complete("first")
        for _ in 0..<100 { if model.sidebarJobs.first?.state == .completed { break }; try await Task.sleep(nanoseconds: 10_000_000) }
        XCTAssertTrue(model.isGenerating, "Finishing an old draft must not stop the new draft")
        XCTAssertNil(model.artwork)
        let before = try await store.list(); XCTAssertTrue(before.isEmpty, "Unviewed detached results stay outside the gallery")
        let job = try XCTUnwrap(model.sidebarJobs.first)
        let result = try await model.openTask(job)
        XCTAssertEqual(result?.prompt, "first")
        await model.archiveTask(job.id)
        XCTAssertTrue(model.sidebarJobs.isEmpty); XCTAssertTrue(model.galleryUnread)
        let archived = try await store.list(); XCTAssertEqual(archived.map(\.prompt), ["first"])
        model.markGalleryRead(); XCTAssertFalse(model.galleryUnread)
        try await transport.complete("second")
        for _ in 0..<100 { if !model.isGenerating { break }; try await Task.sleep(nanoseconds: 10_000_000) }
        XCTAssertEqual(model.artwork?.prompt, "second")
        let final = try await store.list(); XCTAssertEqual(final.count, 2)
    }

    func testCompletedTaskMetadataSurvivesRelaunch() throws {
        let suite = "CanvasTaskTests." + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let job = CanvasGenerationJob(id: UUID(), draftID: UUID(), prompt: "restored", model: "fixture", startedAt: Date(), state: .completed, detached: true, artworkID: UUID())
        defaults.set(try JSONEncoder().encode([job]), forKey: "canvas-jobs-v1")
        defaults.set(true, forKey: "canvas-gallery-unread")
        let restored = CanvasViewModel(defaults: defaults)
        XCTAssertEqual(restored.sidebarJobs.map(\.id), [job.id]); XCTAssertTrue(restored.galleryUnread)
    }
}
